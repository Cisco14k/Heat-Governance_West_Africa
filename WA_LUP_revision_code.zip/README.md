# Processing and analysis code — West African heat-governance revision (LUP-D-26-03718)

1. `pc_download/` — data acquisition (run on a machine with internet access): `wa_landsat.py` (dry-season Landsat C2 L2
   composites), `wa_scenes.py` (scene archive 1985–2026), `wa_ref.py` (WorldCover, GSW, DEM, GHSL), `wa_era5.py`
   (ERA5-Land/ERA5 via Open-Meteo); helpers `wa_common.py` (requires `a42_common.py` from the Heat6 pipeline),
   boundaries in `areas/`.
2. `analysis/` — `lulc.py` → `lulc_tc.py` (classification, temporal consistency, accuracy and EM area adjustment),
   `lstm.py` (LST/SUHI), `did.py` (conversion thermal effect), `clr.py` (cooling-land retention), `scene_clim.py` and
   `comp_met.py` (ERA5 control), `invest.py`/`invest_run.py` (InVEST Urban Cooling re-implementation), `conn.py`
   (connectivity and access), `seb_core.py`/`seb_wa.py` (IBM/TRM), `ml.py` (XGBoost–SHAP–ALE), `results.py` (summary).
3. `figures/` — all manuscript and supplementary figures (matplotlib; `overlap.py` checks text overlaps).
