"""Figures 4, 6-10 for the revised manuscript (matplotlib; generated from the processed data; no generative AI)."""
import json, sys
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch, FancyBboxPatch, FancyArrowPatch
from matplotlib.lines import Line2D
from overlap import check
from wc import D, RES, KEYS, NAME, EPOCHS, YEAR, LABEL, CLASSES, inside, read

FIG = __import__('pathlib').Path('/home/claude/heat/figs')
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7, 'axes.linewidth': 0.6, 'axes.titlesize': 7.5,
                     'legend.frameon': False, 'savefig.dpi': 600, 'axes.spines.top': False, 'axes.spines.right': False,
                     'xtick.major.width': 0.6, 'ytick.major.width': 0.6, 'axes.grid': True, 'grid.color': '#e6e6e6',
                     'grid.linewidth': 0.5, 'axes.axisbelow': True})
CCOL = ['#d7301f', '#c7dd8c', '#1b7837', '#2b83ba', '#d8b365']
CITY = {'WA_OUA': '#2a78d6', 'WA_ABJ': '#eb6834', 'WA_ACC': '#1baf7a'}
MK = {'WA_OUA': 'o', 'WA_ABJ': 's', 'WA_ACC': '^'}
SHORT = {'WA_OUA': 'Ouagadougou', 'WA_ABJ': 'Abuja (FCT)', 'WA_ACC': 'Accra (AMA)'}
INK, MUTED = '#222222', '#6b6b6b'
J = lambda p: json.load(open(p))


def panel(ax, s):
    ax.text(-0.02, 1.04, s, transform=ax.transAxes, fontweight='bold', fontsize=8.5, ha='right', va='bottom')


def fig4():
    """Land-cover shares per period (stacked bars) and built-up share: mapped, error-adjusted (95% CI), GHSL check."""
    fig, axs = plt.subplots(2, 3, figsize=(18 / 2.54, 11.5 / 2.54), gridspec_kw=dict(height_ratios=[1.15, 1]))
    x = np.arange(4); yrs = [YEAR[e] for e in EPOCHS]
    for c, k in enumerate(KEYS):
        acc = J(RES / 'lulc' / f'{k}_accuracy.json'); ins = inside(k)
        ax = axs[0, c]; bottom = np.zeros(4)
        for i, cl in enumerate(CLASSES):
            v = np.array([acc[e]['map_share'][cl] * 100 for e in EPOCHS])
            ax.bar(x, v, bottom=bottom, color=CCOL[i], width=0.68, edgecolor='white', linewidth=0.8, label=cl)
            for xi, (b, h) in enumerate(zip(bottom, v)):
                if h >= 7:
                    ax.text(xi, b + h / 2, f'{h:.0f}', ha='center', va='center', fontsize=5.8,
                            color='white' if i in (0, 2, 3) else INK)
            bottom += v
        ax.set_xticks(x); ax.set_xticklabels([LABEL[e] for e in EPOCHS]); ax.set_ylim(0, 100)
        ax.set_title(SHORT[k], fontweight='bold'); ax.grid(axis='x', visible=False)
        if c == 0:
            ax.set_ylabel('Mapped share of boundary (%)')
        panel(ax, 'abc'[c])
        ax = axs[1, c]
        m = [acc[e]['map_share']['Built-up'] * 100 for e in EPOCHS]
        a = [acc[e]['adj_share']['Built-up'] * 100 for e in EPOCHS]
        lo = [acc[e]['adj_lo']['Built-up'] * 100 for e in EPOCHS]; hi = [acc[e]['adj_hi']['Built-up'] * 100 for e in EPOCHS]
        g = []
        for e, gy in zip(EPOCHS, [1990, 2000, 2015, 2025]):
            f = D / 'ref' / f'{k}_ghsl_built_{gy}.tif'
            g.append(float((read(f)[0][0][ins] / 1000.0 >= 0.2).mean() * 100) if f.exists() else np.nan)
        ax.plot(yrs, m, '-', color=CCOL[0], lw=2, marker='o', ms=4.5, mec='white', mew=0.8, label='Mapped (this study)')
        ax.errorbar(yrs, a, yerr=[np.array(a) - lo, np.array(hi) - a], fmt='D', ms=3.6, color='#7f1d1d', mec='white',
                    mew=0.6, elinewidth=1, capsize=2, label='Error-adjusted, 95% CI')
        ax.plot(yrs, g, '--', color=MUTED, lw=1.4, marker='s', ms=3.5, mec='white', mew=0.6,
                label='GHSL built-up fraction ≥ 0.2')
        ax.set_xlim(1984, 2029); ax.set_xticks([1988, 2001, 2015, 2025])
        ax.set_ylim(0, max(max(m), max(hi), np.nanmax(g)) * 1.18 + 1)
        if c == 0:
            ax.set_ylabel('Built-up share (%)')
        panel(ax, 'def'[c])
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc='upper center', ncol=5, bbox_to_anchor=(0.5, 1.0), fontsize=6.6, handlelength=1.2)
    h, l = axs[1, 0].get_legend_handles_labels()
    fig.legend(h, l, loc='lower center', ncol=3, bbox_to_anchor=(0.5, 0.0), fontsize=6.6)
    fig.subplots_adjust(left=0.07, right=0.99, top=0.88, bottom=0.12, wspace=0.25, hspace=0.42)
    check(fig, 'Fig4_trajectories.png'); fig.savefig(FIG / 'Fig4_trajectories.png'); plt.close(fig)



def fig6():
    """Scene-level dry-season LST and SUHI (1985-2026): raw and ERA5-meteorology-adjusted, with composite benchmarks."""
    import statsmodels.api as sm
    from scene_clim import fit, MET
    C = J(RES / 'clim' / 'clim_summary.json'); L = J(RES / 'lst' / 'lst_metrics.json')
    fig, axs = plt.subplots(2, 3, figsize=(18 / 2.54, 11 / 2.54), sharex=True)
    for c, k in enumerate(KEYS):
        S = pd.read_csv(RES / 'clim' / f'{k}_scenes.csv')
        for r, y in enumerate(['LST_city', 'SUHI_core']):
            ax = axs[r, c]
            m_met, d = fit(S, y, False)
            raw = d[y]; adj = m_met.resid + raw.mean()
            t = d['year']
            ax.scatter(t, raw - (raw.mean() if r == 0 else 0), s=7, color='#bdbdbd', lw=0, label='Scene, as observed')
            ax.scatter(t, adj - (raw.mean() if r == 0 else 0), s=9, color=CITY[k], lw=0, alpha=0.85,
                       label='Scene, meteorology-adjusted (city colour)')
            s_ = C[k][y]; tt = np.array([t.min(), t.max()])
            for vals, col, ls, sl in [(raw, '#9e9e9e', '--', s_['trend_raw_per_decade']), (adj, CITY[k], '-', s_['trend_adj_per_decade'])]:
                yy = vals.mean() + sl / 10 * (tt - t.mean())
                ax.plot(tt, yy - (raw.mean() if r == 0 else 0), ls, color=col, lw=1.6)
            if r == 1:
                for ep in EPOCHS:
                    ax.plot(YEAR[ep], L[k]['periods'][ep]['suhi'], 'D', ms=5, color=INK, mec='white', mew=0.7,
                            label='Composite benchmark' if ep == 'E88' else None, zorder=5)
                ax.axhline(0, color=MUTED, lw=0.6)
            s = C[k][y]
            ax.text(0.03, 0.97, f"trend {s['trend_raw_per_decade']:+.2f} → {s['trend_adj_per_decade']:+.2f} °C/10 yr\n"
                    f"95% CI of adjusted: [{s['trend_adj_ci'][0]:+.2f}, {s['trend_adj_ci'][1]:+.2f}]\n"
                    f"n = {s['n']}, R²(met) = {s['r2_met']:.2f}", transform=ax.transAxes, va='top', fontsize=5.8,
                    color=INK, bbox=dict(fc='white', ec='none', alpha=0.8, pad=1))
            if r == 0:
                ax.set_title(SHORT[k], fontweight='bold')
            if c == 0:
                ax.set_ylabel('City-mean LST anomaly (°C)' if r == 0 else 'SUHI of persistent core (°C)')
            panel(ax, 'abcdef'[r * 3 + c])
            ax.set_xlim(1984, 2027)
    h, l = axs[1, 0].get_legend_handles_labels()
    fig.legend(h, l, loc='lower center', ncol=3, bbox_to_anchor=(0.5, 0.0), fontsize=6.6, markerscale=1.5)
    fig.subplots_adjust(left=0.075, right=0.99, top=0.94, bottom=0.12, wspace=0.22, hspace=0.18)
    check(fig, 'Fig6_scene_met.png'); fig.savefig(FIG / 'Fig6_scene_met.png'); plt.close(fig)


TERMS = [('radiative', 'Radiative'), ('aerodynamic', r'Aerodynamic ($r_a$)'), ('surface_resistance', r'Evaporative ($r_s$)'),
         ('storage', 'Storage (G)')]
TCOL = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100']


def fig8():
    """TRM attribution of the urban-rural surface temperature contrast (mean terms) and covariance contributions."""
    S = J(RES / 'seb' / 'seb_summary.json')
    fig, axs = plt.subplots(2, 3, figsize=(18 / 2.54, 11 / 2.54), gridspec_kw=dict(height_ratios=[1.25, 1]))
    x = np.arange(4)
    for c, k in enumerate(KEYS):
        ax = axs[0, c]; pos = np.zeros(4); neg = np.zeros(4)
        for i, (t, lab) in enumerate(TERMS):
            v = np.array([S[k][e]['trm_mean'][t] for e in EPOCHS])
            b = np.where(v >= 0, pos, neg)
            ax.bar(x, v, bottom=b, color=TCOL[i], width=0.62, edgecolor='white', linewidth=0.8, label=lab)
            pos += np.where(v >= 0, v, 0); neg += np.where(v < 0, v, 0)
        dx = [S[k][e]['dX_mean'] for e in EPOCHS]
        ax.plot(x, dx, 'D', color=INK, ms=5, mec='white', mew=0.7, label=r'Observed $\Delta T_s$ (urban − rural)', zorder=5)
        for xi, v in zip(x, dx):
            ax.text(xi + 0.36, v, f'{v:+.1f}', fontsize=5.8, va='center', color=INK)
        ax.axhline(0, color=MUTED, lw=0.6)
        ax.set_xticks(x); ax.set_xticklabels([LABEL[e] for e in EPOCHS]); ax.grid(axis='x', visible=False)
        ax.set_title(SHORT[k], fontweight='bold'); ax.set_xlim(-0.5, 3.85)
        if c == 0:
            ax.set_ylabel('Mean contribution (K)')
        panel(ax, 'abc'[c])
        ax = axs[1, c]; w = 0.19
        for i, (t, lab) in enumerate(TERMS):
            v = [S[k][e]['trm_cov'][t] for e in EPOCHS]
            ax.bar(x + (i - 1.5) * w, v, width=w * 0.92, color=TCOL[i])
        ax.axhline(0, color=MUTED, lw=0.6)
        ax.set_xticks(x); ax.set_xticklabels([LABEL[e] for e in EPOCHS]); ax.grid(axis='x', visible=False)
        if c == 0:
            ax.set_ylabel('Share of spatial variance (%)')
        panel(ax, 'def'[c])
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc='lower center', ncol=5, bbox_to_anchor=(0.5, 0.0), fontsize=6.6)
    fig.subplots_adjust(left=0.07, right=0.99, top=0.94, bottom=0.12, wspace=0.24, hspace=0.3)
    check(fig, 'Fig8_seb.png'); fig.savefig(FIG / 'Fig8_seb.png'); plt.close(fig)


def fig7():
    """InVEST HMI-LST association, green-blue synergy, observed cooling gradient and cooling access."""
    I = J(RES / 'invest' / 'invest_summary.json'); Cn = J(RES / 'conn' / 'conn_metrics.json')
    fig, axs = plt.subplots(2, 2, figsize=(18 / 2.54, 12.5 / 2.54))
    # a: adjusted R2 c. 2025, V vs V+W by distance
    ax = axs[0, 0]; ds = [100, 200, 300]
    for k in KEYS:
        r = I[k]['B25']
        ax.plot(ds, [r[f'main_V_{d}']['r2_adj'] for d in ds], '--', color=CITY[k], marker=MK[k], mfc='white', ms=5, lw=1.4)
        ax.plot(ds, [r[f'main_VW_{d}']['r2_adj'] for d in ds], '-', color=CITY[k], marker=MK[k], ms=5, lw=2, mec='white', mew=0.6)
        ax.text(306, r['main_VW_300']['r2_adj'], SHORT[k].split(' ')[0], color=INK, fontsize=6.2, va='center')
    ax.set_xticks(ds); ax.set_xlim(85, 360); ax.set_xlabel('InVEST cooling distance (m)')
    ax.set_ylabel('Adjusted R² of LST ~ HMI (c. 2025)')
    ax.legend(handles=[Line2D([], [], color=MUTED, ls='--', marker='o', mfc='white', label='Vegetation (V)'),
                       Line2D([], [], color=MUTED, ls='-', marker='o', label='Vegetation + water (V+W)')], loc='center right',
              bbox_to_anchor=(1.0, 0.62), fontsize=6.2)
    panel(ax, 'a')
    # b: GBS at 100 m by period
    ax = axs[0, 1]; yrs = [YEAR[e] for e in EPOCHS]
    for k in KEYS:
        g = [I[k][e]['main_GBS_100'] for e in EPOCHS]; gcv = [I[k][e]['main_GBScv_100'] for e in EPOCHS]
        ax.plot(yrs, g, '-', color=CITY[k], marker=MK[k], ms=5, lw=2, mec='white', mew=0.6, label=SHORT[k])
        ax.plot(yrs, gcv, ':', color=CITY[k], lw=1.2)
    ax.axhline(0, color=MUTED, lw=0.6); ax.set_xticks([1988, 2001, 2015, 2025])
    ax.set_ylabel('Green–blue synergy, ΔAdj.R² at 100 m')
    ax.legend(loc='center right', bbox_to_anchor=(1.0, 0.45), fontsize=6.2)
    ax.text(0.98, 0.30, 'solid: in-sample; dotted: spatial-block CV', transform=ax.transAxes, fontsize=5.8, color=MUTED, ha='right')
    panel(ax, 'b')
    # c: observed LST gradient of built-up pixels with distance to the nearest cooling patch (c. 2025)
    ax = axs[1, 0]
    for k in KEYS:
        g = pd.read_csv(RES / 'conn' / f'{k}_B25_gradient.csv')
        ax.plot(g['d_mid'], g['mean'], marker=MK[k], color=CITY[k], ms=3.2, lw=1.2, mec='white', mew=0.4,
                label=f"{SHORT[k]} (d* = {Cn[k]['B25']['gradient'].get('dstar', np.nan):.0f} m)")
        p = Cn[k]['B25']['gradient']
        if 'dstar' in p:
            dd = np.linspace(15, 900, 200)
            ax.plot(dd, p['A'] * np.exp(-dd / p['dstar']) + p['c'], '-', color=CITY[k], lw=0.8, alpha=0.6)
    ax.axhline(0, color=MUTED, lw=0.6)
    ax.set_xlabel('Distance of built-up pixel to nearest forest/water patch ≥ 2 ha (m)')
    ax.set_ylabel('LST relative to built-up 600–900 m away (°C)'); ax.legend(loc='lower right', fontsize=6.2)
    panel(ax, 'c')
    # d: cooling access c. 2025
    ax = axs[1, 1]; w = 0.26; xs = np.arange(3)
    for i, k in enumerate(KEYS):
        r = Cn[k]['B25']
        b = [r[f'built_within_{d}'] * 100 for d in ds]; p = [r.get(f'pop_within_{d}', np.nan) * 100 for d in ds]
        h = [r[f'hot_built_within_{d}'] * 100 for d in ds]
        ax.bar(xs + (i - 1) * w, b, width=w * 0.92, color=CITY[k], label=SHORT[k])
        ax.scatter(xs + (i - 1) * w, p, marker='o', s=16, color='white', edgecolor=INK, lw=0.8, zorder=4,
                   label='Residents' if i == 0 else None)
        ax.scatter(xs + (i - 1) * w, h, marker='v', s=16, color=INK, zorder=4, label='Hottest 25% of built-up' if i == 0 else None)
    ax.set_xticks(xs); ax.set_xticklabels([f'≤ {d} m' for d in ds]); ax.grid(axis='x', visible=False)
    ax.set_ylabel('Share within distance of a cooling patch (%)'); ax.set_xlabel('Distance to forest/water patch ≥ 2 ha (c. 2025)')
    ax.legend(loc='upper left', fontsize=6.0, ncol=2)
    panel(ax, 'd')
    fig.subplots_adjust(left=0.08, right=0.98, top=0.96, bottom=0.09, wspace=0.25, hspace=0.32)
    check(fig, 'Fig7_cooling_access.png'); fig.savefig(FIG / 'Fig7_cooling_access.png'); plt.close(fig)


FLAB = {'built': 'Built-up fraction', 'forest': 'Forest fraction', 'water': 'Water fraction', 'bare': 'Bare fraction',
        'ndvi': 'NDVI', 'mndwi': 'MNDWI', 'albedo': 'Albedo', 'hmi': 'HMI (V+W, 100 m)', 'cool300': 'Cooling patches ≤ 300 m',
        'd_cool': 'Distance to cooling patch', 'd_water': 'Distance to water', 'elev_rel': 'Relative elevation',
        'slope': 'Slope', 'bheight': 'Building height', 'pop': 'Residential density'}


def fig9():
    """Validation-gated XGBoost: SHAP importance and ALE response shapes (c. 2025)."""
    M = J(RES / 'ml' / 'ml_summary.json')
    fig = plt.figure(figsize=(18 / 2.54, 10.5 / 2.54))
    ax = fig.add_axes([0.205, 0.12, 0.27, 0.80])
    top = []
    for k in KEYS:
        top += list(M['shap'][k])[:6]
    top = [f for f in dict.fromkeys(top)]
    top = sorted(top, key=lambda f: -np.mean([M['shap'][k].get(f, 0) for k in KEYS]))
    y = np.arange(len(top))[::-1]; h = 0.26
    for i, k in enumerate(KEYS):
        ax.barh(y + (1 - i) * h, [M['shap'][k].get(f, 0) for f in top], height=h * 0.9, color=CITY[k], label=SHORT[k])
    ax.set_yticks(y); ax.set_yticklabels([FLAB[f] for f in top], fontsize=6.4); ax.grid(axis='y', visible=False)
    ax.set_xlabel('Mean |SHAP| (standardized LST)')
    g1 = M['gate1']; g2 = M['gate2']
    txt = '\n'.join([f"{SHORT[k].split(' ')[0]}: CV R² {g1[k]['r2']:.2f}, LOCO R² {g2[k]['r2']:.2f}" for k in KEYS])
    ax.set_xlim(0, 0.56)
    ax.legend(loc='center right', bbox_to_anchor=(1.0, 0.45), fontsize=6.2)
    panel(ax, 'a')
    feats = ['ndvi', 'cool300', 'd_cool']
    for j, f in enumerate(feats):
        ax = fig.add_axes([0.55 + (j % 2) * 0.235, 0.58 - (j // 2) * 0.47, 0.19, 0.34])
        for k in KEYS:
            A = J(RES / 'ml' / f'ale_{k}.json').get(f)
            if not A:
                continue
            sd = g1[k]['lst_sd_C']
            x = np.array(A['x']); a = np.array(A['ale']) * sd
            ax.plot(x, a, '-', color=CITY[k], lw=1.8, marker=MK[k], ms=2.6, mec='white', mew=0.3)
        ax.axhline(0, color=MUTED, lw=0.6)
        ax.set_xlabel(FLAB[f] + (' (m)' if f == 'd_cool' else ' (share)' if f == 'cool300' else ''), fontsize=6.4)
        if j % 2 == 0:
            ax.set_ylabel('ALE (°C)')
        if f == 'd_cool':
            ax.set_xlim(0, 1500)
        panel(ax, 'bcd'[j])
    axl = fig.add_axes([0.785, 0.11, 0.19, 0.34]); axl.axis('off')
    axl.legend(handles=[Line2D([], [], color=CITY[k], marker=MK[k], lw=1.8, label=SHORT[k]) for k in KEYS],
               loc='center', fontsize=6.4, title='ALE curves', title_fontsize=6.6)
    check(fig, 'Fig9_ml.png'); fig.savefig(FIG / 'Fig9_ml.png'); plt.close(fig)


if __name__ == '__main__':
    for f in sys.argv[1:]:
        globals()[f]()
