"""Fig. 10: evidence-to-policy synthesis (matplotlib vector primitives; no generative-AI elements)."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import sys
sys.path.insert(0, '/home/claude/heat/an')
from overlap import check
plt.rcParams.update({'font.family': 'DejaVu Sans'})
W, H = 18.0, 10.4
fig = plt.figure(figsize=(W / 2.54, H / 2.54))
ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, W); ax.set_ylim(0, H); ax.axis('off')
CITY = [('Ouagadougou', 'semi-arid; 556 mm yr⁻¹', '#2a78d6'), ('Abuja (FCT)', 'sub-humid; 1,407 mm yr⁻¹', '#eb6834'),
        ('Accra (AMA)', 'coastal humid; 883 mm yr⁻¹', '#1baf7a')]
EVID = [
    [['Built-up 32% → 59% (0.75 pp yr⁻¹)'], ['44% of c. 1988 green–blue land sealed'],
     ['Dry-season SUHI −0.2 to −1.3 °C;', 'conversion effect −0.8 °C'], ['Forest −4.6 °C, reservoirs −13.3 °C', 'vs rural; water adds HMI skill'],
     ['21% of built-up ≤ 300 m of a patch']],
    [['Built-up 3% → 7% of the FCT'], ['97% of green–blue land retained;', 'patch connectivity declining'],
     ['SUHI about +5 °C;', 'conversion effect +0.9 °C'], ['Cooling footprint d* ≈ 110 m'],
     ['27% of built-up, 32% of residents', '≤ 300 m of a patch']],
    [['Core 68–75% built-up in c. 1988;', 'little change since'], ['Forest/water only 8% of area'],
     ['SUHI +2.3 to +4.8 °C;', 'conversion effect +1.6 to +2.4 °C'], ['No open water: no V+W gain'],
     ['12% of built-up, 4% of hottest', 'built-up ≤ 300 m of a patch']],
]
POL = [
    [['Retain tree cover, riparian', 'woodland and reservoirs'], ['Limit sealing of remaining', 'green–blue land'],
     ['Shade along markets, schools', 'and transit routes*'], ['Water–heat nexus: harvest and', 'reuse stormwater*']],
    [['Prevent fragmentation of forests,', 'green wedges and riparian corridors'], ['Connectivity and green–blue', 'retention in subdivision plans'],
     ['Monitor patch connectivity and', 'cooling access'], ['Integrate detention and drainage*']],
    [['Protect remaining forest and', 'institutional green land'], ['Greening and permeability rules', 'for infill and redevelopment'],
     ['Street trees and pocket parks to', 'raise access ≤ 300 m'], ['Joint flood–heat planning*']],
]
BX = [0.25, 6.15, 12.05]; BW = 5.7
inside_checks = []


def box(x, y, w, h, fc, ec, lw=0.8):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.02,rounding_size=0.15', fc=fc, ec=ec, lw=lw))


def items(x, ytop, lst):
    y = ytop; LH = 0.36
    out = []
    for it in lst:
        for j, line in enumerate(it):
            if j == 0:
                out.append(ax.text(x, y, '•', ha='left', va='top', fontsize=6.1, color='#1a1a1a'))
            out.append(ax.text(x + 0.22, y, line, ha='left', va='top', fontsize=6.1, color='#1a1a1a'))
            y -= LH
        y -= 0.1
    return out


for i, (name, clim, col) in enumerate(CITY):
    x = BX[i]
    box(x, 9.25, BW, 0.95, col, col)
    ax.text(x + BW / 2, 9.84, name, ha='center', va='center', fontsize=8, fontweight='bold', color='white')
    ax.text(x + BW / 2, 9.5, clim, ha='center', va='center', fontsize=6.2, color='white')
    box(x, 5.2, BW, 3.85, '#f4f6f8', '#5b6670')
    t = ax.text(x + 0.18, 8.88, 'Empirical findings (Tier 1–2)', ha='left', va='top', fontsize=6.6, fontweight='bold', color='#33414d')
    inside_checks.append((t, (x, 5.2, BW, 3.85)))
    for tb in items(x + 0.2, 8.47, EVID[i]):
        inside_checks.append((tb, (x, 5.2, BW, 3.85)))
    ax.add_patch(FancyArrowPatch((x + BW / 2, 5.15), (x + BW / 2, 4.62), arrowstyle='-|>', mutation_scale=9, lw=1.0, color='#555555'))
    box(x, 0.55, BW, 4.0, '#ffffff', col, lw=1.1)
    t = ax.text(x + 0.18, 4.38, 'Land-policy responses', ha='left', va='top', fontsize=6.6, fontweight='bold', color='#33414d')
    inside_checks.append((t, (x, 0.55, BW, 4.0)))
    for tb in items(x + 0.2, 3.97, POL[i]):
        inside_checks.append((tb, (x, 0.55, BW, 4.0)))
ax.text(W / 2, 0.22, '* recommendation extending beyond the analysed variables (not tested in this study)', ha='center',
        va='center', fontsize=6.0, color='#555555', style='italic')
issues = check(fig, 'Fig10')
r = fig.canvas.get_renderer(); inv = ax.transData.inverted()
for t, (x, y, w, h) in inside_checks:
    bb = t.get_window_extent(r).transformed(inv)
    if bb.x0 < x or bb.x1 > x + w - 0.05 or bb.y0 < y + 0.05 or bb.y1 > y + h:
        print('TEXT OUTSIDE BOX:', t.get_text()[:30], bb, (x, y, w, h))
fig.savefig('/home/claude/heat/figs/Fig10_policy.png', dpi=600)
fig.savefig('/home/claude/heat/figs/Fig10_policy.pdf'); fig.savefig('/home/claude/heat/figs/Fig10_policy.svg')
print('ok')
