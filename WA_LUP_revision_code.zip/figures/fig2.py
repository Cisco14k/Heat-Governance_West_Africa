"""Fig. 2 (drawn with matplotlib vector primitives; no generative-AI elements): analytical workflow."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 6.2})
W, H = 18.0, 12.2                      # cm
fig = plt.figure(figsize=(W / 2.54, H / 2.54))
ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, W); ax.set_ylim(0, H); ax.axis('off')
C = dict(data=('#EAF2E3', '#3F6E2A'), t1=('#E6EEF7', '#2B5C8A'), t2=('#E5F4F1', '#1F7A6B'),
         t3=('#F7EDE2', '#9A5B1E'))
TS, BS = 6.3, 5.75


def box(x, y, w, h, title, lines, kind):
    fc, ec = C[kind]
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.02,rounding_size=0.15', fc=fc, ec=ec, lw=0.8))
    ax.text(x + 0.17, y + h - 0.2, title, ha='left', va='top', fontsize=TS, fontweight='bold', color=ec)
    ax.text(x + 0.17, y + h - 0.58, '\n'.join(lines), ha='left', va='top', fontsize=BS, color='#1a1a1a', linespacing=1.28)


def arrow(x0, y0, x1, y1, col='#555555'):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle='-|>', mutation_scale=6.5, lw=0.8, color=col,
                                 shrinkA=0, shrinkB=0))


def band(y, h, label, kind):
    fc, ec = C[kind]
    ax.add_patch(FancyBboxPatch((4.55, y), 13.35, h, boxstyle='round,pad=0.02,rounding_size=0.18', fc='none', ec=ec,
                                lw=0.7, ls=(0, (3, 2))))
    ax.text(4.83, y + h / 2, label, ha='center', va='center', rotation=90, fontsize=6.1, color=ec, fontweight='bold')


# data column
box(0.12, 8.6, 4.2, 3.45, 'Satellite and reanalysis data',
    ['Landsat 4/5 TM, 7 ETM+, 8/9 OLI', 'Collection 2 Level-2 surface', 'reflectance and surface temperature',
     'Dry seasons (1 Nov-31 Mar),', '1985-2026', 'ERA5-Land and ERA5 hourly fields', 'Study boundaries (geoBoundaries)'], 'data')
box(0.12, 4.75, 4.2, 3.6, 'Independent reference layers',
    ['ESA WorldCover 2021 (10 m)', 'GHSL R2023A built-up surface', '(1990-2025), building height,', 'residential population',
     'JRC Global Surface Water', '(1984-2021)', 'Copernicus DEM GLO-30'], 'data')
box(0.12, 0.2, 4.2, 4.3, 'Benchmark periods and cities',
    ['c. 1988: 1986-1991 (TM)', 'c. 2001: 2000-2003 (ETM+, SLC-on)', 'c. 2015: 2014-2016 (OLI)', 'c. 2025: 2024-2026 (OLI/OLI-2)',
     '', 'Ouagadougou (semi-arid)', 'Abuja FCT (sub-humid)', 'Accra Metropolitan Area', '(coastal humid)'], 'data')
# tier 1
band(6.55, 5.5, 'Tier 1  observed change', 't1')
box(5.15, 9.15, 4.1, 2.7, '1a Screening, compositing',
    ['QA_PIXEL cloud, shadow and', 'cirrus masks; ST_QA <= 5 K;', 'outlier screens; per-pixel', 'median composites (30 m);',
     'OLI harmonised to ETM+'], 't1')
box(9.45, 9.15, 4.1, 2.7, '1b Land-cover maps',
    ['Random Forest, five classes;', 'reference labels from WorldCover', 'with GHSL and GSW constraints;',
     'spatial-block accuracy; area-', 'adjusted estimates with 95% CI'], 't1')
box(13.75, 9.15, 4.0, 2.7, '1c LST and SUHI',
    ['Mean and percentile LST;', 'SUHI = built-up minus fixed', 'persistent rural reference;', 'ring and GHSL sensitivity',
     'zones; class-level LST'], 't1')
box(5.15, 6.7, 6.2, 2.2, '1d Land-policy indicators',
    ['Annualised sealing pressure (ASP); cooling-land', 'retention (CLR); conversion thermal effect',
     '(difference-in-differences of converted versus', 'persistent green pixels)'], 't1')
box(11.55, 6.7, 6.2, 2.2, '1e Background-climate control',
    ['Scene-level LST and SUHI (1985-2026) regressed', 'on ERA5-Land/ERA5 meteorology at overpass;',
     'meteorology-adjusted period means;', 'cross-sensor (TM/ETM+/OLI) check'], 't1')
# tier 2
band(3.5, 2.85, 'Tier 2  screening', 't2')
box(5.15, 3.62, 6.2, 2.6, '2a InVEST Urban Cooling (HMI)',
    ['Cooling capacity from shade, albedo and ETI;', 'vegetation (V) and vegetation + water (V+W)',
     'cooling areas at 100, 200 and 300 m;', 'HMI-LST association, spatial-block CV,', "residual Moran's I, spatial error model"], 't2')
box(11.55, 3.62, 6.2, 2.6, '2b Connectivity and cooling access',
    ['Forest/water patches >= 2 ha: largest patch,', 'cohesion, network linkage at 100/300 m;',
     'built-up land and residents within', '100-300 m of a patch; observed LST', 'gradient with distance to patches'], 't2')
# tier 3
band(0.2, 3.05, 'Tier 3  exploratory', 't3')
box(5.15, 0.33, 6.2, 2.75, '3a Surface energy balance (IBM/TRM)',
    ['Landsat albedo, NDVI and LST with ERA5', 'forcing at overpass; Shapley attribution',
     'of the urban-rural contrast to radiative,', 'aerodynamic, evaporative (beta, rs) and', 'storage terms'], 't3')
box(11.55, 0.33, 6.2, 2.75, '3b XGBoost with SHAP and ALE (c. 2025)',
    ['120 m cells, 15 predictors; Gate 1: spatial-', 'block CV within each city; Gate 2: leave-',
     "one-city-out transfer; residual Moran's I;", 'SHAP importance and ALE response shapes'], 't3')
# arrows
for y in (10.3, 6.5, 2.4):
    arrow(4.32, y, 4.55, y, '#3F6E2A')
arrow(9.25, 10.5, 9.45, 10.5); arrow(13.55, 10.5, 13.75, 10.5)
arrow(11.5, 9.15, 8.25, 8.9); arrow(15.75, 9.15, 14.65, 8.9)
arrow(8.25, 6.7, 8.25, 6.22); arrow(14.65, 6.7, 14.65, 6.22)
arrow(8.25, 3.62, 8.25, 3.08); arrow(14.65, 3.62, 14.65, 3.08)
import sys; sys.path.insert(0, '/home/claude/heat/an'); from overlap import check; check(fig, 'Fig2')
fig.savefig('/home/claude/heat/figs/Fig2_workflow.png', dpi=600)
fig.savefig('/home/claude/heat/figs/Fig2_workflow.pdf')
fig.savefig('/home/claude/heat/figs/Fig2_workflow.svg')
print('ok')
