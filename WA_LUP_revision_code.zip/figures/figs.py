"""Figures for the revised manuscript (all generated from the processed data with matplotlib; no generative AI)."""
import json, sys
import numpy as np, pandas as pd, rasterio
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm, TwoSlopeNorm
from matplotlib.patches import Patch, Rectangle
import geopandas as gpd
from overlap import check
from wc import D, RES, KEYS, NAME, EPOCHS, YEAR, LABEL, CLASSES, grid, boundary, inside, read, composite

FIG = __import__('pathlib').Path('/home/claude/heat/figs'); FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7, 'axes.linewidth': 0.6, 'axes.titlesize': 7.5,
                     'legend.frameon': False, 'savefig.dpi': 600})
CCOL = ['#d7301f', '#c7dd8c', '#1b7837', '#2b83ba', '#d8b365']
CMAP = ListedColormap(['#ffffff'] + CCOL)
CITY_ORDER = ['WA_OUA', 'WA_ABJ', 'WA_ACC']


def extent(key, pad=0.03, vpad=0.15):
    """Map extent: boundary bounds plus a 3% side margin and 15% strips above and below the boundary, which hold
    the panel annotation (top) and the scale bar and north arrow (bottom) so that they never overlap the map."""
    b = boundary(key).bounds
    dx, dy = b[2] - b[0], b[3] - b[1]
    return [b[0] - pad * dx, b[2] + pad * dx, b[1] - vpad * dy, b[3] + vpad * dy]


def show(ax, arr, key, res=30.0, **kw):
    g = grid(key, res)
    x0, y0, x1, y1 = g['bounds']
    im = ax.imshow(arr, extent=[x0, x1, y0, y1], interpolation='nearest', **kw)
    gpd.GeoSeries([boundary(key)]).boundary.plot(ax=ax, color='k', lw=0.5)
    e = extent(key)
    ax.set_xlim(e[0], e[1]); ax.set_ylim(e[2], e[3])
    ax.set_xticks([]); ax.set_yticks([]); ax.set_xlabel(''); ax.set_ylabel('')
    for s in ax.spines.values():
        s.set_visible(False)
    return im


def scalebar(ax, key, km=None):
    """Scale bar in the bottom margin strip (bottom-left), below the study boundary."""
    e = extent(key)
    w = e[1] - e[0]; h = e[3] - e[2]
    km = km or (5 if w < 40000 else (20 if w < 150000 else 50))
    x0 = e[0] + 0.04 * w; y0 = e[2] + 0.02 * h
    ax.add_patch(Rectangle((x0, y0), km * 1000, 0.012 * h, color='k', lw=0, zorder=6))
    ax.text(x0 + km * 500, y0 + 0.022 * h, f'{km} km', ha='center', va='bottom', fontsize=6, zorder=6)


def north(ax, key=None):
    """North arrow in the bottom margin strip (bottom-right), below the study boundary: arrow with 'N' to its left."""
    ax.annotate('', xy=(0.97, 0.108), xytext=(0.97, 0.018), xycoords='axes fraction', zorder=6,
                arrowprops=dict(arrowstyle='-|>', lw=0.9, color='k', mutation_scale=7, shrinkA=0, shrinkB=0))
    ax.text(0.945, 0.063, 'N', transform=ax.transAxes, ha='right', va='center', fontsize=6.5, fontweight='bold', zorder=6)


def masked(arr, key):
    ins = inside(key)
    a = arr.astype(float).copy()
    a[~ins] = np.nan
    return a


def fig_lulc():
    fig, axs = plt.subplots(3, 4, figsize=(18 / 2.54, 15.5 / 2.54))
    for r, k in enumerate(CITY_ORDER):
        acc = json.load(open(RES / 'lulc' / f'{k}_accuracy.json'))
        for c, ep in enumerate(EPOCHS):
            ax = axs[r, c]
            L = read(RES / 'lulc' / f'{k}_{ep}_lulc.tif')[0][0]
            a = masked(L, k)
            show(ax, np.where(np.isfinite(a), a, 0), k, cmap=CMAP, vmin=-0.5, vmax=5.5)
            if r == 0:
                ax.set_title(LABEL[ep], fontweight='bold')
            if c == 0:
                ax.text(-0.04, 0.5, NAME[k], transform=ax.transAxes, rotation=90, ha='right', va='center', fontweight='bold')
                scalebar(ax, k)
            if c == 3:
                north(ax, k)
            a_ = acc.get(ep, {})
            if a_:
                ax.text(0.02, 0.98, f"OA {a_['oa']:.2f}, κ {a_['kappa']:.2f}", transform=ax.transAxes, fontsize=5.6,
                        va='top')
    fig.legend(handles=[Patch(color=CCOL[i], label=CLASSES[i]) for i in range(5)], loc='lower center', ncol=5,
               bbox_to_anchor=(0.5, 0.005), fontsize=6.8)
    fig.subplots_adjust(left=0.04, right=0.995, top=0.96, bottom=0.06, wspace=0.03, hspace=0.06)
    check(fig, 'Fig3_lulc_maps.png'); fig.savefig(FIG / 'Fig3_lulc_maps.png'); plt.close(fig)


def fig_lst():
    M = json.load(open(RES / 'lst' / 'lst_metrics.json'))
    fig, axs = plt.subplots(3, 4, figsize=(18 / 2.54, 15.5 / 2.54))
    norm = TwoSlopeNorm(vmin=-8, vcenter=0, vmax=8)
    for r, k in enumerate(CITY_ORDER):
        for c, ep in enumerate(EPOCHS):
            ax = axs[r, c]
            lst = composite(k, ep)['lst']
            ref = M[k]['periods'][ep]['ref_mean']
            im = show(ax, masked(lst - ref, k), k, cmap='RdBu_r', norm=norm)
            if r == 0:
                ax.set_title(LABEL[ep], fontweight='bold')
            if c == 0:
                ax.text(-0.04, 0.5, NAME[k], transform=ax.transAxes, rotation=90, ha='right', va='center', fontweight='bold')
                scalebar(ax, k)
            if c == 3:
                north(ax, k)
            p = M[k]['periods'][ep]
            ax.text(0.02, 0.98, f"mean {p['lst_mean']:.1f} °C\nSUHI {p['suhi']:+.1f} °C", transform=ax.transAxes,
                    fontsize=5.6, va='top')
    cax = fig.add_axes([0.30, 0.075, 0.40, 0.012])
    cb = fig.colorbar(im, cax=cax, orientation='horizontal', extend='both')
    cb.set_label('LST minus persistent rural reference (°C)', fontsize=6.5); cb.ax.tick_params(labelsize=6)
    fig.subplots_adjust(left=0.04, right=0.995, top=0.96, bottom=0.12, wspace=0.03, hspace=0.06)
    check(fig, 'Fig5_lst_maps.png'); fig.savefig(FIG / 'Fig5_lst_maps.png'); plt.close(fig)



def fig_study():
    """Fig. 1: location of the three cities in West Africa and their analysis boundaries over c. 2025 land cover."""
    ne = gpd.read_file('/home/claude/heat/bnd/ne_50m_admin0.geojson')
    afr = ne[ne.CONTINENT == 'Africa']
    fig = plt.figure(figsize=(18 / 2.54, 7.6 / 2.54))
    ax0 = fig.add_axes([0.005, 0.13, 0.28, 0.85])
    afr.plot(ax=ax0, color='#f2f2f2', edgecolor='#9a9a9a', lw=0.3)
    for iso, col in [('BFA', '#f3d9a4'), ('NGA', '#cfe3f3'), ('GHA', '#cfe8cc')]:
        afr[afr.ADM0_A3 == iso].plot(ax=ax0, color=col, edgecolor='#666', lw=0.4)
    pts = {'WA_OUA': (-1.52, 12.37), 'WA_ABJ': (7.49, 9.06), 'WA_ACC': (-0.20, 5.56)}
    for k, (x, y) in pts.items():
        ax0.plot(x, y, 'o', ms=3.5, color='k')
        ax0.text(x + 1.0, y + (0.8 if k != 'WA_ACC' else -1.6), NAME[k].split(' (')[0], fontsize=6.5)
    ax0.set_xlim(-19, 52); ax0.set_ylim(-36, 38); ax0.set_xticks([]); ax0.set_yticks([]); ax0.set_xlabel(''); ax0.set_ylabel('')
    ax0.text(0.03, 0.97, 'a', transform=ax0.transAxes, fontweight='bold', fontsize=9, va='top')
    for s in ax0.spines.values():
        s.set_linewidth(0.5)
    for i, k in enumerate(CITY_ORDER):
        ax = fig.add_axes([0.30 + i * 0.235, 0.15, 0.225, 0.70])
        L = read(RES / 'lulc' / f'{k}_B25_lulc.tif')[0][0]
        show(ax, L, k, cmap=CMAP, vmin=-0.5, vmax=5.5, alpha=0.85)
        from shapely.geometry import box
        e = extent(k, pad=0.0)
        ax.set_title(f"{'bcd'[i]}  {NAME[k]}\n{json.load(open('/home/claude/heat/pc/wa_lup/areas_wa.json'))[k]['area_km2_equal_area']:,.1f} km²",
                     fontsize=7, loc='left')
        scalebar(ax, k); north(ax, k)
    fig.legend(handles=[Patch(color=CCOL[j], label=CLASSES[j]) for j in range(5)] +
               [plt.Line2D([], [], color='k', lw=0.8, label='Analysis boundary')], loc='lower center', ncol=6,
               bbox_to_anchor=(0.5, 0.0), fontsize=6.5)
    check(fig, 'Fig1_study_area.png'); fig.savefig(FIG / 'Fig1_study_area.png'); plt.close(fig)


def fig_s1():
    """Fig. S1: number of clear observations per pixel in each composite."""
    from matplotlib.colors import BoundaryNorm
    fig, axs = plt.subplots(3, 4, figsize=(18 / 2.54, 15.5 / 2.54))
    cmap = plt.get_cmap('viridis', 10); norm = BoundaryNorm(np.arange(0.5, 11.5, 1), 10)
    for r, k in enumerate(CITY_ORDER):
        for c, ep in enumerate(EPOCHS):
            ax = axs[r, c]
            n = composite(k, ep)['nobs']
            im = show(ax, masked(np.clip(n, 0, 10), k), k, cmap=cmap, norm=norm)
            if r == 0:
                ax.set_title(LABEL[ep], fontweight='bold')
            if c == 0:
                ax.text(-0.04, 0.5, NAME[k], transform=ax.transAxes, rotation=90, ha='right', va='center', fontweight='bold')
                scalebar(ax, k)
            if c == 3:
                north(ax, k)
            ins = inside(k)
            ax.text(0.02, 0.98, f"median {np.median(n[ins]):.0f}; ≥3: {(n[ins] >= 3).mean() * 100:.0f}%", transform=ax.transAxes,
                    fontsize=5.6, va='top')
    cax = fig.add_axes([0.30, 0.075, 0.40, 0.012])
    cb = fig.colorbar(im, cax=cax, orientation='horizontal', ticks=range(1, 11))
    cb.ax.set_xticklabels([str(i) for i in range(1, 10)] + ['≥10'])
    cb.set_label('Clear observations per pixel', fontsize=6.5); cb.ax.tick_params(labelsize=6)
    fig.subplots_adjust(left=0.04, right=0.995, top=0.96, bottom=0.12, wspace=0.03, hspace=0.06)
    check(fig, 'FigS1_nobs.png'); fig.savefig(FIG / 'FigS1_nobs.png', dpi=300); plt.close(fig)


def fig_s2():
    """Fig. S2: InVEST HMI (V+W, 100 m) for c. 2025."""
    fig, axs = plt.subplots(1, 3, figsize=(18 / 2.54, 7.2 / 2.54))
    for i, k in enumerate(CITY_ORDER):
        ax = axs[i]
        h = read(RES / 'invest' / f'{k}_B25_hmi_vw100.tif')[0][0].astype(float)
        h[h < 0] = np.nan
        im = show(ax, masked(h, k), k, cmap='YlGn', vmin=0, vmax=1)
        ax.set_title(f"{'abc'[i]}  {NAME[k]}", fontsize=7, loc='left', fontweight='bold')
        scalebar(ax, k); north(ax, k)
    cax = fig.add_axes([0.30, 0.20, 0.40, 0.03])
    cb = fig.colorbar(im, cax=cax, orientation='horizontal'); cb.set_label('Heat Mitigation Index (V+W, 100 m), c. 2025', fontsize=6.5)
    cb.ax.tick_params(labelsize=6)
    fig.subplots_adjust(left=0.01, right=0.99, top=0.92, bottom=0.30, wspace=0.05)
    check(fig, 'FigS2_hmi.png'); fig.savefig(FIG / 'FigS2_hmi.png', dpi=300); plt.close(fig)


if __name__ == '__main__':
    for f in sys.argv[1:]:
        globals()[f]()
