"""Overlap checker for matplotlib figures: collects the text that is actually drawn (titles, axis labels, visible tick
labels, free text, legends) and reports intersecting bounding boxes and text outside the canvas."""
import itertools


def _drawn_ticklabels(axis):
    lo, hi = sorted(axis.get_view_interval())
    eps = (hi - lo) * 1e-6
    out = []
    for tk in axis.get_major_ticks():
        loc = tk.get_loc()
        if lo - eps <= loc <= hi + eps:
            for lab in (tk.label1, tk.label2):
                if lab.get_visible() and lab.get_text().strip():
                    out.append(lab)
    return out


def check(fig, name='', pad=0.5):
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    W, H = fig.canvas.get_width_height()
    items = []
    def add(t, kind):
        if t is None or not t.get_visible():
            return
        if kind != 'legend' and not t.get_text().strip():
            return
        bb = t.get_window_extent(r)
        if bb.width >= 1 and bb.height >= 1:
            items.append(((t.get_text().strip().replace('\n', ' ')[:40] if kind != 'legend' else '<legend>'), bb, kind))
    for ax in fig.axes:
        if not ax.get_visible() or not ax.axison and not ax.texts:
            pass
        for t in (ax.title, ax._left_title, ax._right_title, ax.xaxis.label, ax.yaxis.label):
            add(t, 'label')
        if ax.axison:
            for t in _drawn_ticklabels(ax.xaxis) + _drawn_ticklabels(ax.yaxis):
                add(t, 'tick')
        for t in ax.texts:
            add(t, 'text')
        if ax.get_legend() is not None:
            add(ax.get_legend(), 'legend')
    for t in fig.texts:
        add(t, 'text')
    for lg in fig.legends:
        add(lg, 'legend')
    issues = []
    for (a, ba, ka), (b, bb, kb) in itertools.combinations(items, 2):
        ov_w = min(ba.x1, bb.x1) - max(ba.x0, bb.x0); ov_h = min(ba.y1, bb.y1) - max(ba.y0, bb.y0)
        if ov_w > pad and ov_h > pad:
            issues.append(f'overlap: [{ka}] "{a}" <-> [{kb}] "{b}"')
    for a, ba, ka in items:
        if ba.x0 < -1 or ba.y0 < -1 or ba.x1 > W + 1 or ba.y1 > H + 1:
            issues.append(f'outside canvas: [{ka}] "{a}"')
    print(f'[overlap check] {name}: {len(issues)} issue(s)')
    for i in issues[:40]:
        print('   ', i)
    return issues
