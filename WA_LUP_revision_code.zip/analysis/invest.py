"""InVEST Urban Cooling Model (v3.14.3, 'factors' method) re-implemented on the 30 m land-cover maps, following
the operations of natcap.invest.urban_cooling_model:
  ETI = Kc * ET0 / ET0max (ET0 uniform within a city -> ETI = Kc); CC = 0.6 shade + 0.2 albedo + 0.2 ETI
  CC_park = convolution of the green-area flag with a normalised exponential-decay kernel (expected distance d_cool,
            truncated at 5 d_cool; edges normalised), GA = green-area pixels within d_cool (dichotomous kernel)
  HMI = CC where CC >= CC_park or GA < 2 ha, else CC_park
Configurations: V (vegetation green areas) and V+W (water also a green area); d_cool 100/200/300 m. Main analysis:
dry-season-matched green areas (forest = perennial tree cover); sensitivity: original configuration in which
farmland/shrub is also a green area (veg_classes=(2, 3)).
Parameters: shade and Kc from the biophysical table of the original submission (Supplementary Table S2); albedo
per class from the Landsat composite of each period (Liang 2001 shortwave albedo, class median).
"""
import numpy as np
from scipy.signal import fftconvolve

SHADE = {'WA_OUA': {1: 0, 2: 0.30, 3: 1.00, 4: 0, 5: 0}, 'WA_ABJ': {1: 0, 2: 0.40, 3: 1.00, 4: 0, 5: 0},
         'WA_ACC': {1: 0, 2: 0.45, 3: 1.00, 4: 0, 5: 0}}
KC = {'WA_OUA': {1: 0.001, 2: 0.85, 3: 0.98, 4: 0.65, 5: 0.05}, 'WA_ABJ': {1: 0.001, 2: 0.90, 3: 0.99, 4: 0.70, 5: 0.06},
      'WA_ACC': {1: 0.002, 2: 0.88, 3: 0.97, 4: 0.72, 5: 0.07}}
ALB_S2 = {'WA_OUA': {1: 0.22, 2: 0.18, 3: 0.16, 4: 0.08, 5: 0.24}, 'WA_ABJ': {1: 0.21, 2: 0.18, 3: 0.16, 4: 0.08, 5: 0.20},
          'WA_ACC': {1: 0.20, 2: 0.19, 3: 0.17, 4: 0.08, 5: 0.19}}


def liang_albedo(c):
    """Liang (2001) broadband shortwave albedo for TM/ETM+-like reflectance (OLI harmonised before use)."""
    return 0.356 * c['blue'] + 0.130 * c['red'] + 0.373 * c['nir'] + 0.085 * c['swir1'] + 0.072 * c['swir2'] - 0.0018


def kernel_exp(d_px):
    R = int(np.ceil(5 * d_px))
    y, x = np.mgrid[-R:R + 1, -R:R + 1]
    r = np.hypot(x, y)
    k = np.where(r <= 5 * d_px, np.exp(-r / d_px), 0.0)
    return k / k.sum()


def kernel_disc(d_px):
    R = int(np.ceil(d_px))
    y, x = np.mgrid[-R:R + 1, -R:R + 1]
    return (np.hypot(x, y) <= d_px).astype(float)


def hmi(lulc, key, d_cool, water_green, albedo=None, res=30.0, veg_classes=(3,)):
    valid = lulc > 0
    sh = np.zeros(lulc.shape, np.float32); kc = np.zeros_like(sh); al = np.zeros_like(sh)
    alb = albedo or ALB_S2[key]
    for c in range(1, 6):
        m = lulc == c
        sh[m] = SHADE[key][c]; kc[m] = KC[key][c]; al[m] = alb[c]
    cc = 0.6 * sh + 0.2 * al + 0.2 * kc
    green = np.isin(lulc, list(veg_classes) + ([4] if water_green else [])).astype(np.float32)
    dpx = int(round(d_cool / res))
    ke = kernel_exp(dpx)
    num = fftconvolve(green * valid, ke, mode='same')
    den = fftconvolve(valid.astype(np.float32), ke, mode='same')
    cc_park = np.where(den > 1e-6, num / np.maximum(den, 1e-6), 0)
    ga = fftconvolve(green * valid, kernel_disc(dpx), mode='same')
    thr = 2e4 / res ** 2
    h = np.where((cc >= cc_park) | (ga < thr), cc, cc_park).astype(np.float32)
    h[~valid] = np.nan
    return h, cc
