"""Surface-energy-balance core for the West Africa revision, taken from the tested Heat6 implementation (seb.py):
cell-level balance at the Landsat overpass (Brutsaert sky emissivity, Bastiaanssen ground-heat fraction with an
imperviousness weight, Monin-Obukhov aerodynamic resistance, surface resistance from the linearised balance) and the
exact Shapley attribution of the TRM surface-air temperature difference (Li et al. 2019 framework). An IBM variant
(Bowen-ratio form) is added in seb_wa.py."""
import numpy as np
import aero
SIG, CP, LV, RD = 5.670374e-8, 1005.0, 2.45e6, 287.05
RS_MAX = 5000.0
G_IMP = 0.40
PLAYERS = ["Rns", "G", "ra_m", "dra", "rs"]
CTX = ["lam0", "rho", "Dq", "sq"]
VARS = ["Rns", "G", "ra", "ra_m", "dra", "rs", "lam0", "rho", "Dq", "sq", "X", "Tb", "alb", "S"]


def solar_position(t_utc, lat, lon):
    """Solar zenith and azimuth (degrees; azimuth clockwise from north), NOAA general solar position."""
    doy = t_utc.timetuple().tm_yday
    hr = t_utc.hour + t_utc.minute / 60 + t_utc.second / 3600
    gam = 2 * np.pi / 365 * (doy - 1 + (hr - 12) / 24)
    eqt = 229.18 * (0.000075 + 0.001868 * np.cos(gam) - 0.032077 * np.sin(gam) - 0.014615 * np.cos(2 * gam)
                    - 0.040849 * np.sin(2 * gam))
    dec = (0.006918 - 0.399912 * np.cos(gam) + 0.070257 * np.sin(gam) - 0.006758 * np.cos(2 * gam)
           + 0.000907 * np.sin(2 * gam) - 0.002697 * np.cos(3 * gam) + 0.00148 * np.sin(3 * gam))
    tst = hr * 60 + eqt + 4 * lon
    ha = np.radians(tst / 4 - 180)
    la = np.radians(lat)
    cz = np.sin(la) * np.sin(dec) + np.cos(la) * np.cos(dec) * np.cos(ha)
    zen = np.degrees(np.arccos(np.clip(cz, -1, 1)))
    az = np.degrees(np.arctan2(np.sin(ha), np.cos(ha) * np.sin(la) - np.tan(dec) * np.cos(la))) + 180
    return float(zen), float(az % 360)



def esat(Tc):
    return 6.112 * np.exp(17.67 * Tc / (Tc + 243.5))          # hPa



def qsat(Tc, P_hpa):
    e = esat(Tc)
    return 0.622 * e / (P_hpa - 0.378 * e)



def emissivity(ndvi, isa):
    nd = np.nan_to_num(ndvi)
    pv = np.clip((nd - 0.2) / 0.3, 0, 1) ** 2
    e_n = np.where(nd < 0.2, 0.973, np.where(nd > 0.5, 0.99, 0.986 + 0.004 * pv))       # Sobrino et al. (2004)
    return (np.clip(isa, 0, 1) * 0.95 + (1 - np.clip(isa, 0, 1)) * e_n).astype(np.float64)



def balance(C, ck, F, prm=None, g_imp=G_IMP, z0sens=False):
    """Cell-level energy balance and resistances of one composite. z0sens: also return d ra / d ln z0m (finite
    difference, z0m x e^0.1 at fixed displacement height), used for the physically predicted roughness effect."""
    ep = ck.split("_")[0]
    z = np.nan_to_num(C["elev"], nan=np.nanmedian(C["elev"]))
    zr = dict(aero.DEFAULT, **(prm or {}))["zr"]
    zg = F.get("grid_elevation", np.nanmedian(z))
    zg = np.nanmedian(z) if not np.isfinite(zg) else zg
    Ta2 = F["temperature_2m"] - 0.0065 * (z - zg)
    Tb_c = Ta2 - 0.0098 * (zr - 2.0)
    Tb = Tb_c + 273.15
    P = F["surface_pressure"] * np.exp(-(z - zg) / 8434.0)              # hPa
    ea = esat(F["dew_point_2m"])                                         # vapour pressure kept from the grid cell
    qa = 0.622 * ea / (P - 0.378 * ea)
    rho = P * 100 / (RD * (Ta2 + 273.15))
    Ts_c = C[f"{ck}_lst"].astype(np.float64)
    Ts = Ts_c + 273.15
    alb = np.clip(C[f"{ck}_albedo"].astype(np.float64), 0.02, 0.9)
    ndvi = C[f"{ck}_ndvi"].astype(np.float64)
    isa = np.nan_to_num(C.get(f"isa_{ep}", C["wc_built"])).astype(np.float64)
    eps = emissivity(ndvi, isa)
    # terrain illumination
    zen, az = np.radians(F["zenith"]), np.radians(F["azimuth"])
    s = np.radians(np.nan_to_num(C["slope"]))
    asp = np.arctan2(np.nan_to_num(C["asp_sin"]), np.nan_to_num(C["asp_cos"]))
    cos_i = np.cos(zen) * np.cos(s) + np.sin(zen) * np.sin(s) * np.cos(az - asp)
    S = F["direct_radiation"] * np.clip(cos_i, 0, None) / max(np.cos(zen), 0.1) + F["diffuse_radiation"] * (1 + np.cos(s)) / 2
    S = np.minimum(S, 1.5 * F["shortwave_radiation"] + 50)
    c = np.clip(F.get("cloud_cover", 0.0) / 100.0, 0, 1)
    ea_K = ea / (Ta2 + 273.15)
    eps_a = np.clip(1.24 * ea_K ** (1 / 7) * (1 + 0.22 * c * c), 0.5, 1.0)
    Ld = eps_a * SIG * (Ta2 + 273.15) ** 4
    Rn = (1 - alb) * S + eps * Ld - eps * SIG * Ts ** 4
    Rns = (1 - alb) * S + eps * Ld - eps * SIG * Tb ** 4
    lam0 = 1.0 / (4 * eps * SIG * Tb ** 3)
    # storage / ground heat flux
    gsoil = np.clip((Ts_c / alb) * (0.0038 * alb + 0.0074 * alb ** 2) * (1 - 0.98 * np.clip(ndvi, 0, 1) ** 4), 0.05, 0.5)
    Gam = np.clip(isa, 0, 1) * g_imp + (1 - np.clip(isa, 0, 1)) * gsoil
    G = Gam * np.maximum(Rn, 0)
    # aerodynamic resistance
    R = aero.roughness(C, ep, prm)
    A = aero.resistance(R, F["wind_speed_10m"], Ts, Tb, rho, prm)
    ra = A["ra"].astype(np.float64)
    ra_m = ra.copy()
    dra_dlnz0 = None
    if z0sens:
        A2 = aero.resistance(dict(R, z0m=R["z0m"] * np.float32(np.exp(0.1))), F["wind_speed_10m"], Ts, Tb, rho, prm)
        dra_dlnz0 = (A2["ra"].astype(np.float64) - ra) / 0.1
    X = Ts - Tb
    Dq = qsat(Tb_c, P) - qa
    sq = (qsat(Tb_c + 0.05, P) - qsat(Tb_c - 0.05, P)) / 0.1
    LE = Rns - G - X / lam0 - rho * CP * X / ra
    adj = LE <= 5.0                                     # no energy left for evaporation with the modelled ra
    avail = Rns - G - X / lam0
    ra_adj = np.where(adj & (X > 0) & (avail > 5.0), rho * CP * X / np.maximum(avail - 5.0, 1.0), ra)
    ra_adj = np.clip(ra_adj, 2.0, 1000.0)
    ra = np.where(adj, ra_adj, ra)
    LE = np.maximum(Rns - G - X / lam0 - rho * CP * X / ra, 1.0)
    num = rho * LV * (Dq + sq * X)
    rs = np.where(num > 0, num / LE - ra, 0.0)
    rs = np.where(adj, RS_MAX, np.clip(rs, 0.0, RS_MAX))
    H = rho * CP * X / ra
    return dict(Ts=Ts, Tb=Tb, X=X, Rn=Rn, Rns=Rns, G=G, H=H, LE=LE, ra=ra, ra_m=ra_m, dra=ra - ra_m, rs=rs, lam0=lam0,
                rho=rho, Dq=Dq, sq=sq,
                alb=alb, S=S, eps=eps, isa=isa, adj=adj, z0m=R["z0m"], zd=R["zd"], lam_p=R["lam_p"], lam_f=R["lam_f"],
                Hav=R["Hav"], kb=A["kb"], ustar=A["ustar"], zeta=A["zeta"], ra_model=A["ra"], U_ref=A["U_ref"],
                dra_dlnz0=dra_dlnz0, U10=F["wind_speed_10m"])


# ------------------------------------------------------------------ TRM
PLAYERS = ["Rns", "G", "ra_m", "dra", "rs"]
CTX = ["lam0", "rho", "Dq", "sq"]
VARS = ["Rns", "G", "ra", "ra_m", "dra", "rs", "lam0", "rho", "Dq", "sq", "X", "Tb", "alb", "S"]



def xhat(st, ctx):
    """Closed-form TRM surface-air temperature difference (TC3 Supplementary Eq. S16)."""
    r0 = ctx["rho"] * CP * ctx["lam0"]
    kq = LV * ctx["sq"] / CP
    ra = np.maximum(st["ra_m"] + st["dra"], 1.0)
    rr = ra + st["rs"]
    f = r0 / ra + r0 * kq / rr
    A = st["Rns"] - st["G"] - ctx["rho"] * LV * ctx["Dq"] / rr
    return ctx["lam0"] * A / (1 + f)



def trm_parts(st):
    """First-order TRM sensitivities (TC3 Supplementary Eqs. S18-S22) at one state."""
    r0 = st["rho"] * CP * st["lam0"]
    kq = LV * st["sq"] / CP
    rr = st["ra"] + st["rs"]
    f = r0 / st["ra"] + r0 * kq / rr
    A = st["Rns"] - st["G"] - st["rho"] * LV * st["Dq"] / rr
    dA = st["rho"] * LV * st["Dq"] / rr ** 2
    dfa = -r0 / st["ra"] ** 2 - r0 * kq / rr ** 2
    dfs = -r0 * kq / rr ** 2
    lam = st["lam0"]
    return dict(dRn=lam / (1 + f), dG=-lam / (1 + f), dra=lam * (dA * (1 + f) - A * dfa) / (1 + f) ** 2,
                drs=lam * (dA * (1 + f) - A * dfs) / (1 + f) ** 2)



def shapley_interaction(v, players, i, j):
    """Pairwise Shapley interaction index (Grabisch and Roubens 1999) of players i and j for the game v:
    I_ij = sum over S in N minus {i, j} of |S|! (n - |S| - 2)! / (n - 1)! [v(S+ij) - v(S+i) - v(S+j) + v(S)].
    Positive: the two changes reinforce each other (synergy); negative: they offset each other."""
    from itertools import combinations
    from math import factorial
    n = len(players)
    others = [q for q in players if q not in (i, j)]
    tot = 0.0
    for k in range(n - 1):
        w = factorial(k) * factorial(n - k - 2) / factorial(n - 1)
        for S in combinations(others, k):
            S = set(S)
            tot = tot + w * (v(S | {i, j}) - v(S | {i}) - v(S | {j}) + v(S))
    return tot



def attribute(s1, s0):
    """Exact additive attribution of Xhat(1) - Xhat(0) by Shapley values over the five factors (net radiation Rn*,
    storage G, modelled aerodynamic resistance ra_m, energy-closure adjustment of ra, surface resistance rs); the
    atmospheric context (lambda0, rho, Dq, s_q) is held at the mean of the two states. First-order Taylor terms
    (TC3 / Li et al. 2019 form) are returned with the prefix taylor_."""
    from itertools import combinations
    from math import factorial
    ctx = {v: 0.5 * (np.asarray(s1[v], dtype=np.float64) + np.asarray(s0[v], dtype=np.float64)) for v in CTX}
    n = len(PLAYERS)
    cache = {}

    def v(S):
        key = frozenset(S)
        if key not in cache:
            st = {p: (s1[p] if p in S else s0[p]) for p in PLAYERS}
            cache[key] = xhat(st, ctx)
        return cache[key]
    phi = {}
    for p in PLAYERS:
        others = [q for q in PLAYERS if q != p]
        tot = 0.0
        for k in range(n):
            w = factorial(k) * factorial(n - k - 1) / factorial(n)
            for S in combinations(others, k):
                tot = tot + w * (v(set(S) | {p}) - v(set(S)))
        phi[p] = tot
    out = dict(radiative=phi["Rns"], storage=phi["G"], aerodynamic=phi["ra_m"], closure=phi["dra"],
               surface_resistance=phi["rs"], background=np.asarray(s1["Tb"]) - np.asarray(s0["Tb"]),
               observed_dX=np.asarray(s1["X"]) - np.asarray(s0["X"]))
    out["imperviousness"] = out["surface_resistance"]          # evaporative limitation (Li et al. 2019 definition)
    out["int_aero_imperv"] = shapley_interaction(v, PLAYERS, "ra_m", "rs")
    out["int_aero_storage"] = shapley_interaction(v, PLAYERS, "ra_m", "G")
    out["int_aero_radiative"] = shapley_interaction(v, PLAYERS, "ra_m", "Rns")
    out["int_imperv_radiative"] = shapley_interaction(v, PLAYERS, "rs", "Rns")
    out["sum"] = out["radiative"] + out["aerodynamic"] + out["closure"] + out["surface_resistance"] + out["storage"]
    out["residual"] = out["observed_dX"] - out["sum"]
    out["observed_dTs"] = out["observed_dX"] + out["background"]
    # albedo share of the radiative term (first-order split of dRn*)
    dRn = np.asarray(s1["Rns"]) - np.asarray(s0["Rns"])
    alb_part = -0.5 * (np.asarray(s1["S"]) + np.asarray(s0["S"])) * (np.asarray(s1["alb"]) - np.asarray(s0["alb"]))
    with np.errstate(invalid="ignore", divide="ignore"):
        out["albedo"] = out["radiative"] * np.clip(np.where(np.abs(dRn) > 1e-6, alb_part / dRn, 0.0), -2, 2)
    p1, p0 = trm_parts(s1), trm_parts(s0)
    d = {k: 0.5 * (p1[k] + p0[k]) for k in ("dRn", "dG", "dra", "drs")}
    out["taylor_radiative"] = d["dRn"] * dRn
    out["taylor_aerodynamic"] = d["dra"] * (np.asarray(s1["ra"]) - np.asarray(s0["ra"]))
    out["taylor_surface_resistance"] = d["drs"] * (np.asarray(s1["rs"]) - np.asarray(s0["rs"]))
    out["taylor_storage"] = d["dG"] * (np.asarray(s1["G"]) - np.asarray(s0["G"]))
    out["taylor_residual"] = out["observed_dX"] - (out["taylor_radiative"] + out["taylor_aerodynamic"]
                                                   + out["taylor_surface_resistance"] + out["taylor_storage"])
    return out



def effective(st):
    """Effective surface resistance of an aggregated state: the rs that reproduces the state's mean X with its mean
    Rn*, G and ra (aggregation without the Jensen bias of averaging resistances)."""
    ra = np.maximum(np.asarray(st["ra_m"]) + np.asarray(st["dra"]), 1.0)
    X = np.asarray(st["X"])
    LE = st["Rns"] - st["G"] - X / st["lam0"] - st["rho"] * CP * X / ra
    num = st["rho"] * LV * (st["Dq"] + st["sq"] * X)
    with np.errstate(invalid="ignore", divide="ignore"):
        rs = np.where((LE > 1.0) & (num > 0), num / np.maximum(LE, 1.0) - ra, np.asarray(st["rs"]))
    st = dict(st)
    st["rs"] = np.clip(rs, 0.0, RS_MAX)
    st["ra"] = ra
    return st



def group_state(B, m, fun=np.nanmean):
    return effective({v: float(fun(np.asarray(B[v], dtype=np.float64)[m])) for v in VARS})

