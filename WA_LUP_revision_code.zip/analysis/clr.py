"""Sealing-based cooling-land retention (pixel level) and transition matrices. Output res/lulc/clr.json"""
import json
import numpy as np
from wc import RES, KEYS, EPOCHS, inside, read
out = {}
for k in KEYS:
    ins = inside(k)
    L = {ep: read(RES / 'lulc' / f'{k}_{ep}_lulc.tif')[0][0][ins] for ep in EPOCHS}
    r = {}
    for base in ('E88', 'E01'):
        a, b = L[base], L['B25']
        for nm, cls in [('GB', [2, 3, 4]), ('FW', [3, 4]), ('farm', [2])]:
            m = np.isin(a, cls)
            r[f'clr_{nm}_{base}'] = float(100 * (1 - ((b == 1) & m).sum() / max(m.sum(), 1)))
            r[f'area_{nm}_{base}_km2'] = float(m.sum() * 900 / 1e6)
    for e0, e1 in zip(EPOCHS[:-1], EPOCHS[1:]):
        m = np.isin(L[e0], [2, 3, 4])
        r[f'sealed_GB_{e0}_{e1}_pct'] = float(100 * ((L[e1] == 1) & m).sum() / max(m.sum(), 1))
    a, b = L['E88'], L['B25']
    T = np.zeros((5, 5))
    for i in range(5):
        for j in range(5):
            T[i, j] = ((a == i + 1) & (b == j + 1)).sum() * 900 / 1e6
    r['transition_km2_E88_B25'] = T.round(2).tolist()
    r['new_built_from_pct'] = {c: float(T[i, 0] / max(T[1:, 0].sum() + T[0, 0] - T[0, 0], 1e-9) * 100) if i else None
                               for i, c in enumerate(['built', 'farm', 'forest', 'water', 'bare'])}
    r['fw_share'] = {ep: float(np.isin(L[ep], [3, 4]).mean() * 100) for ep in EPOCHS}
    out[k] = r
    print(k, {x: round(v, 1) for x, v in r.items() if x.startswith('clr')}, {x: round(v, 1) for x, v in r['new_built_from_pct'].items() if v})
json.dump(out, open(RES / 'lulc' / 'clr.json', 'w'), indent=1)
