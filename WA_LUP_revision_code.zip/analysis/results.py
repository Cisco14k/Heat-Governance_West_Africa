"""Compile all analysis outputs into res/summary.json and print the numbers used in the manuscript tables."""
import json
import numpy as np, pandas as pd
from wc import D, RES, KEYS, EPOCHS, YEAR, CLASSES, AREAS

J = lambda p: json.load(open(p)) if p.exists() else {}
acc = {k: J(RES / 'lulc' / f'{k}_accuracy.json') for k in KEYS}
lst = J(RES / 'lst' / 'lst_metrics.json'); inv = J(RES / 'invest' / 'invest_summary.json')
conn = J(RES / 'conn' / 'conn_metrics.json'); seb = J(RES / 'seb' / 'seb_summary.json')
clim = J(RES / 'clim' / 'clim_summary.json'); cm = J(RES / 'clim' / 'composite_met.json')
did = J(RES / 'did' / 'did_summary.json'); ml = J(RES / 'ml' / 'ml_summary.json')
ctx = J(RES / 'clim' / 'climate_context.json'); clr = J(RES / 'lulc' / 'clr.json')
S = {}
for k in KEYS:
    s = dict(area_km2=AREAS[k]['area_km2_equal_area'], climate=ctx.get(k), periods={})
    for ep in EPOCHS:
        a = acc[k].get(ep, {})
        meta = J(D / 'landsat' / f'{k}_{ep}.json')
        p = dict(n_dates=meta.get('n_dates'), platforms=meta.get('platforms'), years=meta.get('years'),
                 ge3=meta.get('ge3_inside'), valid=meta.get('valid_inside'), nobs_med=meta.get('nobs_inside_median'),
                 nobs_p10=meta.get('nobs_inside_p10'), dates=sorted(meta.get('dates', [])))
        if a:
            p.update(oa=a['oa'], kappa=a['kappa'], ua=a['ua'], pa=a['pa'], map_share=a['map_share'], adj_share=a['adj_share'],
                     adj_ci=a['adj_ci95'], tc=a.get('temporal_consistency'))
            gb_map = sum(a['map_share'][c] for c in CLASSES[1:4]); gb_adj = sum(a['adj_share'][c] for c in CLASSES[1:4])
            p.update(gb_map=gb_map, gb_adj=gb_adj)
        if k in lst and ep in lst[k]['periods']:
            L = lst[k]['periods'][ep]
            p.update({x: L[x] for x in ['lst_mean', 'lst_p02', 'lst_p98', 'urban_mean', 'ref_mean', 'suhi', 'suhi_ring',
                                        'suhi_ghsl', 'stqa_median', 'nobs_median']})
        if k in cm and ep in cm[k]:
            p['met_anom'] = cm[k][ep]['anomaly']; p['months'] = cm[k][ep]['months']
        s['periods'][ep] = p
    P = s['periods']
    if all('adj_share' in P[e] for e in ('E88', 'B25')):
        dy = YEAR['B25'] - YEAR['E88']
        for t in ('map', 'adj'):
            b0 = P['E88'][f'{t}_share']['Built-up']; b1 = P['B25'][f'{t}_share']['Built-up']
            s[f'built_gain_pp_{t}'] = (b1 - b0) * 100; s[f'asp_{t}'] = (b1 - b0) * 100 / dy
            s[f'clr_{t}'] = P['B25'][f'gb_{t}'] / P['E88'][f'gb_{t}'] * 100
            s[f'clr01_{t}'] = P['B25'][f'gb_{t}'] / P['E01'][f'gb_{t}'] * 100
    s['clr'] = clr.get(k)
    s['did'] = did.get(k); s['clim'] = clim.get(k); s['seb'] = seb.get(k); s['conn'] = conn.get(k); s['invest'] = inv.get(k)
    S[k] = s
S['ml'] = ml
json.dump(S, open(RES / 'summary.json', 'w'), indent=1, default=float)

# ---- printout
for k in KEYS:
    s = S[k]; print('\n=====', k, s['area_km2'], s['climate'])
    for ep in EPOCHS:
        p = s['periods'][ep]
        if 'oa' not in p:
            continue
        print(f" {ep} n={p['n_dates']} {p['platforms']} ge3={p['ge3']} nobs={p['nobs_med']}/{p['nobs_p10']} OA={p['oa']:.3f} k={p['kappa']:.3f}"
              f" built map {p['map_share']['Built-up']*100:.1f} adj {p['adj_share']['Built-up']*100:.1f}±{p['adj_ci']['Built-up']*100:.1f}"
              f" GB map {p['gb_map']*100:.1f} adj {p['gb_adj']*100:.1f} tc={p.get('tc')}")
        if 'suhi' in p:
            print(f"    LST {p['lst_mean']:.2f} urban {p['urban_mean']:.2f} ref {p['ref_mean']:.2f} SUHI {p['suhi']:+.2f} ring {p['suhi_ring']:+.2f} ghsl {p['suhi_ghsl']:+.2f}")
    for t in ('map', 'adj'):
        if f'asp_{t}' in s:
            print(f"  {t}: built gain {s[f'built_gain_pp_{t}']:+.1f} pp ASP {s[f'asp_{t}']:.2f} CLR {s[f'clr_{t}']:.1f}% (vs c.2001 {s[f'clr01_{t}']:.1f}%)")
    if s['did']:
        d = s['did'].get('E88_B25', {})
        print('  DiD E88-B25', {x: (d[x].get('n_conv'), round(d[x]['effect'], 2), [round(v, 2) for v in d[x]['ci95']]) for x in d if isinstance(d[x], dict) and 'effect' in d[x]})
