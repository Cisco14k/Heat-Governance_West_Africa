"""Background meteorology of the composite acquisition dates (ERA5-Land/ERA5 at the overpass time) compared with the
dry-season climatology of the same window (all Nov-Mar days of the window years, same UTC hour).
Outputs res/clim/composite_met.json and res/clim/composite_dates_met.csv
"""
import json
import numpy as np, pandas as pd
from wc import D, RES, KEYS, EPOCHS
from scene_clim import era5, WIN

OUT = RES / 'clim'; OUT.mkdir(exist_ok=True)
COLS = {'T2m': 'temperature_2m_era5_land', 'SM1': 'soil_moisture_0_to_7cm_era5_land', 'VPD': 'vapour_pressure_deficit_era5',
        'SW': 'shortwave_radiation_era5', 'WS': 'wind_speed_10m_era5', 'RH': 'relative_humidity_2m_era5_land'}


def at(E, t, col):
    t0 = t.floor('h'); t1 = t0 + pd.Timedelta(hours=1)
    if t0 not in E.index or t1 not in E.index:
        return np.nan
    w = (t - t0).total_seconds() / 3600
    return float(E.at[t0, col] * (1 - w) + E.at[t1, col] * w)


def main():
    res, rows = {}, []
    for key in KEYS:
        E = era5(key)
        P = E['precipitation_era5'].fillna(0)
        P30 = P.rolling('30D').sum()
        res[key] = {}
        for ep in EPOCHS:
            inv = pd.read_csv(D / 'landsat' / f'{key}_{ep}_scenes.csv')
            inv = inv[(inv.used == 1) & (inv.date_screen == 'kept')]
            recs = []
            for _, r in inv.iterrows():
                t = pd.Timestamp(f"{r['date']} {r['time_utc']}")
                rec = dict(key=key, ep=ep, date=r['date'], time_utc=r['time_utc'], platform=r['platform'],
                           clear_inside=r['clear_inside'], lst_median_inside=r['lst_median_inside'])
                for k, c in COLS.items():
                    rec[k] = at(E, t, c) if c in E.columns else np.nan
                rec['P30'] = float(P30.asof(t)) if len(P30) else np.nan
                recs.append(rec)
            R = pd.DataFrame(recs); rows += recs
            hh = int(np.median([int(x[:2]) for x in inv['time_utc']]))
            yrs = list(WIN[ep])
            sel = E[(E.index.hour == hh) & E.index.month.isin([11, 12, 1, 2, 3])]
            seas = sel.index.year + (sel.index.month >= 11)
            sel = sel[np.isin(seas, yrs)]
            clim = {k: (float(sel[c].mean()), float(sel[c].std())) for k, c in COLS.items() if c in sel.columns}
            p30c = P30[(P30.index.hour == hh) & P30.index.month.isin([11, 12, 1, 2, 3])]
            p30c = p30c[np.isin(p30c.index.year + (p30c.index.month >= 11), yrs)]
            clim['P30'] = (float(p30c.mean()), float(p30c.std()))
            out = dict(n_dates=int(len(R)), months=sorted(set(int(d[5:7]) for d in R['date'])),
                       composite={k: float(R[k].median()) for k in list(COLS) + ['P30']},
                       climatology={k: v[0] for k, v in clim.items()},
                       anomaly={k: float(R[k].median() - clim[k][0]) for k in list(COLS) + ['P30'] if k in clim},
                       anomaly_z={k: float((R[k].median() - clim[k][0]) / clim[k][1]) if clim[k][1] > 0 else None
                                  for k in list(COLS) + ['P30'] if k in clim})
            res[key][ep] = out
            print(key, ep, out['n_dates'], {k: round(v, 2) for k, v in out['anomaly'].items()}, flush=True)
    json.dump(res, open(OUT / 'composite_met.json', 'w'), indent=1)
    pd.DataFrame(rows).to_csv(OUT / 'composite_dates_met.csv', index=False)


if __name__ == '__main__':
    main()
