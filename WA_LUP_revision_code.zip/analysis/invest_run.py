"""Run the InVEST Urban Cooling re-implementation for every city and period and summarise HMI-LST associations.
Cells: 90 m (3 x 3 Landsat pixels) inside the boundary; regressions LST ~ HMI (OLS); green-blue synergy (GBS) =
adjusted R2(V+W) - adjusted R2(V); spatial-block (2 km) cross-validated R2; residual Moran's I (8 nearest
neighbours); spatial error model (GMM, heteroskedasticity-robust) slope on a 6,000-cell subsample.
Outputs res/invest/invest_summary.json, res/invest/albedo_classes.json, res/invest/<key>_B25_hmi_vw100.tif
"""
import json, sys
import numpy as np, pandas as pd
import statsmodels.api as sm
from sklearn.model_selection import GroupKFold
from sklearn.neighbors import NearestNeighbors
from wc import D, RES, KEYS, EPOCHS, CLASSES, inside, read, composite, block_mean, save_tif
from lulc import ROY
import invest

OUT = RES / 'invest'; OUT.mkdir(exist_ok=True)
F = 3


def moran(xy, e, k=8, nmax=12000, seed=0):
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(e), min(nmax, len(e)), replace=False)
    X, v = xy[idx], e[idx] - e[idx].mean()
    _, nb = NearestNeighbors(n_neighbors=k + 1).fit(X).kneighbors(X)
    return float((v * v[nb[:, 1:]].mean(1)).sum() / (v * v).sum())


def sem_slope(xy, y, x, n=6000, seed=1):
    try:
        from libpysal.weights import KNN
        from spreg import GM_Error_Het
        rng = np.random.default_rng(seed)
        idx = rng.choice(len(y), min(n, len(y)), replace=False)
        w = KNN.from_array(xy[idx].astype(float), k=8); w.transform = 'r'
        m = GM_Error_Het(y[idx][:, None], x[idx][:, None], w=w)
        return dict(beta=float(m.betas[1][0]), se=float(np.sqrt(m.vm[1, 1])), lam=float(m.betas[-1][0]))
    except Exception as ex:
        return dict(error=str(ex)[:100])


def assoc(lst, h, ins, blocks_px=22):
    hm = block_mean(h, F, ins); lm = block_mean(lst, F, ins); fin = block_mean(ins.astype(float), F)
    ok = np.isfinite(hm) & np.isfinite(lm) & (fin >= 0.75)
    rr, cc = np.nonzero(ok)
    y, x = lm[ok], hm[ok]
    X = sm.add_constant(x)
    m = sm.OLS(y, X).fit()
    blk = (rr // blocks_px) * 10000 + cc // blocks_px
    pred = np.zeros_like(y)
    for tr, te in GroupKFold(5).split(X, y, blk):
        pred[te] = sm.OLS(y[tr], X[tr]).fit().predict(X[te])
    r2cv = 1 - np.sum((y - pred) ** 2) / np.sum((y - y.mean()) ** 2)
    xy = np.c_[rr, cc].astype(float)
    return dict(n=int(len(y)), r2_adj=float(m.rsquared_adj), slope=float(m.params[1]), slope_se=float(m.bse[1]),
                r2_spatial_cv=float(r2cv), moran_resid=moran(xy, m.resid), mean_hmi=float(np.mean(x))), (xy, y, x)


def run(key):
    ins = inside(key)
    out, albs = {}, {}
    for ep in EPOCHS:
        L = read(RES / 'lulc' / f'{key}_{ep}_lulc.tif')[0][0]
        c = composite(key, ep)
        if ep in ('B15', 'B25'):
            for b, (s, i) in ROY.items():
                c[b] = c[b] * s + i
        alb = invest.liang_albedo(c)
        albc = {k: float(np.nanmedian(alb[(L == k) & np.isfinite(alb)])) if ((L == k) & np.isfinite(alb)).any()
                else invest.ALB_S2[key][k] for k in range(1, 6)}
        albs[ep] = albc
        lst = c['lst']
        res = {}
        for cfg, veg in [('main', (3,)), ('original', (2, 3))]:
            for d in (100, 200, 300):
                for wg in (False, True):
                    h, cc = invest.hmi(L, key, d, wg, albc, veg_classes=veg)
                    a, (xy, y, x) = assoc(lst, h, ins)
                    if ep == 'B25' and cfg == 'main' and d == 100 and wg:
                        a['sem'] = sem_slope(xy, y, x)
                        save_tif(OUT / f'{key}_B25_hmi_vw100.tif', np.nan_to_num(h, nan=-1), key, 30.0, 'float32', nodata=-1)
                        cls = {}
                        for k in range(1, 6):
                            m = (L == k) & ins & np.isfinite(lst)
                            if m.any():
                                cls[CLASSES[k - 1]] = dict(hmi=float(np.nanmean(h[m])), lst=float(np.nanmean(lst[m])), cc=float(np.nanmean(cc[m])))
                        a['class'] = cls
                    res[f'{cfg}_{"VW" if wg else "V"}_{d}'] = a
            for d in (100, 200, 300):
                res[f'{cfg}_GBS_{d}'] = res[f'{cfg}_VW_{d}']['r2_adj'] - res[f'{cfg}_V_{d}']['r2_adj']
                res[f'{cfg}_GBScv_{d}'] = res[f'{cfg}_VW_{d}']['r2_spatial_cv'] - res[f'{cfg}_V_{d}']['r2_spatial_cv']
            s100, s300 = res[f'{cfg}_VW_100']['slope'], res[f'{cfg}_VW_300']['slope']
            res[f'{cfg}_slope_attenuation_100_300'] = float(1 - abs(s300) / abs(s100)) if s100 != 0 else None
        out[ep] = res
        print(key, ep, {k: (round(v['r2_adj'], 3), round(v['slope'], 2)) for k, v in res.items() if isinstance(v, dict) and k.startswith('main')},
              {k: round(v, 3) for k, v in res.items() if k.startswith('main_GBS')}, flush=True)
    return out, albs


if __name__ == '__main__':
    S = json.load(open(OUT / 'invest_summary.json')) if (OUT / 'invest_summary.json').exists() else {}
    A = json.load(open(OUT / 'albedo_classes.json')) if (OUT / 'albedo_classes.json').exists() else {}
    for k in [a for a in sys.argv[1:] if a in KEYS] or KEYS:
        S[k], A[k] = run(k)
        json.dump(S, open(OUT / 'invest_summary.json', 'w'), indent=1, default=float)
        json.dump(A, open(OUT / 'albedo_classes.json', 'w'), indent=1)
