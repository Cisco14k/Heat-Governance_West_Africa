"""Composite-level LST and SUHI metrics per city and benchmark period (30 m).
Urban zone: built-up pixels inside the study boundary (classified map of the same period).
Reference zone (fixed for all periods): persistent rural pixels (farmland/shrub or forest in all four maps) in the
analysis window, >= 1 km from built-up land of c. 2025, not water, elevation within +-50 m of the median elevation of
the c. 2025 urban zone. Sensitivities: (i) reference = non-built land of the same period within 0-5 km outside the
boundary; (ii) GHSL-based zones (built-up fraction >= 0.5 vs <= 0.02).
Outputs res/lst/lst_metrics.json, res/lst/class_lst.csv
"""
import json, sys
import numpy as np, pandas as pd
from scipy import ndimage
from wc import D, RES, KEYS, EPOCHS, YEAR, GHSL_YEAR, CLASSES, inside, read, composite

OUT = RES / 'lst'; OUT.mkdir(exist_ok=True)


def maps(key):
    return {ep: read(RES / 'lulc' / f'{key}_{ep}_lulc.tif')[0][0] for ep in EPOCHS}


def reference_mask(key, L, ins):
    dem = read(D / 'ref' / f'{key}_dem.tif')[0][0]
    rural = np.ones(ins.shape, bool)
    for ep in EPOCHS:
        rural &= np.isin(L[ep], [2, 3])
    far = ndimage.distance_transform_edt(L['B25'] != 1) * 30.0 >= 1000
    zc = np.nanmedian(dem[(L['B25'] == 1) & ins])
    ref = rural & far & (np.abs(dem - zc) <= 50)
    return ref, float(zc)


def metrics(key):
    L = maps(key); ins = inside(key)
    ref, zc = reference_mask(key, L, ins)
    ghsl = {e: read(D / 'ref' / f'{key}_ghsl_built_{e}.tif')[0][0] / 1000.0 for e in [1990, 2000, 2015, 2020]}
    out = dict(ref_n=int(ref.sum()), ref_km2=round(ref.sum() * 900 / 1e6, 2), zc=zc, periods={})
    rows = []
    ring = (ndimage.distance_transform_edt(~ins) * 30.0 <= 5000) & ~ins
    for ep in EPOCHS:
        c = composite(key, ep)
        lst = c['lst']; v = np.isfinite(lst)
        urb = (L[ep] == 1) & ins & v
        r = ref & v
        x = lst[ins & v]
        g = ghsl[GHSL_YEAR[ep]]
        meta = json.load(open(D / 'landsat' / f'{key}_{ep}.json'))
        rec = dict(valid_inside=float(v[ins].mean()), nobs_median=float(np.median(c['nobs'][ins])),
                   nobs_p10=float(np.percentile(c['nobs'][ins], 10)), stqa_median=float(np.nanmedian(c['stqa'][ins & v])),
                   n_dates=meta['n_dates'], dates=meta['dates'], platforms=meta['platforms'],
                   lst_mean=float(np.mean(x)), lst_p02=float(np.percentile(x, 2)), lst_p98=float(np.percentile(x, 98)),
                   lst_median=float(np.median(x)), lst_sd=float(np.std(x)),
                   urban_mean=float(np.mean(lst[urb])), ref_mean=float(np.mean(lst[r])),
                   suhi=float(np.mean(lst[urb]) - np.mean(lst[r])),
                   suhi_ring=float(np.mean(lst[urb]) - np.mean(lst[ring & v & (L[ep] != 1) & (L[ep] != 4)])),
                   suhi_ghsl=float(np.mean(lst[(g >= 0.5) & ins & v]) - np.mean(lst[(g <= 0.02) & v & (L[ep] != 4)])),
                   built_share=float((L[ep][ins] == 1).mean()))
        for ci in range(1, 6):
            m = (L[ep] == ci) & ins & v
            rows.append(dict(key=key, ep=ep, cls=CLASSES[ci - 1], share=float((L[ep][ins] == ci).mean()),
                             lst=float(np.mean(lst[m])) if m.any() else np.nan,
                             lst_minus_ref=float(np.mean(lst[m]) - rec['ref_mean']) if m.any() else np.nan))
        out['periods'][ep] = rec
        print(key, ep, {k: round(v_, 2) for k, v_ in rec.items() if isinstance(v_, float)}, flush=True)
    return out, rows


if __name__ == '__main__':
    allm = json.load(open(OUT / 'lst_metrics.json')) if (OUT / 'lst_metrics.json').exists() else {}
    allr = pd.read_csv(OUT / 'class_lst.csv') if (OUT / 'class_lst.csv').exists() else pd.DataFrame()
    for k in [a for a in sys.argv[1:] if a in KEYS] or KEYS:
        m, rows = metrics(k)
        allm[k] = m
        if len(allr):
            allr = allr[allr.key != k]
        allr = pd.concat([allr, pd.DataFrame(rows)])
    json.dump(allm, open(OUT / 'lst_metrics.json', 'w'), indent=1)
    allr.to_csv(OUT / 'class_lst.csv', index=False)
