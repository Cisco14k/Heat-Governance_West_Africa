"""Validation-gated explainable machine learning (c. 2025, 120 m cells inside each study boundary).
Response: standardised LST anomaly within each city (z). Predictors: land-cover fractions (built-up, forest, water,
bare), NDVI, MNDWI, albedo, InVEST HMI (V+W, 100 m), cooling-patch share within 300 m, distance to the nearest cooling
patch, distance to water, relative elevation, slope, GHSL building height (2018) and residential density (2025).
Gate 1: 5-fold spatial-block cross-validation within each city (2 km blocks); Gate 2: leave-one-city-out (LOCO).
Diagnostics: R2, RMSE, MAE (z and degC), fold spread, residual Moran's I (8 nearest neighbours); SHAP (TreeExplainer)
and first-order ALE (Apley and Zhu 2020) of the leading predictors.
Outputs res/ml/ml_summary.json, res/ml/<key>_cells.parquet, res/ml/shap_<key>.csv, res/ml/ale_<key>.json
"""
import json, sys
import numpy as np, pandas as pd
from scipy import ndimage
import xgboost as xgb
from sklearn.model_selection import GroupKFold
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from wc import D, RES, KEYS, inside, read, composite, block_mean, block_frac
from lulc import ROY
from invest import liang_albedo

OUT = RES / 'ml'; OUT.mkdir(exist_ok=True)
F4 = 4                     # 4 x 4 Landsat pixels = 120 m
FEATS = ['built', 'forest', 'water', 'bare', 'ndvi', 'mndwi', 'albedo', 'hmi', 'cool300', 'd_cool', 'd_water',
         'elev_rel', 'slope', 'bheight', 'pop']
PARAMS = dict(n_estimators=500, learning_rate=0.05, max_depth=6, subsample=0.8, colsample_bytree=0.8,
              min_child_weight=5, reg_lambda=1.0, tree_method='hist', n_jobs=2, random_state=7)


def cells(key, hmi_vw100):
    ins = inside(key)
    L = read(RES / 'lulc' / f'{key}_B25_lulc.tif')[0][0]
    c = composite(key, 'B25')
    for b, (s, i) in ROY.items():
        c[b] = c[b] * s + i
    with np.errstate(divide='ignore', invalid='ignore'):
        ndvi = (c['nir'] - c['red']) / (c['nir'] + c['red']); mndwi = (c['green'] - c['swir1']) / (c['green'] + c['swir1'])
    alb = liang_albedo(c)
    cool = np.isin(L, [3, 4])
    lab, n = ndimage.label(cool, structure=np.ones((3, 3), bool))
    sz = ndimage.sum(cool, lab, index=np.arange(1, n + 1)) if n else np.array([])
    keep = np.zeros(n + 1, bool); keep[1:] = sz >= 23
    coolp = keep[lab]
    d_cool = ndimage.distance_transform_edt(~coolp) * 30.0
    d_water = ndimage.distance_transform_edt(L != 4) * 30.0
    r10 = 10
    k = (np.hypot(*np.mgrid[-r10:r10 + 1, -r10:r10 + 1]) <= r10).astype(float); k /= k.sum()
    cool300 = ndimage.convolve(coolp.astype(np.float32), k, mode='nearest')
    dem = read(D / 'ref' / f'{key}_dem.tif')[0][0]
    gy, gx = np.gradient(dem, 30.0); slope = np.degrees(np.arctan(np.hypot(gx, gy)))
    hb = read(D / 'ref' / f'{key}_ghsl_hagb_2018.tif')[0][0] / 10.0
    pop = read(D / 'ref' / f'{key}_ghsl_pop_2025.tif')[0][0]
    df = dict(inside=block_frac(ins, F4), lst=block_mean(c['lst'], F4),
              built=block_frac(L == 1, F4), forest=block_frac(L == 3, F4), water=block_frac(L == 4, F4),
              bare=block_frac(L == 5, F4), ndvi=block_mean(ndvi, F4), mndwi=block_mean(mndwi, F4), albedo=block_mean(alb, F4),
              hmi=block_mean(hmi_vw100, F4), cool300=block_mean(cool300, F4), d_cool=block_mean(d_cool, F4),
              d_water=block_mean(d_water, F4), elev=block_mean(dem, F4), slope=block_mean(slope, F4),
              bheight=block_mean(hb, F4), pop=block_mean(pop, F4))
    H, W = df['lst'].shape
    rr, cc = np.indices((H, W))
    df['row'] = rr; df['col'] = cc
    T = pd.DataFrame({k_: v.ravel() for k_, v in df.items()})
    T = T[(T.inside >= 0.75)].dropna(subset=['lst'] + [f for f in FEATS if f != 'elev_rel'])
    T['elev_rel'] = T['elev'] - T['elev'].median()
    T['z'] = (T['lst'] - T['lst'].mean()) / T['lst'].std()
    T['lst_sd'] = T['lst'].std()
    T['block'] = (T['row'] // (2000 // 120)).astype(int) * 1000 + (T['col'] // (2000 // 120)).astype(int)
    T['city'] = key
    return T.reset_index(drop=True)


def morans_i(T, resid, k=8, nmax=15000, seed=0):
    from sklearn.neighbors import NearestNeighbors
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(T), min(nmax, len(T)), replace=False)
    X = T[['row', 'col']].values[idx].astype(float); e = resid[idx] - resid[idx].mean()
    nn = NearestNeighbors(n_neighbors=k + 1).fit(X)
    _, nb = nn.kneighbors(X)
    lag = e[nb[:, 1:]].mean(1)
    return float((e * lag).sum() / (e * e).sum())


def gate1(T):
    pred = np.zeros(len(T)); folds = []
    for tr, te in GroupKFold(5).split(T, T['z'], T['block']):
        m = xgb.XGBRegressor(**PARAMS).fit(T.iloc[tr][FEATS], T.iloc[tr]['z'])
        p = m.predict(T.iloc[te][FEATS]); pred[te] = p
        folds.append(dict(r2=r2_score(T.iloc[te]['z'], p), rmse=mean_squared_error(T.iloc[te]['z'], p) ** 0.5))
    sd = T['lst_sd'].iloc[0]
    r = dict(n=len(T), n_blocks=int(T['block'].nunique()), r2=r2_score(T['z'], pred),
             r2_fold_mean=float(np.mean([f['r2'] for f in folds])), r2_fold_sd=float(np.std([f['r2'] for f in folds])),
             rmse_z=mean_squared_error(T['z'], pred) ** 0.5, mae_z=mean_absolute_error(T['z'], pred),
             rmse_C=mean_squared_error(T['z'], pred) ** 0.5 * sd, mae_C=mean_absolute_error(T['z'], pred) * sd,
             lst_sd_C=float(sd), moran_resid=morans_i(T, (T['z'] - pred).values), moran_lst=morans_i(T, T['z'].values))
    # random (non-spatial) CV for comparison (optimism of non-spatial validation)
    from sklearn.model_selection import KFold
    pr = np.zeros(len(T))
    for tr, te in KFold(5, shuffle=True, random_state=0).split(T):
        pr[te] = xgb.XGBRegressor(**PARAMS).fit(T.iloc[tr][FEATS], T.iloc[tr]['z']).predict(T.iloc[te][FEATS])
    r['r2_random_cv'] = r2_score(T['z'], pr)
    return r, pred


def ale_1d(model, X, feat, nb=30):
    x = X[feat].values
    qs = np.unique(np.quantile(x, np.linspace(0, 1, nb + 1)))
    if len(qs) < 3:
        return None
    idx = np.clip(np.digitize(x, qs[1:-1]), 0, len(qs) - 2)
    eff = np.zeros(len(qs) - 1); cnt = np.zeros(len(qs) - 1)
    for j in range(len(qs) - 1):
        m = idx == j
        if not m.any():
            continue
        lo, hi = X[m].copy(), X[m].copy()
        lo[feat] = qs[j]; hi[feat] = qs[j + 1]
        eff[j] = np.mean(model.predict(hi) - model.predict(lo)); cnt[j] = m.sum()
    ale = np.concatenate([[0], np.cumsum(eff)])
    centre = np.sum((ale[:-1] + ale[1:]) / 2 * cnt) / cnt.sum()
    return dict(x=qs.tolist(), ale=(ale - centre).tolist())


if __name__ == '__main__':
    from invest import hmi as hmi_fn
    import invest
    data = {}
    for k in KEYS:
        L = read(RES / 'lulc' / f'{k}_B25_lulc.tif')[0][0]
        alb = json.load(open(RES / 'invest' / 'albedo_classes.json'))[k]['B25'] if (RES / 'invest' / 'albedo_classes.json').exists() else None
        alb = {int(a): b for a, b in alb.items()} if alb else None
        h, _ = hmi_fn(L, k, 100, True, alb, veg_classes=(3,))
        T = cells(k, h); T.to_csv(OUT / f'{k}_cells.csv.gz', index=False); data[k] = T
        print(k, len(T), flush=True)
    summ = dict(gate1={}, gate2={}, shap={}, direction={})
    for k, T in data.items():
        r, pred = gate1(T); summ['gate1'][k] = r
        print('gate1', k, {a: round(b, 3) if isinstance(b, float) else b for a, b in r.items()}, flush=True)
    # Gate 2: leave-one-city-out (training sample <= 40,000 cells per city)
    for k in KEYS:
        tr = pd.concat([d.sample(min(len(d), 40000), random_state=1) for kk, d in data.items() if kk != k])
        m = xgb.XGBRegressor(**PARAMS).fit(tr[FEATS], tr['z'])
        te = data[k]; p = m.predict(te[FEATS])
        sd = te['lst_sd'].iloc[0]
        summ['gate2'][k] = dict(r2=r2_score(te['z'], p), rmse_z=mean_squared_error(te['z'], p) ** 0.5,
                                rmse_C=mean_squared_error(te['z'], p) ** 0.5 * sd, moran_resid=morans_i(te, (te['z'] - p).values))
        print('gate2', k, summ['gate2'][k], flush=True)
    # SHAP and ALE per city (final within-city model) and pooled
    import shap
    pooled = pd.concat([d.sample(min(len(d), 40000), random_state=2) for d in data.values()])
    for k, T in list(data.items()) + [('pooled', pooled)]:
        m = xgb.XGBRegressor(**PARAMS).fit(T[FEATS], T['z'])
        S = T.sample(min(len(T), 5000), random_state=3)
        sv = shap.TreeExplainer(m).shap_values(S[FEATS])
        imp = pd.Series(np.abs(sv).mean(0), index=FEATS).sort_values(ascending=False)
        from scipy.stats import spearmanr
        dirn = {f: float(spearmanr(S[f], sv[:, i])[0]) for i, f in enumerate(FEATS)}
        summ['shap'][k] = imp.round(4).to_dict(); summ['direction'][k] = {f: round(v, 3) for f, v in dirn.items()}
        pd.DataFrame(sv, columns=FEATS).assign(**{f'x_{f}': S[f].values for f in FEATS}).to_csv(OUT / f'shap_{k}.csv', index=False)
        ale = {f: ale_1d(m, T.sample(min(len(T), 8000), random_state=4)[FEATS], f) for f in imp.index[:6]}
        json.dump(ale, open(OUT / f'ale_{k}.json', 'w'))
        print('shap', k, imp.head(8).round(3).to_dict(), flush=True)
    json.dump(summ, open(OUT / 'ml_summary.json', 'w'), indent=1, default=float)
