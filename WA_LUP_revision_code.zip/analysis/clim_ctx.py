"""Climate context per city from ERA5/ERA5-Land daily series (1991-2020): mean annual precipitation, dry-season
(Nov-Mar) and annual mean 2 m temperature, dry-season mean daily max temperature. Output res/clim/climate_context.json"""
import glob, json
import pandas as pd
from wc import D, RES, KEYS
out = {}
for k in KEYS:
    dd = {}
    for m in ['era5', 'era5_land']:
        fs = sorted(glob.glob(str(D / 'era5' / f'{k}_daily_{m}_*.csv')))
        d = pd.concat([pd.read_csv(f) for f in fs]).drop_duplicates('time'); d['time'] = pd.to_datetime(d['time'])
        dd[m] = d.set_index('time').sort_index()
    p = dd['era5']['precipitation_sum']; t = dd['era5_land']
    p = p[(p.index.year >= 1991) & (p.index.year <= 2020)]; t = t[(t.index.year >= 1991) & (t.index.year <= 2020)]
    dry = t.index.month.isin([11, 12, 1, 2, 3])
    pdry = p[p.index.month.isin([11, 12, 1, 2, 3])]
    out[k] = dict(P_annual_mm=round(float(p.groupby(p.index.year).sum().mean()), 0),
                  P_dry_season_mm=round(float(pdry.sum() / 30), 0),
                  T_annual=round(float(t['temperature_2m_mean'].mean()), 1),
                  T_dry_mean=round(float(t.loc[dry, 'temperature_2m_mean'].mean()), 1),
                  Tmax_dry=round(float(t.loc[dry, 'temperature_2m_max'].mean()), 1),
                  n_years=int(p.index.year.nunique()))
    print(k, out[k])
json.dump(out, open(RES / 'clim' / 'climate_context.json', 'w'), indent=1)
