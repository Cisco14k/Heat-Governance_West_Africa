"""Green-blue connectivity and cooling accessibility per city and period (30 m maps, inside the study boundary).

Cooling patches: contiguous (8-connected) forest or water pixels forming patches >= 2 ha (the InVEST park threshold);
green-blue land (CLR definition) = farmland/shrub + forest + water.
Metrics: number of cooling patches, mean patch area, largest patch index (LPI, % of boundary), patch cohesion
(Schumaker 1996), network connectivity (share of cooling-patch area in the largest cluster when patches closer than
100 m or 300 m are linked), cooling access (share of built-up pixels and of residents within 100, 200 and 300 m of a
cooling patch; also for the hottest quarter of built-up pixels), and the observed LST gradient of built-up pixels
with distance to the nearest cooling patch (exponential fit -> e-folding cooling distance).
Outputs res/conn/conn_metrics.json, res/conn/<key>_<ep>_gradient.csv
"""
import json, sys
import numpy as np, pandas as pd
from scipy import ndimage
from scipy.optimize import curve_fit
from wc import D, RES, KEYS, EPOCHS, YEAR, inside, read, composite

OUT = RES / 'conn'; OUT.mkdir(exist_ok=True)
PX = 30.0
MIN_PX = int(np.ceil(2e4 / PX ** 2))
ST8 = np.ones((3, 3), bool)


def patches(mask):
    lab, n = ndimage.label(mask, structure=ST8)
    if n == 0:
        return lab, np.array([]), mask & False
    sizes = ndimage.sum(mask, lab, index=np.arange(1, n + 1))
    keep = np.zeros(n + 1, bool); keep[1:] = sizes >= MIN_PX
    return lab, sizes[sizes >= MIN_PX], keep[lab]


def cohesion(mask, lab):
    """Patch cohesion index (%), perimeter in cell edges, area in cells."""
    m = mask.astype(np.int8)
    edges = (np.abs(np.diff(np.pad(m, 1), axis=0)).sum() + np.abs(np.diff(np.pad(m, 1), axis=1)).sum())
    n = lab.max()
    if n == 0:
        return np.nan
    a = ndimage.sum(mask, lab, index=np.arange(1, n + 1))
    # perimeter per patch: count exposed edges per labelled cell
    up = np.pad(m, 1)
    exposed = (4 - (up[:-2, 1:-1] + up[2:, 1:-1] + up[1:-1, :-2] + up[1:-1, 2:])) * m
    p = ndimage.sum(exposed, lab, index=np.arange(1, n + 1))
    Z = mask.size
    return float((1 - p.sum() / np.sum(p * np.sqrt(a))) / (1 - 1 / np.sqrt(Z)) * 100)


def network_share(cool, d_link):
    """Share of cooling-patch area in the largest cluster when patches within d_link (edge to edge) are linked."""
    r = int(round(d_link / 2 / PX))
    dil = ndimage.binary_dilation(cool, structure=np.hypot(*np.mgrid[-r:r + 1, -r:r + 1]) <= r) if r > 0 else cool
    lab, n = ndimage.label(dil, structure=ST8)
    if n == 0:
        return np.nan, 0
    area = ndimage.sum(cool, lab, index=np.arange(1, n + 1))
    return float(area.max() / max(area.sum(), 1)), int((area > 0).sum())


def expfit(d, y):
    try:
        f = lambda x, A, s, c: A * np.exp(-x / s) + c
        p, _ = curve_fit(f, d, y, p0=(-1.0, 150.0, 0.0), bounds=([-20, 10, -10], [0, 2000, 10]), maxfev=20000)
        return dict(A=float(p[0]), dstar=float(p[1]), c=float(p[2]))
    except Exception as e:
        return dict(error=str(e)[:80])


def run(key):
    ins = inside(key)
    popf = {ep: D / 'ref' / f'{key}_ghsl_pop_{y}.tif' for ep, y in [('B25', 2025), ('B15', 2015), ('E01', 2000)]}
    res = {}
    for ep in EPOCHS:
        L = read(RES / 'lulc' / f'{key}_{ep}_lulc.tif')[0][0]
        lst = composite(key, ep)['lst']
        coolraw = np.isin(L, [3, 4])
        lab, sizes, cool = patches(coolraw)
        coolin = cool & ins
        labin, nin = ndimage.label(coolin, structure=ST8)
        sz_in = ndimage.sum(coolin, labin, index=np.arange(1, nin + 1)) if nin else np.array([])
        sz_in = sz_in[sz_in >= MIN_PX]
        A = ins.sum()
        dist = ndimage.distance_transform_edt(~cool) * PX
        built = (L == 1) & ins
        hot = built & np.isfinite(lst) & (lst >= np.nanpercentile(lst[built], 75))
        p = read(popf[ep])[0][0] if ep in popf and popf[ep].exists() else None
        r = dict(n_cool_patches=int(len(sz_in)), cool_area_km2=round(float(sz_in.sum() * PX ** 2 / 1e6), 3),
                 cool_share=round(float(coolin.sum() / A), 4),
                 mean_patch_ha=round(float(sz_in.mean() * PX ** 2 / 1e4), 2) if len(sz_in) else 0.0,
                 lpi=round(float(sz_in.max() / A * 100), 3) if len(sz_in) else 0.0,
                 cohesion=round(cohesion(coolin, labin), 2) if nin else np.nan,
                 gb_share=round(float(np.isin(L[ins], [2, 3, 4]).mean()), 4))
        for dl in (100, 300):
            sh, nc = network_share(coolin, dl)
            r[f'net_largest_share_{dl}'] = round(sh, 3) if sh == sh else None
            r[f'n_clusters_{dl}'] = nc
        for dd in (100, 200, 300):
            r[f'built_within_{dd}'] = round(float((dist[built] <= dd).mean()), 4)
            r[f'hot_built_within_{dd}'] = round(float((dist[hot] <= dd).mean()), 4)
            if p is not None:
                w = np.nan_to_num(p[ins]); r[f'pop_within_{dd}'] = round(float(w[dist[ins] <= dd].sum() / max(w.sum(), 1)), 4)
        # observed LST gradient of built-up pixels with distance to the nearest cooling patch (0-900 m, 30 m bins)
        bins = np.arange(0, 930, 30)
        m = built & np.isfinite(lst) & (dist > 0) & (dist <= 900)
        ref = np.nanmean(lst[built & (dist > 600) & (dist <= 900)]) if (built & (dist > 600)).any() else np.nanmean(lst[m])
        idx = np.digitize(dist[m], bins) - 1
        g = pd.DataFrame(dict(b=idx, t=lst[m] - ref)).groupby('b')['t'].agg(['mean', 'count']).reset_index()
        g['d_mid'] = bins[g['b']] + 15
        g = g[g['count'] >= 30]
        g.to_csv(OUT / f'{key}_{ep}_gradient.csv', index=False)
        r['gradient'] = expfit(g['d_mid'].values, g['mean'].values) if len(g) >= 6 else {}
        r['dT_0_60'] = round(float(g.loc[g.d_mid <= 60, 'mean'].mean()), 3) if (g.d_mid <= 60).any() else None
        res[ep] = r
        print(key, ep, {k: v for k, v in r.items() if k != 'gradient'}, r['gradient'], flush=True)
    return res


if __name__ == '__main__':
    allr = json.load(open(OUT / 'conn_metrics.json')) if (OUT / 'conn_metrics.json').exists() else {}
    for k in [a for a in sys.argv[1:] if a in KEYS] or KEYS:
        allr[k] = run(k)
    json.dump(allr, open(OUT / 'conn_metrics.json', 'w'), indent=1, default=float)
