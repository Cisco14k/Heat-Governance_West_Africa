"""IBM/TRM surface-energy-balance attribution of the urban-rural surface temperature contrast per city and period.

120 m cells (4 x 4 Landsat pixels). Forcing: hourly ERA5-Land/ERA5 at the city centre interpolated to the overpass
time of every acquisition date of the composite (median over dates): 2 m air and dew-point temperature (ERA5-Land),
surface pressure, 10 m wind speed, cloud cover and shortwave radiation (ERA5; direct/diffuse split 0.8/0.2).
Surface: Landsat albedo (Liang 2001; OLI harmonised), NDVI, LST; GHSL built-up fraction (imperviousness for G and
emissivity, building plan area for roughness) and GHSL building height (2018); classified land-cover fractions for
tree cover and low-cover roughness. Balance and TRM attribution: seb_core (from the Heat6 implementation).
Urban cells: classified built-up >= 50 % inside the boundary; reference: persistent rural cells (as for SUHI).
Each urban cell is attributed against the effective state of the rural reference (exact Shapley decomposition);
reported: mean term values (K) and covariance contributions (Eq. 10) across urban cells.
Outputs res/seb/seb_summary.json
"""
import json, sys
import numpy as np, pandas as pd
from itertools import combinations
from math import factorial
from scipy import ndimage
from wc import D, RES, KEYS, EPOCHS, YEAR, GHSL_YEAR, AREAS, inside, read, composite, block_mean, block_frac
from lulc import ROY
from invest import liang_albedo
import seb_core as S
from scene_clim import era5

OUT = RES / 'seb'; OUT.mkdir(exist_ok=True)
F4 = 4


def cells(key, ep, L_all):
    ins = inside(key)
    L = L_all[ep]
    c = composite(key, ep)
    if ep in ('B15', 'B25'):
        for b, (s, i) in ROY.items():
            c[b] = c[b] * s + i
    with np.errstate(divide='ignore', invalid='ignore'):
        ndvi = (c['nir'] - c['red']) / (c['nir'] + c['red'])
    alb = liang_albedo(c)
    yr = GHSL_YEAR[ep]
    gh = read(D / 'ref' / f'{key}_ghsl_built_{yr}.tif')[0][0] / 1000.0
    hb = read(D / 'ref' / f'{key}_ghsl_hagb_2018.tif')[0][0] / 10.0
    dem = read(D / 'ref' / f'{key}_dem.tif')[0][0]
    gy, gx = np.gradient(dem, 30.0)
    slope = np.degrees(np.arctan(np.hypot(gx, gy)))
    asp = np.arctan2(-gx, gy)
    C = {f'{ep}_lst': block_mean(c['lst'], F4), f'{ep}_albedo': block_mean(alb, F4), f'{ep}_ndvi': block_mean(ndvi, F4),
         f'built_{ep}': block_mean(gh, F4), f'isa_{ep}': block_mean(gh, F4), 'wc_built': block_mean(gh, F4),
         'hagb_2018': block_mean(hb, F4), 'can_cover': block_frac(L == 3, F4) * 0.6, 'can_h': np.zeros_like(block_mean(gh, F4)),
         'wc_crop': block_frac(L == 2, F4), 'wc_bare': block_frac(L == 5, F4), 'wc_water': block_frac(L == 4, F4),
         'elev': block_mean(dem, F4), 'slope': block_mean(slope, F4),
         'asp_sin': block_mean(np.sin(asp), F4), 'asp_cos': block_mean(np.cos(asp), F4),
         'inside': block_frac(ins, F4), 'built_cls': block_frac(L == 1, F4)}
    rural = np.ones(L.shape, bool)
    for e in EPOCHS:
        rural &= np.isin(L_all[e], [2, 3])
    far = ndimage.distance_transform_edt(L_all['B25'] != 1) * 30.0 >= 1000
    C['rural'] = block_frac(rural & far, F4)
    return C


def forcing(key, ep):
    inv = pd.read_csv(D / 'landsat' / f'{key}_{ep}_scenes.csv')
    inv = inv[(inv.used == 1) & (inv.date_screen == 'kept')]
    E = era5(key)
    a = AREAS[key]
    rows = []
    for _, r in inv.iterrows():
        t = pd.Timestamp(f"{r['date']} {r['time_utc']}")
        t0 = t.floor('h'); t1 = t0 + pd.Timedelta(hours=1)
        if t0 not in E.index or t1 not in E.index:
            continue
        w = (t - t0).total_seconds() / 3600
        g = lambda c: float(E.loc[t0, c] * (1 - w) + E.loc[t1, c] * w)
        zen, az = S.solar_position(t.to_pydatetime(), a['lat'], a['lon'])
        sw = g('shortwave_radiation_era5')
        rows.append(dict(date=r['date'], temperature_2m=g('temperature_2m_era5_land'), dew_point_2m=g('dew_point_2m_era5_land'),
                         surface_pressure=g('surface_pressure_era5'), wind_speed_10m=g('wind_speed_10m_era5'),
                         cloud_cover=g('cloud_cover_era5'), shortwave_radiation=sw, direct_radiation=0.8 * sw,
                         diffuse_radiation=0.2 * sw, zenith=zen, azimuth=az))
    Fd = pd.DataFrame(rows)
    F = {k: float(Fd[k].median()) for k in Fd.columns if k != 'date'}
    F['grid_elevation'] = np.nan
    return F, Fd


def xhat_ibm(st, ctx):
    r0 = ctx['rho'] * S.CP * ctx['lam0']
    ra = np.maximum(st['ra'], 1.0)
    f = (r0 / ra) * (1 + 1 / np.maximum(st['beta'], 0.05))
    return ctx['lam0'] * (st['Rns'] - st['G']) / (1 + f)


def attribute_ibm(s1, s0):
    P = ['Rns', 'G', 'ra', 'beta']
    ctx = {v: 0.5 * (np.asarray(s1[v], float) + np.asarray(s0[v], float)) for v in ['lam0', 'rho']}
    cache = {}
    def v(Sx):
        k = frozenset(Sx)
        if k not in cache:
            cache[k] = xhat_ibm({p: (s1[p] if p in Sx else s0[p]) for p in P}, ctx)
        return cache[k]
    phi = {}
    n = len(P)
    for p in P:
        others = [q for q in P if q != p]; tot = 0.0
        for k in range(n):
            wgt = factorial(k) * factorial(n - k - 1) / factorial(n)
            for Sx in combinations(others, k):
                tot = tot + wgt * (v(set(Sx) | {p}) - v(set(Sx)))
        phi[p] = tot
    return dict(radiative=phi['Rns'], storage=phi['G'], aerodynamic=phi['ra'], evaporative=phi['beta'])


def run(key):
    L_all = {ep: read(RES / 'lulc' / f'{key}_{ep}_lulc.tif')[0][0] for ep in EPOCHS}
    out = {}
    for ep in EPOCHS:
        C = cells(key, ep, L_all)
        F, Fd = forcing(key, ep)
        B = S.balance(C, ep, F)
        urb = (C['built_cls'] >= 0.5) & (C['inside'] >= 0.75) & np.isfinite(B['X'])
        ref = (C['rural'] >= 0.9) & np.isfinite(B['X'])
        zc = np.nanmedian(C['elev'][urb]); ref &= np.abs(C['elev'] - zc) <= 50
        s0 = S.group_state(B, ref)
        s1 = {v: np.asarray(B[v], float)[urb] for v in S.VARS}
        T = S.attribute(s1, s0)
        dX = T['observed_dX']
        terms = {'radiative': T['radiative'], 'aerodynamic': T['aerodynamic'] + T['closure'],
                 'surface_resistance': T['surface_resistance'], 'storage': T['storage']}
        # IBM: beta = H / LE per cell; reference beta from the effective state
        H = B['H']; LE = B['LE']
        beta = np.clip(H / np.maximum(LE, 1.0), 0.05, 50)
        s1i = dict(Rns=B['Rns'][urb], G=B['G'][urb], ra=B['ra'][urb], beta=beta[urb], lam0=B['lam0'][urb], rho=B['rho'][urb])
        H0 = s0['rho'] * S.CP * s0['X'] / s0['ra']
        LE0 = s0['Rns'] - s0['G'] - s0['X'] / s0['lam0'] - H0
        s0i = dict(Rns=s0['Rns'], G=s0['G'], ra=s0['ra'], beta=float(np.clip(H0 / max(LE0, 1.0), 0.05, 50)), lam0=s0['lam0'], rho=s0['rho'])
        Ti = attribute_ibm(s1i, s0i)
        def cov_share(t):
            return float(np.cov(t, dX)[0, 1] / np.var(dX, ddof=1) * 100)
        rec = dict(n_urban=int(urb.sum()), n_ref=int(ref.sum()), forcing=F, n_dates=int(len(Fd)),
                   dX_mean=float(np.mean(dX)), residual_mean=float(np.mean(T['residual'])),
                   adj_share_urban=float(np.mean(B['adj'][urb])), adj_share_ref=float(np.mean(B['adj'][ref])),
                   trm_mean={k: float(np.mean(v)) for k, v in terms.items()},
                   trm_cov={k: cov_share(v) for k, v in terms.items()},
                   ibm_mean={k: float(np.mean(v)) for k, v in Ti.items()},
                   ibm_cov={k: cov_share(v) for k, v in Ti.items()},
                   state_urban={k: float(np.nanmean(np.asarray(B[k])[urb])) for k in ['Rns', 'G', 'H', 'LE', 'ra', 'rs', 'alb', 'X']},
                   state_ref={k: float(np.nanmean(np.asarray(B[k])[ref])) for k in ['Rns', 'G', 'H', 'LE', 'ra', 'rs', 'alb', 'X']},
                   beta_urban=float(np.median(beta[urb])), beta_ref=s0i['beta'])
        out[ep] = rec
        print(key, ep, 'dX', round(rec['dX_mean'], 2), 'TRM', {k: round(v, 2) for k, v in rec['trm_mean'].items()},
              'IBM', {k: round(v, 2) for k, v in rec['ibm_mean'].items()}, 'cov', {k: round(v) for k, v in rec['trm_cov'].items()}, flush=True)
    return out


if __name__ == '__main__':
    allr = json.load(open(OUT / 'seb_summary.json')) if (OUT / 'seb_summary.json').exists() else {}
    for k in [a for a in sys.argv[1:] if a in KEYS] or KEYS:
        allr[k] = run(k)
        json.dump(allr, open(OUT / 'seb_summary.json', 'w'), indent=1, default=float)
