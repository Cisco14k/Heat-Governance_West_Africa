"""Five-class land-cover classification of the 30 m dry-season composites (Random Forest per city and period) with
reference labels migrated from ESA WorldCover 2021, constrained by GHSL built-up fractions and JRC GSW water history;
spatial-block accuracy assessment and area-adjusted (Olofsson et al. 2014) estimates.
Usage: python lulc.py WA_OUA [WA_ABJ ...]
Outputs: res/lulc/<key>_<ep>_lulc.tif (uint8 1..5, 0 = no data), res/lulc/<key>_accuracy.json, res/lulc/<key>_samples.csv
"""
import sys, json, time
import numpy as np, pandas as pd
from scipy import ndimage
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GroupKFold
from sklearn.metrics import confusion_matrix, cohen_kappa_score
from wc import D, RES, KEYS, EPOCHS, YEAR, GHSL_YEAR, CLASSES, grid, inside, read, composite, save_tif

OUT = RES / 'lulc'; OUT.mkdir(exist_ok=True)
RNG = np.random.default_rng(42)
# Roy et al. (2016) OLS transformation of OLI surface reflectance to ETM+ (blue, green, red, nir, swir1, swir2)
ROY = {'blue': (0.8474, 0.0003), 'green': (0.8483, 0.0088), 'red': (0.9047, 0.0061),
       'nir': (0.8462, 0.0412), 'swir1': (0.8937, 0.0254), 'swir2': (0.9071, 0.0172)}
OLI = {'B15', 'B25'}
SRB = ['blue', 'green', 'red', 'nir', 'swir1', 'swir2']
WC_ORDER = ['tree', 'shrub', 'grass', 'crop', 'built', 'bare', 'snow', 'water', 'wetland', 'mangrove', 'moss']
WC2C = {'built': 1, 'shrub': 2, 'grass': 2, 'crop': 2, 'wetland': 2, 'moss': 2, 'tree': 3, 'mangrove': 3,
        'water': 4, 'bare': 5}
N_PER_CLASS = 3000
BLOCK = 3000.0      # m, spatial blocks for cross-validation


def nd(a, b):
    with np.errstate(divide='ignore', invalid='ignore'):
        return (a - b) / (a + b)


def features(key, ep):
    c = composite(key, ep)
    sr = {}
    for b in SRB:
        x = c[b]
        if ep in OLI:
            s, i = ROY[b]; x = x * s + i
        sr[b] = x
    F = dict(sr)
    F['ndvi'] = nd(sr['nir'], sr['red'])
    F['ndbi'] = nd(sr['swir1'], sr['nir'])
    F['mndwi'] = nd(sr['green'], sr['swir1'])
    with np.errstate(divide='ignore', invalid='ignore'):
        F['bsi'] = ((sr['swir1'] + sr['red']) - (sr['nir'] + sr['blue'])) / ((sr['swir1'] + sr['red']) + (sr['nir'] + sr['blue']))
    v = np.nan_to_num(F['ndvi'], nan=0.0)
    m1 = ndimage.uniform_filter(v, 3); m2 = ndimage.uniform_filter(v * v, 3)
    F['ndvi_m3'] = m1; F['ndvi_sd3'] = np.sqrt(np.maximum(m2 - m1 * m1, 0))
    valid = np.all([np.isfinite(sr[b]) for b in SRB], axis=0)
    for k in F:
        F[k] = np.where(valid, F[k], np.nan).astype(np.float32)
    return F, valid, c


FEATS = SRB + ['ndvi', 'ndbi', 'mndwi', 'bsi', 'ndvi_m3', 'ndvi_sd3']


def reference(key):
    wc, _, _ = read(D / 'ref' / f'{key}_worldcover2021_counts.tif')          # 11 x H x W counts of 9
    cnt = np.zeros((6,) + wc.shape[1:], np.uint8)
    for i, n in enumerate(WC_ORDER):
        if n in WC2C:
            cnt[WC2C[n]] += wc[i]
    lab = cnt.argmax(0).astype(np.uint8); pur = cnt.max(0)
    lab[pur < 7] = 0                                   # >= 7 of 9 10 m sub-pixels of one class
    gsw, _, gdesc = read(D / 'ref' / f'{key}_gsw.tif')
    gs = {n: gsw[i] for i, n in enumerate(gdesc)}
    ghsl = {}
    for e in [1990, 2000, 2015, 2020]:
        f = D / 'ref' / f'{key}_ghsl_built_{e}.tif'
        if f.exists():
            ghsl[e] = read(f)[0][0].astype(np.float32) / 1000.0
    return lab, gs, ghsl


def labels_for_epoch(key, ep, lab25, gs, ghsl, F, F25):
    y = YEAR[ep]
    lab = lab25.copy()
    occ = gs.get('occurrence', np.full(lab.shape, 255, np.uint8)).astype(np.int16)
    tr = gs.get('transitions', np.zeros(lab.shape, np.uint8))
    occ[occ == 255] = 0
    early = ep in ('E88', 'E01')
    water_ok = (occ >= 70) & (np.isin(tr, [1, 3, 8]) if early else np.isin(tr, [1, 2, 7]))
    lab[(lab == 4) & ~water_ok] = 0
    lab[water_ok & (lab == 0)] = 4
    gy = ghsl.get(GHSL_YEAR[ep]) if ghsl else None
    if gy is not None:
        lab[(lab == 1) & (gy < 0.30)] = 0             # built-up label needs GHSL built-up in that period
        lab[np.isin(lab, [2, 3, 5]) & (gy > 0.05)] = 0  # natural labels need (almost) no GHSL built-up
    lab[~np.isfinite(F['ndvi'])] = 0
    if ep != 'B25':
        # spectral-stability screen against the 2024-2026 composite (harmonised indices): keep the most stable half
        z = []
        for k in ['ndvi', 'ndbi', 'mndwi', 'bsi']:
            d = F[k] - F25[k]
            s = np.nanpercentile(np.abs(d[lab > 0]), 50) + 1e-6
            z.append((d / s) ** 2)
        chg = np.sqrt(np.nansum(z, axis=0))
        for c in range(1, 6):
            m = lab == c
            if m.sum() > 50:
                thr = np.nanpercentile(chg[m], 50)
                lab[m & ~(chg <= thr)] = 0
    # within-period outlier screen: Mahalanobis distance to the class centroid (chi2 0.95, 4 dof = 9.49)
    X = np.stack([F[k] for k in ['ndvi', 'ndbi', 'mndwi', 'bsi']], -1)
    for c in range(1, 6):
        m = lab == c
        if m.sum() < 100:
            continue
        xs = X[m]; mu = np.nanmean(xs, 0); cov = np.cov(xs[np.all(np.isfinite(xs), 1)].T) + np.eye(4) * 1e-6
        ic = np.linalg.inv(cov); dd = np.einsum('ij,jk,ik->i', xs - mu, ic, xs - mu)
        bad = ~(dd <= 9.49)
        idx = np.flatnonzero(m.ravel())
        lab.ravel()[idx[bad]] = 0
    return lab


def sample(lab, key, n=N_PER_CLASS):
    g = grid(key, 30.0)
    H, W = lab.shape
    rows, cols = np.indices((H, W))
    bpx = int(BLOCK // 30)
    blk = (rows // bpx) * (W // bpx + 1) + (cols // bpx)
    idx = []
    for c in range(1, 6):
        ii = np.flatnonzero(lab.ravel() == c)
        if len(ii) == 0:
            continue
        # spread across blocks: at most n / n_blocks + 5 per block
        b = blk.ravel()[ii]
        ub, inv = np.unique(b, return_inverse=True)
        cap = max(5, int(np.ceil(n / len(ub))) + 5)
        RNG.shuffle(order := np.arange(len(ii)))
        take, cnt = [], np.zeros(len(ub), int)
        for o in order:
            if cnt[inv[o]] < cap:
                take.append(ii[o]); cnt[inv[o]] += 1
            if len(take) >= n:
                break
        idx += take
    idx = np.array(idx)
    return idx, blk.ravel()[idx]


def majority3(cls):
    """3 x 3 majority filter (ties keep the centre class); 0 = no data is ignored."""
    cnt = np.stack([ndimage.uniform_filter((cls == c).astype(np.float32), 3) for c in range(1, 6)])
    best = cnt.argmax(0) + 1
    centre_ok = np.take_along_axis(cnt, (np.clip(cls, 1, 5) - 1)[None].astype(int), 0)[0] >= cnt.max(0) - 1e-6
    out = np.where(centre_ok, cls, best).astype(np.uint8)
    out[cls == 0] = 0
    return out


def olofsson(cm, w):
    """Area-adjusted proportions and 95% CI (Olofsson et al. 2014); cm rows = map class, cols = reference."""
    n_i = cm.sum(1, keepdims=True).astype(float)
    p = np.where(n_i > 0, w[:, None] * cm / np.maximum(n_i, 1), 0)
    prop = p.sum(0)
    se = np.sqrt(np.nansum(np.where(n_i > 1, (w[:, None] ** 2) * (cm / np.maximum(n_i, 1)) *
                                    (1 - cm / np.maximum(n_i, 1)) / np.maximum(n_i - 1, 1), 0), axis=0))
    ua = np.diag(cm) / np.maximum(cm.sum(1), 1); pa = np.diag(p) / np.maximum(prop, 1e-12)
    oa = np.diag(p).sum()
    return prop, 1.96 * se, ua, pa, oa


def run(key, eps=EPOCHS):
    t0 = time.time()
    ins = inside(key)
    lab25, gs, ghsl = reference(key)
    F25, v25, _ = features(key, 'B25')
    acc = {}
    rows = []
    for ep in eps:
        F, valid, c = (F25, v25, None) if ep == 'B25' else features(key, ep)
        lab = labels_for_epoch(key, ep, lab25, gs, ghsl, F, F25)
        idx, blk = sample(lab, key)
        X = np.stack([F[k].ravel()[idx] for k in FEATS], 1); y = lab.ravel()[idx]
        ok = np.all(np.isfinite(X), 1); X, y, blk, idx = X[ok], y[ok], blk[ok], idx[ok]
        # spatial-block cross-validation
        pred = np.zeros_like(y)
        gkf = GroupKFold(n_splits=5)
        for tr_, te_ in gkf.split(X, y, blk):
            rf = RandomForestClassifier(n_estimators=150, max_features='sqrt', min_samples_leaf=2, n_jobs=2,
                                        random_state=1).fit(X[tr_], y[tr_])
            pred[te_] = rf.predict(X[te_])
        rf = RandomForestClassifier(n_estimators=200, max_features='sqrt', min_samples_leaf=2, n_jobs=2,
                                    random_state=1).fit(X, y)
        # predict the whole window in strips
        H, W = lab.shape
        cls = np.zeros((H, W), np.uint8)
        for r0 in range(0, H, 400):
            Xs = np.stack([F[k][r0:r0 + 400].ravel() for k in FEATS], 1)
            m = np.all(np.isfinite(Xs), 1)
            out = np.zeros(len(Xs), np.uint8)
            if m.any():
                out[m] = rf.predict(Xs[m])
            cls[r0:r0 + 400] = out.reshape(-1, W)
        cls = majority3(cls)
        save_tif(OUT / f'{key}_{ep}_lulc.tif', cls, key, 30.0, 'uint8', nodata=0)
        save_tif(OUT / f'{key}_{ep}_lulc_raw.tif', cls, key, 30.0, 'uint8', nodata=0)
        np.savez_compressed(OUT / f'{key}_{ep}_cv.npz', idx=idx, y=y, pred=pred, blk=blk)
        labs = [c_ for c_ in range(1, 6) if (y == c_).any()]
        cm = confusion_matrix(y, pred, labels=list(range(1, 6)))          # rows = reference, cols = map
        # strata weights: mapped class shares inside the study boundary
        w = np.array([(cls[ins] == c_).mean() for c_ in range(1, 6)])
        w = w / w.sum()
        prop, ci, ua, pa, oa_w = olofsson(cm.T, w)                         # rows = map class
        oa = float(np.trace(cm) / cm.sum()); kap = float(cohen_kappa_score(y, pred))
        area_km2 = ins.sum() * 900 / 1e6
        acc[ep] = dict(n_samples=int(len(y)), n_per_class={CLASSES[c_ - 1]: int((y == c_).sum()) for c_ in range(1, 6)},
                       oa=round(oa, 4), kappa=round(kap, 4), oa_area_weighted=round(float(oa_w), 4),
                       ua={CLASSES[i]: round(float(ua[i]), 3) for i in range(5)},
                       pa={CLASSES[i]: round(float(pa[i]), 3) for i in range(5)},
                       map_share={CLASSES[i]: round(float(w[i]), 4) for i in range(5)},
                       adj_share={CLASSES[i]: round(float(prop[i]), 4) for i in range(5)},
                       adj_ci95={CLASSES[i]: round(float(ci[i]), 4) for i in range(5)},
                       map_km2={CLASSES[i]: round(float(w[i] * area_km2), 2) for i in range(5)},
                       adj_km2={CLASSES[i]: round(float(prop[i] * area_km2), 2) for i in range(5)},
                       adj_ci95_km2={CLASSES[i]: round(float(ci[i] * area_km2), 2) for i in range(5)},
                       cm=cm.tolist(), nodata_inside=round(float((cls[ins] == 0).mean()), 5),
                       importance=dict(zip(FEATS, np.round(rf.feature_importances_, 4).tolist())))
        for c_ in range(1, 6):
            rows.append(dict(key=key, ep=ep, cls=CLASSES[c_ - 1], n_labels=int((lab == c_).sum()), n_sample=int((y == c_).sum())))
        print(f'{key} {ep}: OA {oa:.3f} kappa {kap:.3f} built {w[0]:.3f} n={len(y)} ({time.time() - t0:.0f}s)', flush=True)
        del F
    old = json.load(open(OUT / f'{key}_accuracy.json')) if (OUT / f'{key}_accuracy.json').exists() else {}
    old.update(acc)
    json.dump(old, open(OUT / f'{key}_accuracy.json', 'w'), indent=1)
    pd.DataFrame(rows).to_csv(OUT / f'{key}_samples.csv', index=False)


if __name__ == '__main__':
    eps = [a for a in sys.argv[1:] if a in EPOCHS] or EPOCHS
    for k in [a for a in sys.argv[1:] if a in KEYS] or KEYS:
        run(k, eps)
