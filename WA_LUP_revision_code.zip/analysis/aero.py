"""Aerodynamic field of a city-region at 120 m: roughness length and displacement height of buildings and trees,
heat-transfer roughness, and the aerodynamic resistance to heat transfer at the Landsat overpass.

Morphometric roughness (Macdonald et al. 1998, staggered arrays, A = 4.43, beta = 1, Cd = 1.2) of the combined
building and tree elements (vegetation included through its aerodynamic porosity, Kent et al. 2017):
  lambda_p = lp_b + (1 - P) lp_v,  lambda_f = lp_b H_b / W_b + (1 - P) lp_v h_v / W_v,
  H_av = (lp_b H_b + (1 - P) lp_v h_v) / lambda_p
  zd = H_av [1 + A^-lambda_p (lambda_p - 1)],  z0m = H_av (1 - zd/H_av) exp{-[0.5 beta Cd k^-2 (1 - zd/H_av) lambda_f]^-1/2}
  lp_b = GHSL built-up fraction, H_b = BUILT_V / BUILT_S (epoch), lp_v = Landsat canopy cover (epoch), h_v = CHM height
Low cover (WorldCover classes without buildings and trees): log-mean of class roughness lengths; z0m = max(element, low).
Heat roughness z0h = z0m exp(-kB^-1): kB^-1 = 1.29 Re*^1/4 - 2 for buildings (Kanda et al. 2007), 2.46 Re*^1/4 - 2 for
bare soil (Brutsaert 1982), 2 for vegetation; area-weighted.
ra = [ln((zr - zd)/z0m) - psi_m][ln((zr - zd)/z0h) - psi_h] / (k^2 U_r), Monin-Obukhov stability iterated with
H = rho cp (Ts - Tb)/ra (Paulson 1970 / Businger-Dyer, -5 <= zeta <= 1); zr = 100 m above ground, U_r from the ERA5
10 m wind (neutral log profile over z0 = 0.1 m), floor 1 m/s.
"""
import numpy as np

KAPPA, G0, NU, CP = 0.4, 9.81, 1.5e-5, 1005.0
DEFAULT = dict(W_b=20.0, P_veg=0.5, A=4.43, beta=1.0, Cd=1.2, zr=100.0, z0_reg=0.1, umin=1.0, kb_veg=2.0,
               H_default=6.0, morph="macdonald", kb_bluff_scale=1.0, kb_uniform=None)
Z0_LOW = {"shrub": 0.10, "grass": 0.03, "crop": 0.06, "bare": 0.005, "snow_ice": 0.001, "water": 0.0002,
          "herb_wetland": 0.03, "moss_lichen": 0.01}


def roughness(C, ep, prm=None):
    p = dict(DEFAULT, **(prm or {}))
    lpb = np.clip(np.nan_to_num(C[f"built_{ep}"]), 0, 0.9)
    Hb = np.nan_to_num(C.get(f"hb_{ep}", np.zeros_like(lpb)))
    if "hagb_2018" in C:
        Hb = np.where(Hb > 0, Hb, np.nan_to_num(C["hagb_2018"]))
    Hb = np.where(lpb > 0.005, np.where(Hb > 0, Hb, p["H_default"]), 0.0)
    Hb = np.clip(Hb, 3.0, 200.0) * (lpb > 0.005)
    lpv = np.clip(np.nan_to_num(C.get(f"canopy_{ep}", C["can_cover"])), 0, 1)
    lpv = np.minimum(lpv, 1.0 - lpb)
    hv = np.nan_to_num(C["can_h"])
    med_h = np.nanmedian(hv[(hv >= 2) & (np.nan_to_num(C["can_cover"]) > 0.3)]) if ((hv >= 2) & (np.nan_to_num(C["can_cover"]) > 0.3)).any() else 10.0
    hv = np.where(hv >= 2, hv, med_h) * (lpv > 0.01)
    P = p["P_veg"]
    Wv = 0.5 * hv + 2.0
    lam_p = lpb + (1 - P) * lpv
    lam_f = lpb * Hb / p["W_b"] + (1 - P) * lpv * hv / np.maximum(Wv, 1.0)
    with np.errstate(invalid="ignore", divide="ignore"):
        Hav = np.where(lam_p > 1e-4, (lpb * Hb + (1 - P) * lpv * hv) / np.maximum(lam_p, 1e-4), 0.0)
    if p["morph"] == "rot":                                  # rule of thumb (Grimmond & Oke 1999)
        zd = 0.7 * Hav * (lam_p > 0.01)
        z0e = 0.1 * Hav * (lam_p > 0.01)
    else:
        lp = np.clip(lam_p, 1e-4, 0.95)
        zd = Hav * (1 + p["A"] ** (-lp) * (lp - 1))
        rel = np.clip(1 - zd / np.maximum(Hav, 1e-3), 1e-4, 1)
        arg = 0.5 * p["beta"] * p["Cd"] / KAPPA ** 2 * rel * np.maximum(lam_f, 1e-6)
        z0e = Hav * rel * np.exp(-arg ** -0.5)
        zd = np.where(lam_p > 1e-3, zd, 0.0); z0e = np.where(lam_p > 1e-3, z0e, 0.0)
    # low (non-element) cover from WorldCover class fractions, log-mean
    num = np.zeros_like(lpb); den = np.zeros_like(lpb)
    for c, z in Z0_LOW.items():
        f = np.nan_to_num(C.get(f"wc_{c}", np.zeros_like(lpb)))
        num += f * np.log(z); den += f
    z0s = np.where(den > 0.05, np.exp(num / np.maximum(den, 1e-6)), 0.03)
    elem = z0e > z0s
    z0m = np.where(elem, z0e, z0s)
    zd = np.where(elem, zd, 0.0)
    # weights of the heat-transfer (kB^-1) regimes
    wb = np.where(elem, lpb / np.maximum(lpb + (1 - P) * lpv, 1e-6), 0.0)
    fbare = np.nan_to_num(C.get("wc_bare", np.zeros_like(lpb))) + np.nan_to_num(C.get("wc_snow_ice", np.zeros_like(lpb)))
    wbare = np.where(elem, 0.0, np.clip(fbare / np.maximum(den, 1e-6), 0, 1))
    wveg = np.clip(1 - wb - wbare, 0, 1)
    return dict(z0m=z0m.astype(np.float32), zd=zd.astype(np.float32), lam_p=lam_p.astype(np.float32),
                lam_f=lam_f.astype(np.float32), Hav=Hav.astype(np.float32), z0_low=z0s.astype(np.float32),
                w_bluff=wb.astype(np.float32), w_bare=wbare.astype(np.float32), w_veg=wveg.astype(np.float32),
                Hb=Hb.astype(np.float32), hv=hv.astype(np.float32))


def psi_unstable(zeta):
    x = (1 - 16 * zeta) ** 0.25
    pm = 2 * np.log((1 + x) / 2) + np.log((1 + x * x) / 2) - 2 * np.arctan(x) + np.pi / 2
    ph = 2 * np.log((1 + x * x) / 2)
    return pm, ph


def psi(zeta):
    zu = np.minimum(zeta, 0)
    pm_u, ph_u = psi_unstable(zu)
    zs = np.clip(zeta, 0, 1)
    pm = np.where(zeta < 0, pm_u, -5 * zs)
    ph = np.where(zeta < 0, ph_u, -5 * zs)
    return pm, ph


def resistance(R, U10, Ts, Tb, rho, prm=None, n_iter=12):
    """Aerodynamic resistance to heat transfer (s m-1) with stability, plus u*, kB^-1 and z0h."""
    p = dict(DEFAULT, **(prm or {}))
    z0m, zd = R["z0m"].astype(np.float64), R["zd"].astype(np.float64)
    zr = np.maximum(p["zr"], zd + 10 * z0m + 5.0)
    Ur = max(U10 * np.log(p["zr"] / p["z0_reg"]) / np.log(10.0 / p["z0_reg"]), p["umin"])
    lm = np.log((zr - zd) / z0m)
    pm = np.zeros_like(z0m); ph = np.zeros_like(z0m)
    dT = Ts - Tb
    for _ in range(n_iter):
        ust = KAPPA * Ur / np.maximum(lm - pm, 0.5)
        Re = ust * z0m / NU
        kb = (R["w_bluff"] * p["kb_bluff_scale"] * (1.29 * Re ** 0.25 - 2) + R["w_bare"] * (2.46 * Re ** 0.25 - 2)
              + R["w_veg"] * p["kb_veg"])
        if p["kb_uniform"] is not None:                       # sensitivity: one kB^-1 for every surface
            kb = np.full_like(kb, p["kb_uniform"])
        kb = np.clip(kb, 0.0, 25.0)
        z0h = z0m * np.exp(-kb)
        lh = np.log((zr - zd) / z0h)
        ra = np.maximum(lm - pm, 0.5) * np.maximum(lh - ph, 0.5) / (KAPPA ** 2 * Ur)
        ra = np.clip(ra, 2.0, 1000.0)
        H = rho * CP * dT / ra
        with np.errstate(divide="ignore", invalid="ignore"):
            L = -rho * CP * Tb * ust ** 3 / (KAPPA * G0 * np.where(np.abs(H) < 1e-3, 1e-3, H))
        zeta = np.clip((zr - zd) / L, -5.0, 1.0)
        pm_n, ph_n = psi(zeta)
        pm = 0.5 * pm + 0.5 * pm_n; ph = 0.5 * ph + 0.5 * ph_n
    return dict(ra=ra.astype(np.float32), ustar=ust.astype(np.float32), kb=kb.astype(np.float32),
                z0h=z0h.astype(np.float32), zeta=zeta.astype(np.float32), U_ref=np.float32(Ur))
