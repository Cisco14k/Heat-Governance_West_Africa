"""Reassemble staged parts (uploads/.../out/wa/_parts/<sub>/<name>.partNNN + .sha256) into /home/claude/heat/data/<sub>/."""
import hashlib, sys, shutil
from pathlib import Path
UP = Path('/mnt/user-data/uploads/Continental and global UHIs/heat6_pipeline/pc/out/wa')
D = Path('/home/claude/heat/data')
done, missing = [], []
for m in sorted((UP / '_parts').rglob('*.sha256')):
    sub = m.parent.name; name = m.name[:-7]
    h, n, size = m.read_text().split()
    n = int(n); size = int(size)
    dst = D / sub / name
    if dst.exists() and dst.stat().st_size == size:
        continue
    parts = [m.parent / f'{name}.part{i:03d}' for i in range(n)]
    if not all(p.exists() for p in parts):
        missing.append(f'{sub}/{name} ({sum(p.exists() for p in parts)}/{n})'); continue
    dst.parent.mkdir(parents=True, exist_ok=True)
    hh = hashlib.sha256()
    with open(dst, 'wb') as out:
        for p in parts:
            b = p.read_bytes(); hh.update(b); out.write(b)
    if hh.hexdigest() != h:
        dst.unlink(); missing.append(f'{sub}/{name} (checksum)'); continue
    done.append(f'{sub}/{name}')
# small files staged directly (json/csv) and directly staged tifs
for f in list(UP.rglob('*.json')) + list(UP.rglob('*.csv')) + list(UP.rglob('*.tif')):
    if '_parts' in f.parts or f.name.startswith('_'):
        continue
    rel = f.relative_to(UP); dst = D / rel
    if not dst.exists() or dst.stat().st_size != f.stat().st_size:
        dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(f, dst); done.append(str(rel))
print('assembled/copied:', len(done), done[:40]); print('incomplete:', missing)
