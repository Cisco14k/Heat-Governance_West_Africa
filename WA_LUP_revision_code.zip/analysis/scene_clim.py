"""Scene-level LST and SUHI (1990-2026 dry seasons) versus ERA5-Land/ERA5 background meteorology.

For every scene of the archive (240 m cells, mean of clear 60 m sub-pixels):
  LST_city  = mean LST of land cells inside the boundary (>= 12/16 clear; >= 40 % of the land cells observed)
  SUHI_core = mean LST of the persistent urban core (built-up >= 50 % in all four periods, inside the boundary)
              minus mean LST of the persistent rural reference (farmland/shrub or forest in all four periods,
              >= 90 % of the cell, >= 1 km from 2025 built-up, elevation within +-50 m of the core median)
  SUHI_dyn  = as SUHI_core but with the built-up cells of the nearest benchmark period (expanding urban zone)
Meteorology at the overpass (linear interpolation of hourly values): T2m, soil moisture 0-7 cm (ERA5-Land),
shortwave radiation, wind speed 10 m, VPD (ERA5), 30-day antecedent precipitation (ERA5).
Models (OLS, HC3 errors): Y = met + seasonality (+ year) ; outputs res/clim/<key>_scenes.csv, res/clim/clim_summary.json
"""
import sys, json, glob, datetime as dt
import numpy as np, pandas as pd, rasterio
import statsmodels.api as sm
from scipy import ndimage
from wc import D, RES, KEYS, EPOCHS, YEAR, grid, inside, read

OUT = RES / 'clim'; OUT.mkdir(exist_ok=True)
WIN = {'E88': range(1986, 1992), 'E01': range(2000, 2004), 'B15': range(2014, 2017), 'B25': range(2024, 2027)}


def era5(key):
    e = []
    for model in ['era5_land', 'era5']:
        fs = sorted(glob.glob(str(D / 'era5' / f'{key}_hourly_{model}_*.csv')))
        d = pd.concat([pd.read_csv(f) for f in fs]).drop_duplicates('time')
        d['time'] = pd.to_datetime(d['time']); d = d.set_index('time').sort_index()
        d = d.drop(columns=[c for c in d.columns if c.startswith('grid_')])
        d.columns = [f'{c}_{model}' for c in d.columns]
        e.append(d)
    E = e[0].join(e[1], how='outer')
    return E


def masks(key, f=8):
    """240 m masks from the 30 m land-cover maps (fractions over 8 x 8 blocks)."""
    L = {ep: read(RES / 'lulc' / f'{key}_{ep}_lulc.tif')[0][0] for ep in EPOCHS}
    ins = inside(key)
    H, W = (L['B25'].shape[0] // f) * f, (L['B25'].shape[1] // f) * f
    def frac(m):
        return m[:H, :W].reshape(H // f, f, W // f, f).mean(axis=(1, 3))
    built = {ep: frac(L[ep] == 1) for ep in EPOCHS}
    rural_all = np.ones_like(built['B25'])
    for ep in EPOCHS:
        rural_all = np.minimum(rural_all, frac(np.isin(L[ep], [2, 3])))
    water = frac(L['B25'] == 4)
    insf = frac(ins)
    dem = read(D / 'ref' / f'{key}_dem.tif')[0][0]
    demf = np.nanmean(dem[:H, :W].reshape(H // f, f, W // f, f), axis=(1, 3))
    core = (np.min([built[ep] for ep in EPOCHS], axis=0) >= 0.5) & (insf >= 0.5)
    dist_b = ndimage.distance_transform_edt(~(built['B25'] >= 0.25)) * 240.0
    zc = np.nanmedian(demf[core]) if core.any() else np.nanmedian(demf[insf >= 0.5])
    ref = (rural_all >= 0.9) & (dist_b >= 1000) & (np.abs(demf - zc) <= 50) & (water < 0.1)
    land_in = (insf >= 0.5) & (water < 0.5)
    dyn = {ep: (built[ep] >= 0.5) & (insf >= 0.5) for ep in EPOCHS}
    return dict(core=core, ref=ref, land_in=land_in, dyn=dyn, n_core=int(core.sum()), n_ref=int(ref.sum()),
                n_land=int(land_in.sum()), zc=float(zc))


def nearest_ep(year):
    return min(EPOCHS, key=lambda e: abs(YEAR[e] - year))


def scene_table(key):
    inv = pd.read_csv(D / 'scenes' / f'{key}_scenes.csv')
    inv = inv[inv.written == 1].copy()
    M = masks(key)
    rows = []
    for _, r in inv.iterrows():
        f = D / 'scenes' / key / f"{key}_{r['key']}.tif"
        if not f.exists():
            continue
        a = rasterio.open(f).read()
        lst = a[0].astype(np.float32) / 100; cnt = a[1]
        H, W = M['core'].shape
        lst = lst[:H, :W]; cnt = cnt[:H, :W]
        ok = (cnt >= 12) & (a[0][:H, :W] > -32768)
        rec = dict(key=r['key'], date=r['date'], time_utc=r['time_utc'], platform=r['platform'], season=r['season'])
        for nm, m in [('city', M['land_in']), ('core', M['core']), ('ref', M['ref']),
                      ('dyn', M['dyn'][nearest_ep(int(r['date'][:4]) + (1 if int(r['date'][5:7]) >= 11 else 0))])]:
            cov = (ok & m).sum() / max(m.sum(), 1)
            rec[f'cov_{nm}'] = cov
            rec[f'lst_{nm}'] = float(np.mean(lst[ok & m])) if cov > 0 else np.nan
        rows.append(rec)
    S = pd.DataFrame(rows)
    S['dt'] = pd.to_datetime(S['date'] + ' ' + S['time_utc'])
    S['LST_city'] = np.where(S.cov_city >= 0.4, S.lst_city, np.nan)
    S['SUHI_core'] = np.where((S.cov_core >= 0.4) & (S.cov_ref >= 0.4), S.lst_core - S.lst_ref, np.nan)
    S['SUHI_dyn'] = np.where((S.cov_dyn >= 0.4) & (S.cov_ref >= 0.4), S.lst_dyn - S.lst_ref, np.nan)
    # meteorology
    E = era5(key)
    def at(t, col):
        s = E[col]; t0 = t.floor('h'); t1 = t0 + pd.Timedelta(hours=1)
        if t0 not in s.index or t1 not in s.index:
            return np.nan
        w = (t - t0).total_seconds() / 3600
        return float(s[t0] * (1 - w) + s[t1] * w)
    cols = {'T2m': 'temperature_2m_era5_land', 'Td': 'dew_point_2m_era5_land', 'SM1': 'soil_moisture_0_to_7cm_era5_land',
            'SM2': 'soil_moisture_7_to_28cm_era5_land', 'SW': 'shortwave_radiation_era5', 'WS': 'wind_speed_10m_era5',
            'VPD': 'vapour_pressure_deficit_era5', 'CC': 'cloud_cover_era5'}
    for k, c in cols.items():
        S[k] = [at(t, c) if c in E.columns else np.nan for t in S['dt']]
    P = E['precipitation_era5'].fillna(0)
    S['P30'] = [float(P[(P.index < t) & (P.index >= t - pd.Timedelta(days=30))].sum()) for t in S['dt']]
    ref_date = pd.to_datetime((S['season']).astype(str) + '-01-15')
    S['doff'] = (S['dt'] - ref_date).dt.days
    S['year'] = S['dt'].dt.year + (S['dt'].dt.dayofyear - 1) / 365.25
    S['sensor'] = S['platform'].map({'landsat-5': 'TM', 'landsat-7': 'ETM+', 'landsat-8': 'OLI', 'landsat-9': 'OLI'})
    S.to_csv(OUT / f'{key}_scenes.csv', index=False)
    return S, M


MET = ['T2m', 'SM1', 'SW', 'WS', 'VPD', 'P30']


def fit(S, y, with_year=True, extra=()):
    d = S.dropna(subset=[y] + MET).copy()
    d['doff2'] = d['doff'] ** 2
    X = d[MET + ['doff', 'doff2'] + list(extra)].copy()
    if with_year:
        X['year'] = d['year'] - 2000
    X = sm.add_constant(X.astype(float))
    m = sm.OLS(d[y].astype(float), X).fit(cov_type='HC3')
    return m, d


def window_means(S, y, resid=None):
    out = {}
    for ep, yrs in WIN.items():
        sel = S['season'].isin(list(yrs))
        v = (resid if resid is not None else S[y])[sel].dropna()
        if len(v) >= 2:
            bs = [np.mean(np.random.default_rng(i).choice(v.values, len(v))) for i in range(1000)]
            out[ep] = dict(n=int(len(v)), mean=float(v.mean()), lo=float(np.percentile(bs, 2.5)), hi=float(np.percentile(bs, 97.5)))
    return out


def summarize(key):
    S, M = scene_table(key)
    res = dict(n_scenes=int(len(S)), masks={k: M[k] for k in ['n_core', 'n_ref', 'n_land', 'zc']},
               n_valid={y: int(S[y].notna().sum()) for y in ['LST_city', 'SUHI_core', 'SUHI_dyn']})
    for y in ['LST_city', 'SUHI_core', 'SUHI_dyn']:
        if S[y].notna().sum() < 25:
            continue
        m_full, d = fit(S, y, True)
        m_met, _ = fit(S, y, False)
        # raw trend (year only + seasonality)
        dd = d.copy(); dd['doff2'] = dd['doff'] ** 2
        Xr = sm.add_constant(pd.DataFrame({'year': dd['year'] - 2000, 'doff': dd['doff'], 'doff2': dd['doff2']}).astype(float))
        m_raw = sm.OLS(dd[y].astype(float), Xr).fit(cov_type='HC3')
        Xo = sm.add_constant(pd.DataFrame({'doff': dd['doff'], 'doff2': dd['doff2']}).astype(float))
        r2_season = sm.OLS(dd[y].astype(float), Xo).fit().rsquared
        resid = pd.Series(np.nan, index=S.index); resid.loc[d.index] = m_met.resid
        anom = pd.Series(np.nan, index=S.index); anom.loc[d.index] = d[y] - d[y].mean()
        res[y] = dict(n=int(m_full.nobs), r2_met=round(float(m_met.rsquared), 3), r2_season_only=round(float(r2_season), 3),
                      trend_raw_per_decade=round(float(m_raw.params['year'] * 10), 3),
                      trend_raw_ci=[round(float(x * 10), 3) for x in m_raw.conf_int().loc['year']],
                      trend_adj_per_decade=round(float(m_full.params['year'] * 10), 3),
                      trend_adj_ci=[round(float(x * 10), 3) for x in m_full.conf_int().loc['year']],
                      coef={k: [round(float(m_full.params[k]), 4), round(float(m_full.bse[k]), 4), round(float(m_full.pvalues[k]), 4)]
                            for k in MET + ['year']},
                      windows_raw=window_means(S, y), windows_adj=window_means(S, y, resid))
    # ERA5 background: dry-season (Nov-Mar) mean daily T2m and total precipitation per season
    E = era5(key)
    Ed = E.resample('D').mean(numeric_only=True)
    Ed['season'] = Ed.index.year + (Ed.index.month >= 11)
    Ed = Ed[Ed.index.month.isin([11, 12, 1, 2, 3])]
    seas = Ed.groupby('season').agg(T2m=('temperature_2m_era5_land', 'mean'), SM1=('soil_moisture_0_to_7cm_era5_land', 'mean'),
                                     VPD=('vapour_pressure_deficit_era5', 'mean'))
    seas = seas[(seas.index >= 1991) & (seas.index <= 2026)]
    b = np.polyfit(seas.index, seas['T2m'], 1)
    res['era5_dry_season'] = dict(T2m_trend_per_decade=round(float(b[0] * 10), 3),
                                  windows={ep: dict(T2m=round(float(seas.loc[seas.index.isin(list(yrs)), 'T2m'].mean()), 3),
                                                    SM1=round(float(seas.loc[seas.index.isin(list(yrs)), 'SM1'].mean()), 4))
                                           for ep, yrs in WIN.items()})
    seas.to_csv(OUT / f'{key}_era5_dryseason.csv')
    # cross-sensor check: ETM+ offset relative to TM (1999-2011) and to OLI (2013-2017), seasonal/met controls
    cs = {}
    for y in ['LST_city', 'SUHI_core']:
        for a, b_, yrs in [('ETM+', 'TM', (1999, 2012)), ('ETM+', 'OLI', (2013, 2018))]:
            sub = S[(S['season'] >= yrs[0]) & (S['season'] <= yrs[1]) & S['sensor'].isin([a, b_])].copy()
            sub['etm'] = (sub['sensor'] == a).astype(float)
            if sub[y].notna().sum() >= 12 and sub['etm'].sum() >= 4 and (1 - sub['etm']).sum() >= 4:
                try:
                    m, _ = fit(sub, y, True, extra=('etm',))
                    cs[f'{y}_{a}_minus_{b_}'] = [round(float(m.params['etm']), 3), round(float(m.bse['etm']), 3), int(m.nobs)]
                except Exception as e:
                    cs[f'{y}_{a}_minus_{b_}'] = str(e)[:60]
    res['cross_sensor'] = cs
    return res


if __name__ == '__main__':
    out = json.load(open(OUT / 'clim_summary.json')) if (OUT / 'clim_summary.json').exists() else {}
    for k in [a for a in sys.argv[1:] if a in KEYS] or KEYS:
        out[k] = summarize(k)
        print(k, json.dumps({kk: v for kk, v in out[k].items() if kk in ('n_scenes', 'masks', 'n_valid')}))
    json.dump(out, open(OUT / 'clim_summary.json', 'w'), indent=1, default=float)
