"""Shared paths and loaders for the West Africa analysis (cloud side)."""
import json, numpy as np, rasterio
from pathlib import Path
D = Path('/home/claude/heat/data')          # staged PC outputs: data/landsat, data/ref, data/scenes, data/era5
RES = Path('/home/claude/heat/res'); RES.mkdir(exist_ok=True)
AREAS = json.load(open('/home/claude/heat/pc/wa_lup/areas_wa.json'))
KEYS = ['WA_OUA', 'WA_ABJ', 'WA_ACC']
NAME = {'WA_OUA': 'Ouagadougou', 'WA_ABJ': 'Abuja (FCT)', 'WA_ACC': 'Accra (AMA)'}
EPOCHS = ['E88', 'E01', 'B15', 'B25']
YEAR = {'E88': 1988, 'E01': 2001, 'B15': 2015, 'B25': 2025}
LABEL = {'E88': 'c. 1988', 'E01': 'c. 2001', 'B15': 'c. 2015', 'B25': 'c. 2025'}
GHSL_YEAR = {'E88': 1990, 'E01': 2000, 'B15': 2015, 'B25': 2020}
CLASSES = ['Built-up', 'Farmland/shrub', 'Forest', 'Water', 'Bare land']   # codes 1..5
CODE = {c: i + 1 for i, c in enumerate(CLASSES)}

def grid(key, res):
    from rasterio.transform import from_origin
    a = AREAS[key]; x0, y0, x1, y1 = a['window_utm']
    w = int(round((x1 - x0) / res)); h = int(round((y1 - y0) / res))
    return dict(crs=f"EPSG:{a['epsg']}", transform=from_origin(x0, y1, res, res), width=w, height=h,
                bounds=(x0, y0, x0 + w * res, y1), res=res)

def boundary(key):
    import geopandas as gpd
    return gpd.read_file(f'/home/claude/heat/pc/wa_lup/areas/{key}_utm.geojson').geometry.iloc[0]

def inside(key, res=30.0):
    from rasterio.features import rasterize
    g = grid(key, res)
    return rasterize([(boundary(key), 1)], out_shape=(g['height'], g['width']), transform=g['transform'],
                     fill=0, dtype='uint8').astype(bool)

def read(path, bands=None):
    with rasterio.open(path) as s:
        a = s.read() if bands is None else s.read(bands)
        return a, s.profile, list(s.descriptions)

def composite(key, ep):
    """dict of float32 arrays: lst (degC), nobs, sd, stqa (K), blue..swir2 (reflectance)."""
    a, prof, desc = read(D / 'landsat' / f'{key}_{ep}.tif')
    out = {}
    names = ['lst', 'nobs', 'sd', 'stqa', 'blue', 'green', 'red', 'nir', 'swir1', 'swir2']
    for i, n in enumerate(names):
        x = a[i].astype(np.float32)
        x[a[i] == -32768] = np.nan
        if n in ('lst', 'sd', 'stqa'):
            x /= 100.0
        elif n != 'nobs':
            x /= 10000.0
        out[n] = x
    out['nobs'] = np.nan_to_num(out['nobs']).astype(np.int16)
    return out

def save_tif(path, arrs, key, res, dtype, nodata=None, names=None):
    g = grid(key, res)
    arrs = arrs if isinstance(arrs, (list, tuple)) else [arrs]
    prof = dict(driver='GTiff', width=g['width'], height=g['height'], count=len(arrs), dtype=dtype, crs=g['crs'],
                transform=g['transform'], compress='deflate', tiled=True)
    if nodata is not None:
        prof['nodata'] = nodata
    with rasterio.open(path, 'w', **prof) as d:
        for i, x in enumerate(arrs, 1):
            d.write(np.asarray(x).astype(dtype), i)
            if names: d.set_band_description(i, names[i - 1])

def block_mean(a, f, mask=None):
    """Mean of f x f blocks ignoring NaN (and outside mask)."""
    H, W = a.shape[0] // f * f, a.shape[1] // f * f
    x = a[:H, :W].astype(np.float64)
    if mask is not None:
        x = np.where(mask[:H, :W], x, np.nan)
    b = x.reshape(H // f, f, W // f, f)
    with np.errstate(invalid='ignore'):
        return np.nanmean(b, axis=(1, 3))

def block_frac(m, f):
    H, W = m.shape[0] // f * f, m.shape[1] // f * f
    return m[:H, :W].reshape(H // f, f, W // f, f).mean(axis=(1, 3))
