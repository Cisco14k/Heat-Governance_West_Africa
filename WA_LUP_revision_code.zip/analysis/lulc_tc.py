"""Temporal-consistency correction of the four classified maps (urban land is assumed not to revert to non-urban
within the study period; cf. the GAIA approach). With b_t = built-up in the raw map of period t:
  * built-up at t that is not built-up in any later period -> relabelled with the (corrected) class of the next period
    (removes early-period confusion of bare rock/soil or burnt surfaces with built-up land);
  * non-built-up at t that is built-up both earlier and later -> built-up (removes single-period omissions).
The c. 2025 map is the anchor and is not changed. Raw maps are kept as <key>_<ep>_lulc_raw.tif.
Accuracy of the corrected maps: the same rule is applied to the spatial-block cross-validated predictions at the
sample pixels (using the maps of the other periods), the error matrices, kappa and area-adjusted (Olofsson) estimates
are recomputed; outputs replace the entries of <key>_accuracy.json (raw values kept under 'raw').
"""
import json, sys, shutil
import numpy as np
from sklearn.metrics import confusion_matrix, cohen_kappa_score
from wc import RES, KEYS, EPOCHS, CLASSES, inside, read, save_tif
from lulc import olofsson


def em_area(y, p, w, iters=500):
    """Class proportions corrected for misclassification when the accuracy samples are stratified by REFERENCE class:
    P[i, j] = P(map = i | ref = j) from the samples; w = mapped proportions; EM (Saerens et al. 2002) for pi with
    w_i = sum_j pi_j P[i, j]. Returns pi, area-weighted OA, user's (Bayes) and producer's accuracy."""
    P = np.zeros((5, 5))
    for j in range(5):
        m = y == j + 1
        if m.any():
            P[:, j] = np.bincount(p[m] - 1, minlength=5)[:5] / m.sum()
        else:
            P[j, j] = 1.0
    pi = w.copy()
    for _ in range(iters):
        num = P * pi[None, :]
        q = num / np.maximum(num.sum(1, keepdims=True), 1e-12)
        new = (w[:, None] * q).sum(0)
        if np.abs(new - pi).max() < 1e-9:
            pi = new; break
        pi = new
    num = P * pi[None, :]
    ua = np.diag(num) / np.maximum(num.sum(1), 1e-12)
    return dict(pi=pi, oa=float(np.sum(pi * np.diag(P))), ua=ua, pa=np.diag(P))

OUT = RES / 'lulc'


def run(key):
    ins = inside(key)
    for ep in EPOCHS:
        raw = OUT / f'{key}_{ep}_lulc_raw.tif'
        if not raw.exists():
            shutil.copy(OUT / f'{key}_{ep}_lulc.tif', raw)
    R = {ep: read(OUT / f'{key}_{ep}_lulc_raw.tif')[0][0] for ep in EPOCHS}
    B = {ep: R[ep] == 1 for ep in EPOCHS}
    C = {'B25': R['B25'].copy()}
    stats = {}
    n = len(EPOCHS)
    for i in range(n - 2, -1, -1):
        ep = EPOCHS[i]; nxt = EPOCHS[i + 1]
        later = np.zeros_like(B[ep])
        for e in EPOCHS[i + 1:]:
            later |= B[e]
        earlier = np.zeros_like(B[ep])
        for e in EPOCHS[:i]:
            earlier |= B[e]
        c = R[ep].copy()
        rem = B[ep] & ~later
        fill = ~B[ep] & earlier & later & (R[ep] > 0)
        c[rem] = C[nxt][rem]
        c[fill] = 1
        C[ep] = c
        stats[ep] = dict(removed_built_share=float(rem[ins].mean()), filled_built_share=float(fill[ins].mean()))
    acc = json.load(open(OUT / f'{key}_accuracy.json'))
    area_km2 = ins.sum() * 900 / 1e6
    for i, ep in enumerate(EPOCHS):
        save_tif(OUT / f'{key}_{ep}_lulc.tif', C[ep], key, 30.0, 'uint8', nodata=0)
        cvf = OUT / f'{key}_{ep}_cv.npz'
        a = acc[ep]
        a.setdefault('raw', {k: a[k] for k in ['oa', 'kappa', 'ua', 'pa', 'map_share', 'adj_share', 'adj_ci95', 'cm']})
        w = np.array([(C[ep][ins] == c_).mean() for c_ in range(1, 6)]); w = w / w.sum()
        if cvf.exists():
            z = np.load(cvf); idx, y, p = z['idx'], z['y'], z['pred'].copy()
            if ep != 'B25':
                later = np.zeros(len(idx), bool); earlier = np.zeros(len(idx), bool)
                for e in EPOCHS[i + 1:]:
                    later |= B[e].ravel()[idx]
                for e in EPOCHS[:i]:
                    earlier |= B[e].ravel()[idx]
                bp = p == 1
                rem = bp & ~later; fill = ~bp & earlier & later
                p[rem] = C[EPOCHS[i + 1]].ravel()[idx][rem]; p[fill] = 1
                p[p == 0] = y[p == 0]
            cm = confusion_matrix(y, p, labels=list(range(1, 6)))          # rows = reference, cols = map
            np.savez_compressed(OUT / f'{key}_{ep}_cvtc.npz', idx=idx, y=y, pred=p, blk=z['blk'])
            est = em_area(y, p, w)
            rng = np.random.default_rng(11); ub, inv_b = np.unique(z['blk'], return_inverse=True); boots = []
            members = [np.flatnonzero(inv_b == g) for g in range(len(ub))]
            for _ in range(300):
                bb = rng.integers(0, len(ub), len(ub)); sel = np.concatenate([members[g] for g in bb])
                boots.append(em_area(y[sel], p[sel], w)['pi'])
            lo, hi = np.percentile(boots, 2.5, axis=0), np.percentile(boots, 97.5, axis=0)
            a.update(oa=round(float(np.trace(cm) / cm.sum()), 4), kappa=round(float(cohen_kappa_score(y, p)), 4),
                     oa_area_weighted=round(float(est['oa']), 4), cm=cm.tolist(),
                     ua={CLASSES[k]: round(float(est['ua'][k]), 3) for k in range(5)},
                     pa={CLASSES[k]: round(float(est['pa'][k]), 3) for k in range(5)},
                     adj_share={CLASSES[k]: round(float(est['pi'][k]), 4) for k in range(5)},
                     adj_lo={CLASSES[k]: round(float(lo[k]), 4) for k in range(5)},
                     adj_hi={CLASSES[k]: round(float(hi[k]), 4) for k in range(5)},
                     adj_ci95={CLASSES[k]: round(float((hi[k] - lo[k]) / 2), 4) for k in range(5)},
                     adj_km2={CLASSES[k]: round(float(est['pi'][k] * area_km2), 2) for k in range(5)},
                     adj_method='EM prior adjustment of the spatial-block CV error matrix (Saerens et al. 2002); '
                                '95% CI from 300 block-bootstrap replicates of the samples')
        a.update(map_share={CLASSES[k]: round(float(w[k]), 4) for k in range(5)},
                 map_km2={CLASSES[k]: round(float(w[k] * area_km2), 2) for k in range(5)},
                 temporal_consistency=stats.get(ep, {}))
        print(key, ep, 'OA', a['oa'], 'k', a['kappa'], 'built map', round(w[0], 4), 'adj', a['adj_share']['Built-up'],
              stats.get(ep, {}), flush=True)
    json.dump(acc, open(OUT / f'{key}_accuracy.json', 'w'), indent=1)


if __name__ == '__main__':
    for k in [a for a in sys.argv[1:] if a in KEYS] or KEYS:
        run(k)
