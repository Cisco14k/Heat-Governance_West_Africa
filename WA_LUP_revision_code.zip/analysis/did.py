"""Conversion-based thermal effect (difference-in-differences, 30 m pixels inside the boundary).
For a period pair (a, b): converted = vegetated (farmland/shrub or forest) at a and built-up at b (and built-up at every
later period, i.e. persistent conversion); control = vegetated in all four periods (persistent green land).
Effect = mean dLST(converted) - mean dLST(control), dLST = LST_b - LST_a. The city-wide background shift between the two
composites (meteorology, acquisition timing, sensor) is common to both groups and cancels. Uncertainty: spatial block
bootstrap (1 km blocks, 1000 replicates). Also: bare -> built conversions.
Outputs res/did/did_summary.json
"""
import json, sys
import numpy as np
from wc import RES, KEYS, EPOCHS, inside, read, composite

OUT = RES / 'did'; OUT.mkdir(exist_ok=True)
PAIRS = [('E88', 'B25'), ('E88', 'E01'), ('E01', 'B15'), ('B15', 'B25')]


def boot(dc, bc, dk, bk, n=1000, seed=0):
    rng = np.random.default_rng(seed)
    ub_c, inv_c = np.unique(bc, return_inverse=True); ub_k, inv_k = np.unique(bk, return_inverse=True)
    sc = np.bincount(inv_c, dc); nc = np.bincount(inv_c); sk = np.bincount(inv_k, dk); nk = np.bincount(inv_k)
    est = []
    for _ in range(n):
        i = rng.integers(0, len(ub_c), len(ub_c)); j = rng.integers(0, len(ub_k), len(ub_k))
        est.append(sc[i].sum() / nc[i].sum() - sk[j].sum() / nk[j].sum())
    return float(np.percentile(est, 2.5)), float(np.percentile(est, 97.5))


def run(key):
    ins = inside(key)
    L = {ep: read(RES / 'lulc' / f'{key}_{ep}_lulc.tif')[0][0] for ep in EPOCHS}
    T = {ep: composite(key, ep)['lst'] for ep in EPOCHS}
    H, W = ins.shape
    rr, cc = np.indices((H, W)); blk = (rr // 33) * 100000 + cc // 33
    veg_all = np.ones_like(ins)
    for ep in EPOCHS:
        veg_all &= np.isin(L[ep], [2, 3])
    out = {}
    for a, b in PAIRS:
        later = EPOCHS[EPOCHS.index(b):]
        persist = np.ones_like(ins)
        for ep in later:
            persist &= L[ep] == 1
        d = T[b] - T[a]; ok = ins & np.isfinite(d)
        ctrl = ok & veg_all
        rec = {}
        for nm, src in [('veg_to_built', [2, 3]), ('bare_to_built', [5]), ('any_to_built', [2, 3, 5])]:
            conv = ok & np.isin(L[a], src) & persist
            if conv.sum() < 200 or ctrl.sum() < 200:
                rec[nm] = dict(n_conv=int(conv.sum()), n_ctrl=int(ctrl.sum())); continue
            eff = float(d[conv].mean() - d[ctrl].mean())
            lo, hi = boot(d[conv], blk[conv], d[ctrl], blk[ctrl])
            rec[nm] = dict(n_conv=int(conv.sum()), conv_km2=round(conv.sum() * 900 / 1e6, 2), n_ctrl=int(ctrl.sum()),
                           dlst_conv=float(d[conv].mean()), dlst_ctrl=float(d[ctrl].mean()), effect=eff, ci95=[lo, hi],
                           conv_share_of_boundary=float(conv.sum() / ins.sum()))
        # level contrast at b: built-up minus persistent green (same composite)
        rec['built_minus_green_b'] = float(np.nanmean(T[b][ins & (L[b] == 1)]) - np.nanmean(T[b][ins & veg_all]))
        rec['built_minus_green_a'] = float(np.nanmean(T[a][ins & (L[a] == 1)]) - np.nanmean(T[a][ins & veg_all]))
        rec['bare_minus_green_b'] = float(np.nanmean(T[b][ins & (L[b] == 5)]) - np.nanmean(T[b][ins & veg_all]))
        out[f'{a}_{b}'] = rec
        print(key, a, b, {k: (v.get('n_conv'), round(v['effect'], 2) if 'effect' in v else None,
                              [round(x, 2) for x in v.get('ci95', [])]) for k, v in rec.items() if isinstance(v, dict)},
              round(rec['built_minus_green_b'], 2), flush=True)
    return out


if __name__ == '__main__':
    S = json.load(open(OUT / 'did_summary.json')) if (OUT / 'did_summary.json').exists() else {}
    for k in [a for a in sys.argv[1:] if a in KEYS] or KEYS:
        S[k] = run(k)
        json.dump(S, open(OUT / 'did_summary.json', 'w'), indent=1)
