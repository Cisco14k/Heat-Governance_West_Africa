"""Supplementary Data S1 (xlsx): error matrices, composite dates and meteorology, scene-level table, DiD, land accounts."""
import json
import pandas as pd
from wc import D, RES, KEYS, EPOCHS, CLASSES, LABEL
out = '/home/claude/heat/ms/Supplementary_Data_S1.xlsx'
with pd.ExcelWriter(out, engine='openpyxl') as xw:
    rd = pd.DataFrame({'Sheet': ['README', 'error_matrices', 'accuracy_area', 'composite_dates_met', 'scenes_<city>', 'did_all_pairs',
                                 'transitions_E88_B25'],
                       'Content': ['Supplementary Data S1 for "Governing urban heat through green-blue infrastructure retention"',
                                   'Spatial-block cross-validated error matrices after temporal-consistency correction (rows = reference, columns = map)',
                                   'Mapped and error-adjusted class shares and areas with 95% CI, user/producer accuracy, OA, kappa',
                                   'Every composite acquisition date with ERA5-Land/ERA5 meteorology at overpass',
                                   'Scene-level city LST and SUHI with ERA5 meteorology (1985-2026)',
                                   'Conversion thermal effect (difference-in-differences) for all period pairs',
                                   'Land-cover transition matrix c. 1988 -> c. 2025 (km2)']})
    rd.to_excel(xw, 'README', index=False)
    rows, acc_rows = [], []
    for k in KEYS:
        A = json.load(open(RES / 'lulc' / f'{k}_accuracy.json'))
        for ep in EPOCHS:
            a = A[ep]
            for i, c in enumerate(CLASSES):
                rows.append(dict(city=k, period=LABEL[ep], reference=c, **{f'map_{m}': a['cm'][i][j] for j, m in enumerate(CLASSES)}))
                acc_rows.append(dict(city=k, period=LABEL[ep], cls=c, map_share=a['map_share'][c], map_km2=a['map_km2'][c],
                                     adj_share=a['adj_share'][c], adj_lo=a['adj_lo'][c], adj_hi=a['adj_hi'][c], adj_km2=a['adj_km2'][c],
                                     users_acc=a['ua'][c], producers_acc=a['pa'][c], n_ref=a['n_per_class'][c], OA=a['oa'],
                                     OA_area_weighted=a['oa_area_weighted'], kappa=a['kappa'], raw_OA=a['raw']['oa'], raw_kappa=a['raw']['kappa']))
    pd.DataFrame(rows).to_excel(xw, 'error_matrices', index=False)
    pd.DataFrame(acc_rows).to_excel(xw, 'accuracy_area', index=False)
    pd.read_csv(RES / 'clim' / 'composite_dates_met.csv').to_excel(xw, 'composite_dates_met', index=False)
    for k in KEYS:
        pd.read_csv(RES / 'clim' / f'{k}_scenes.csv').to_excel(xw, f'scenes_{k[3:]}', index=False)
    S = json.load(open(RES / 'did' / 'did_summary.json')); dr = []
    for k, v in S.items():
        for pair, r in v.items():
            for typ in ['veg_to_built', 'bare_to_built', 'any_to_built']:
                x = r[typ]
                dr.append(dict(city=k, pair=pair, type=typ, n_conv=x.get('n_conv'), n_ctrl=x.get('n_ctrl'), dlst_conv=x.get('dlst_conv'),
                               dlst_ctrl=x.get('dlst_ctrl'), effect=x.get('effect'), ci_lo=(x.get('ci95') or [None, None])[0],
                               ci_hi=(x.get('ci95') or [None, None])[1]))
    pd.DataFrame(dr).to_excel(xw, 'did_all_pairs', index=False)
    C = json.load(open(RES / 'lulc' / 'clr.json')); tr = []
    for k in KEYS:
        for i, c in enumerate(CLASSES):
            tr.append(dict(city=k, from_c1988=c, **{f'to_{m}_km2': C[k]['transition_km2_E88_B25'][i][j] for j, m in enumerate(CLASSES)}))
    pd.DataFrame(tr).to_excel(xw, 'transitions_E88_B25', index=False)
print('ok')
