"""Scene archive for the background-climate analysis: every usable dry-season (Nov-Mar) Landsat acquisition 1990-2026.

Per date (tiles of one platform and day mosaicked): QA_PIXEL and ST read from the first COG overview (60 m),
medium/high-confidence cloud/cirrus, dilated cloud, shadow and snow removed, ST_QA <= 5 K; aggregated to the 240 m
grid as the mean LST of the clear 60 m sub-pixels and their count (0-16).
Selection: footprint covering >= 50 % of the study area, scene cloud cover < 50 %, Landsat 7 only until 2017 (later
orbit drift changes the overpass time), at most 8 dates per dry season (lowest cloud cover first).
Outputs: out/wa/scenes/<key>/<key>_<date>_<platform>.tif (int16: LST degC x100, clear count) and
         out/wa/scenes/<key>_scenes.csv (inventory)
Usage: python wa_scenes.py <key> [...]
"""
import sys, csv, time, datetime as dt
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from wa_common import (WOUT, AREAS, get_logger, status, retry, grid, grid_bbox_lonlat, stac_client, sign, warp_read,
                       write_tif, boundary, boundary_mask, mark, is_done)

lg = get_logger("wa_scenes")
ODIR = WOUT / "scenes"; ODIR.mkdir(parents=True, exist_ok=True)
PLATS = ["landsat-5", "landsat-7", "landsat-8", "landsat-9"]
PER_SEASON = 8
Y0 = next((int(a.split("=")[1]) for a in sys.argv if a.startswith("--y0=")), 1990)


def qa_clear(qa, conf=2):
    fill = (qa & 1) > 0
    bad = ((qa >> 1) & 1) | ((qa >> 2) & 1) | ((qa >> 3) & 1) | ((qa >> 4) & 1) | ((qa >> 5) & 1)
    return (~fill) & (bad == 0) & (((qa >> 8) & 3) < conf) & (((qa >> 14) & 3) < conf) & (qa > 0)


def rd(href, g):
    last = None
    for ovr in (0, None):
        try:
            return warp_read(href, g, "nearest", dst_nodata=0, overview=ovr)
        except Exception as e:
            last = e
    raise last


def run(key):
    name = f"scenes_{key}" + ("" if Y0 == 1990 else f"_y{Y0}")
    if is_done(name):
        return
    sd = ODIR / key; sd.mkdir(exist_ok=True)
    g60 = grid(key, 60.0); g240 = grid(key, 240.0)
    inside60 = boundary_mask(key, g60); inside240 = boundary_mask(key, g240)
    bbox = grid_bbox_lonlat(g60, 0.01)
    from shapely.geometry import shape
    from shapely.ops import unary_union, transform as stransform
    from pyproj import Transformer
    trf = Transformer.from_crs("EPSG:4326", g60["crs"], always_xy=True).transform
    B = boundary(key)
    cl = retry(stac_client, tries=10, wait=60, lg=lg, what="stac client")
    items = []
    for y in range(Y0, 2027):
        a, b = dt.date(y - 1, 11, 1), dt.date(y, 3, 31)
        s = retry(lambda: list(cl.search(collections=["landsat-c2-l2"], bbox=bbox, datetime=f"{a}/{b}",
                                         query={"eo:cloud_cover": {"lt": 50}, "platform": {"in": PLATS}}).items()),
                  tries=6, wait=30, lg=lg, what=f"search {y}")
        items += [i for i in s if "_L2SR_" not in i.id and
                  not (i.properties.get("platform") == "landsat-7" and i.datetime.year >= 2018)]
    bydate = {}
    for it in items:
        bydate.setdefault(it.datetime.date().isoformat() + "_" + it.properties.get("platform"), []).append(it)
    cand = []
    for d, its in bydate.items():
        try:
            fp = stransform(trf, unary_union([shape(i.geometry) for i in its]))
            cov = fp.intersection(B).area / B.area
        except Exception:
            cov = 1.0
        if cov < 0.5:
            continue
        dd = dt.date.fromisoformat(d[:10])
        cand.append((dd.year + 1 if dd.month >= 11 else dd.year, np.mean([i.properties.get("eo:cloud_cover", 100) for i in its]), d, its, cov))
    sel = []
    for s_ in sorted({c[0] for c in cand}):
        sel += sorted([c for c in cand if c[0] == s_], key=lambda c: c[1])[:PER_SEASON]
    lg.info(f"{key}: {len(items)} items, {len(bydate)} dates, {len(cand)} covering, {len(sel)} selected")
    inv_f = ODIR / f"{key}_scenes.csv"
    done_dates = set()
    if inv_f.exists():
        for r in csv.DictReader(open(inv_f)):
            done_dates.add(r["key"])
    cols = ["key", "season", "date", "time_utc", "platform", "wrs", "scene_cloud", "sun_elev", "coverage",
            "clear_inside", "lst_median_inside", "lst_mean_inside", "written", "ids"]
    new = not inv_f.exists()
    fh = open(inv_f, "a", newline=""); wr = csv.DictWriter(fh, fieldnames=cols)
    if new:
        wr.writeheader()
    for i, (season, cc, d, its, cov) in enumerate(sel):
        if d in done_dates or (sd / f"{key}_{d}.tif").exists():
            continue
        t0 = time.time()
        rec = dict(key=d, season=season, date=d[:10], platform=d[11:], time_utc=its[0].datetime.strftime("%H:%M:%S"),
                   wrs=";".join(f"{x.properties.get('landsat:wrs_path')}/{x.properties.get('landsat:wrs_row')}" for x in its),
                   scene_cloud=round(float(cc), 1), coverage=round(cov, 3),
                   sun_elev=round(float(np.mean([x.properties.get("view:sun_elevation", np.nan) for x in its])), 2),
                   ids=";".join(x.id for x in its))
        try:
            qa = np.zeros((g60["height"], g60["width"]), np.uint16)
            st = np.zeros_like(qa); sq = np.zeros_like(qa)
            for it in its:
                q = retry(lambda: rd(sign(it.assets["qa_pixel"].href), g60), tries=4, wait=20, lg=lg, what=f"qa {it.id}")
                ok = (q > 0) & ((q & 1) == 0)
                m = ok & ((qa == 0) | ((qa & 1) > 0)); qa[m] = q[m]
                f_ = (qa == 0) & (q > 0); qa[f_] = q[f_]
                kk = "lwir11" if "lwir11" in it.assets else "lwir"
                t_ = retry(lambda: rd(sign(it.assets[kk].href), g60), tries=4, wait=20, lg=lg, what=f"st {it.id}")
                m2 = (st == 0) & (t_ > 0); st[m2] = t_[m2]
                if "qa" in it.assets:
                    try:
                        u = rd(sign(it.assets["qa"].href), g60).astype(np.uint16)
                        m3 = (sq == 0) & (u > 0); sq[m3] = u[m3]
                    except Exception:
                        pass
            clear = qa_clear(qa, 2) & (st > 0) & ((sq <= 500) | (sq >= 32768))
            rec["clear_inside"] = round(float(clear[inside60].mean()), 3)
            if clear[inside60].mean() < 0.05:
                rec["written"] = 0; wr.writerow(rec); fh.flush(); continue
            L = np.where(clear, st * 0.00341802 + 149.0 - 273.15, 0.0).astype(np.float32)
            H, W = g240["height"], g240["width"]
            Lb = L[: H * 4, : W * 4].reshape(H, 4, W, 4); Cb = clear[: H * 4, : W * 4].reshape(H, 4, W, 4)
            n = Cb.sum(axis=(1, 3)); s_ = Lb.sum(axis=(1, 3))
            mean = np.where(n > 0, s_ / np.maximum(n, 1), np.nan)
            vals = L[clear & inside60]
            rec["lst_median_inside"] = round(float(np.median(vals)), 2)
            rec["lst_mean_inside"] = round(float(np.mean(vals)), 2)
            write_tif(sd / f"{key}_{d}.tif", [np.where(np.isfinite(mean), np.round(mean * 100), -32768).astype(np.int16),
                                              n.astype(np.int16)], g240, "int16", nodata=-32768,
                      names=["LST_C_x100", "clear_count_of16"])
            rec["written"] = 1
        except Exception as e:
            lg.warning(f"{key} {d} failed: {type(e).__name__} {str(e)[:150]}")
            continue
        wr.writerow(rec); fh.flush()
        lg.info(f"{key} {i + 1}/{len(sel)} {d}: clear {rec['clear_inside']} LST {rec.get('lst_median_inside')} ({time.time() - t0:.0f}s)")
        status(f"wa_scenes_{key}", n=i + 1, of=len(sel), last=d)
    fh.close()
    mark(name, n_selected=len(sel))
    lg.info(f"WA SCENES {key} DONE")


if __name__ == "__main__":
    keys = [a for a in sys.argv[1:] if a in AREAS] or list(AREAS)
    for k in keys:
        for p_ in range(3):
            try:
                run(k); break
            except Exception:
                import traceback
                lg.error(f"{k} FAILED\n{traceback.format_exc()[-1500:]}")
                time.sleep(300)
    lg.info("WA SCENES ALL DONE")
