"""Reference and ancillary layers on the 30 m grid of each study area (independent of the Landsat classification).

* ESA WorldCover 2021 v200 (10 m) -> count of each class among the 9 sub-pixels of a 30 m cell (11 bands, uint8)
* JRC Global Surface Water v1.4 (1984-2021): occurrence (%), transitions class, seasonality (months) (uint8)
* ESA CCI Land Cover (300 m; 1995, 2005, 2015, 2020) -> class code (uint8, nearest)
* Copernicus DEM GLO-30 -> elevation (m, float32)
* GHSL R2023A BUILT_S 3" (1995, 2005, 2015, 2020, 2025) -> built-up fraction x1000 (uint16)
* GHSL R2023A BUILT_H AGBH 2018 3" -> average gross building height (m x10, uint16)
* GHSL R2023A POP 3" (2020, 2025) -> residents per hectare (float32)
Outputs: out/wa/ref/<key>_<layer>.tif
Usage: python wa_ref.py <key> [...]
"""
import sys, os, time
from pathlib import Path
import numpy as np
from wa_common import (WOUT, AREAS, get_logger, status, retry, grid, subgrid, grid_bbox_lonlat, stac_client, sign,
                       warp_read, write_tif, mark, is_done)

lg = get_logger("wa_ref")
ODIR = WOUT / "ref"; ODIR.mkdir(parents=True, exist_ok=True)
WC = [10, 20, 30, 40, 50, 60, 70, 80, 90, 95, 100]
WC_NAMES = ["tree", "shrub", "grass", "crop", "built", "bare", "snow_ice", "water", "herb_wetland", "mangrove", "moss"]


def search(cl, coll, bbox, **kw):
    return retry(lambda: list(cl.search(collections=[coll], bbox=bbox, **kw).items()), tries=6, wait=30, lg=lg,
                 what=f"search {coll}")


def mosaic_items(items, asset, g, resampling, nd_src, nd_dst, dtype, overview=None):
    out = np.full((g["height"], g["width"]), nd_dst, dtype)
    for it in items:
        if asset not in it.assets:
            continue
        a = retry(lambda: warp_read(sign(it.assets[asset].href), g, resampling, src_nodata=nd_src, dst_nodata=nd_dst,
                                    overview=overview), tries=6, wait=30, lg=lg, what=f"{asset} {it.id}").astype(dtype)
        m = (out == nd_dst) & (a != nd_dst); out[m] = a[m]
    return out


def worldcover(key, cl):
    fn = ODIR / f"{key}_worldcover2021_counts.tif"
    if fn.exists():
        return
    g = grid(key, 30.0)
    its = search(cl, "esa-worldcover", grid_bbox_lonlat(g, 0.01), datetime="2021-01-01/2021-12-31")
    its = [i for i in its if "v200" in i.id or str(i.properties.get("esa_worldcover:product_version", "")).startswith("2")] or its
    out = np.zeros((len(WC), g["height"], g["width"]), np.uint8)
    step = 300
    from rasterio.transform import from_origin
    for r0 in range(0, g["height"], step):
        r1 = min(g["height"], r0 + step)
        gg = dict(subgrid(g, 3))
        gg["transform"] = from_origin(g["bounds"][0], g["bounds"][3] - r0 * 30.0, 10.0, 10.0)
        gg["height"] = (r1 - r0) * 3
        wc = mosaic_items(its, "map", gg, "nearest", 0, 0, np.uint8)
        b = wc.reshape(r1 - r0, 3, g["width"], 3)
        for i, c in enumerate(WC):
            out[i, r0:r1] = (b == c).sum(axis=(1, 3))
    write_tif(fn, list(out), g, "uint8", nodata=None, names=[f"wc_{n}" for n in WC_NAMES],
              tags=dict(note="ESA WorldCover 2021 v200: number of 10 m sub-pixels (of 9) per class"))
    lg.info(f"{key} worldcover done")


def gsw(key, cl):
    fn = ODIR / f"{key}_gsw.tif"
    if fn.exists():
        return
    g = grid(key, 30.0)
    its = search(cl, "jrc-gsw", grid_bbox_lonlat(g, 0.01))
    bands, names = [], []
    for a in ["occurrence", "transitions", "seasonality", "recurrence", "extent"]:
        try:
            bands.append(mosaic_items(its, a, g, "nearest", 255, 255, np.uint8)); names.append(a)
        except Exception as e:
            lg.warning(f"{key} gsw {a}: {e}")
    write_tif(fn, bands, g, "uint8", nodata=255, names=names,
              tags=dict(note="JRC Global Surface Water v1.4 1984-2021 (255 = no data)"))
    lg.info(f"{key} gsw done: {names}")


def cci(key, cl):
    extra = "--extra" in sys.argv
    fn = ODIR / (f"{key}_cci_early.tif" if extra else f"{key}_cci.tif")
    if fn.exists():
        return
    g = grid(key, 30.0)
    bbox = grid_bbox_lonlat(g, 0.05)
    bands, names = [], []
    for y in ([1992, 2000] if extra else [1995, 2005, 2015, 2020]):
        its = search(cl, "esa-cci-lc", bbox, datetime=f"{y}-01-01/{y}-12-31")
        if not its:
            lg.warning(f"{key} CCI {y}: no items"); continue
        asset = "lccs_class" if "lccs_class" in its[0].assets else sorted(its[0].assets)[0]
        bands.append(mosaic_items(its, asset, g, "nearest", 0, 0, np.uint8)); names.append(f"cci_{y}")
    write_tif(fn, bands, g, "uint8", nodata=0, names=names, tags=dict(note="ESA CCI LC 300 m class codes (nearest)"))
    lg.info(f"{key} cci done: {names}")


def dem(key, cl):
    fn = ODIR / f"{key}_dem.tif"
    if fn.exists():
        return
    g = grid(key, 30.0)
    its = search(cl, "cop-dem-glo-30", grid_bbox_lonlat(g, 0.02))
    d = mosaic_items(its, "data", g, "bilinear", -32767.0, -32767.0, np.float32)
    d[d <= -1000] = np.nan
    write_tif(fn, d, g, "float32", nodata=None, names=["elevation_m"], tags=dict(note="Copernicus DEM GLO-30"))
    lg.info(f"{key} dem done {np.nanmin(d):.0f}..{np.nanmax(d):.0f}")


def ghsl(key):
    import a42_ghsl as G
    g = grid(key, 30.0)
    bbox = grid_bbox_lonlat(g, 0.05)
    tmpdir = ODIR / "_tmp"; tmpdir.mkdir(exist_ok=True)
    if "--extra" in sys.argv:
        jobs = [("built", 1990), ("built", 2000), ("pop", 2015), ("pop", 2000)]
    else:
        jobs = [("built", e) for e in [1995, 2005, 2015, 2020, 2025]] + [("hagb", 2018)] + [("pop", 2020), ("pop", 2025)]
    for prod, e in jobs:
        fn = ODIR / f"{key}_ghsl_{prod}_{e}.tif"
        if fn.exists():
            continue
        if prod == "pop":
            folder, name, mode = "GHS_POP_GLOBE_R2023A", f"GHS_POP_E{e}_GLOBE_R2023A_4326_3ss", "pop"
        else:
            folder, pattern, mode = G.PRODUCTS[prod]
            name = pattern.format(e=e)
        arr = None
        for zp in G.tiles_for(folder, name, bbox):
            src = G.tif_in_zip(zp)
            if mode in ("frac", "value"):
                fr = G.built_fraction_tif(src, tmpdir, mode)
                a = G.warp_avg(fr, g)
                try:
                    os.remove(fr)
                except Exception:
                    pass
            else:
                # population: persons per 3" cell -> persons per hectare (3" cell area at each row's latitude)
                import rasterio
                from rasterio.vrt import WarpedVRT
                from rasterio.enums import Resampling
                with rasterio.open(src) as s:
                    tr = s.transform
                    with WarpedVRT(s, crs=g["crs"], transform=g["transform"], width=g["width"], height=g["height"],
                                   resampling=Resampling.bilinear, src_nodata=s.nodata, nodata=np.nan, dtype="float32") as v:
                        a = v.read(1)
                from pyproj import Transformer
                trf = Transformer.from_crs(g["crs"], "EPSG:4326", always_xy=True)
                ys = g["bounds"][3] - (np.arange(g["height"]) + 0.5) * 30.0
                _, lat = trf.transform(np.full_like(ys, (g["bounds"][0] + g["bounds"][2]) / 2), ys)
                cell_ha = (abs(tr.e) * 110574.0) * (abs(tr.a) * 111320.0 * np.cos(np.radians(lat))) / 1e4
                a = a / cell_ha[:, None]
            arr = a if arr is None else np.where(np.isfinite(arr), arr, a)
        if prod == "built":
            write_tif(fn, np.where(np.isfinite(arr), np.round(arr * 1000), 0).astype(np.uint16), g, "uint16", nodata=None,
                      names=[f"built_frac_x1000_{e}"], tags=dict(note=f"GHSL R2023A BUILT_S E{e} 3ss fraction x1000"))
        elif prod == "hagb":
            write_tif(fn, np.where(np.isfinite(arr), np.round(arr * 10), 0).astype(np.uint16), g, "uint16", nodata=None,
                      names=["agbh_m_x10"], tags=dict(note="GHSL R2023A BUILT_H AGBH 2018 (m x10; 0 = no building)"))
        else:
            write_tif(fn, np.where(np.isfinite(arr), arr, 0).astype(np.float32), g, "float32", nodata=None,
                      names=[f"pop_per_ha_{e}"], tags=dict(note=f"GHSL R2023A POP E{e} 3ss, residents per hectare"))
        lg.info(f"{key} ghsl {prod} {e} done")
        status("wa_ref", area=key, prod=prod, epoch=e)


def run(key, cl):
    for f in ((cci,) if "--extra" in sys.argv else (worldcover, gsw, cci, dem)):
        try:
            f(key, cl)
        except Exception:
            import traceback
            lg.error(f"{key} {f.__name__} FAILED\n{traceback.format_exc()[-1200:]}")
    try:
        ghsl(key)
    except Exception:
        import traceback
        lg.error(f"{key} ghsl FAILED\n{traceback.format_exc()[-1200:]}")


if __name__ == "__main__":
    keys = [a for a in sys.argv[1:] if a in AREAS] or list(AREAS)
    cl = retry(stac_client, tries=10, wait=60, lg=lg, what="stac client")
    for p_ in range(3):
        for k in keys:
            run(k, cl)
        need = [ODIR / f"{k}_{n}.tif" for k in keys for n in
                (["cci_early", "ghsl_built_1990", "ghsl_built_2000", "ghsl_pop_2015"] if "--extra" in sys.argv else
                 ["worldcover2021_counts", "gsw", "cci", "dem", "ghsl_built_1995", "ghsl_built_2020", "ghsl_pop_2020", "ghsl_hagb_2018"])]
        miss = [p.name for p in need if not p.exists()]
        if not miss:
            break
        lg.info(f"pass {p_ + 1}: missing {miss}; retry in 10 min")
        time.sleep(600)
    mark("ref_" + "_".join(keys) + ("_extra" if "--extra" in sys.argv else ""), missing=miss)
    lg.info("WA REF DONE")
