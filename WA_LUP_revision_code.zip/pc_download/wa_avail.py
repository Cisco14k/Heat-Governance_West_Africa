"""Landsat C2 L2 availability 1982-2004 per area (all months, cloud < 80 %): out/wa/avail_<key>.csv"""
import csv, datetime as dt
from wa_common import WOUT, AREAS, get_logger, retry, stac_client, grid, grid_bbox_lonlat
lg = get_logger("wa_avail")
cl = retry(stac_client, tries=10, wait=60, lg=lg, what="stac")
for key in AREAS:
    bbox = grid_bbox_lonlat(grid(key, 240.0), 0.0)
    rows = []
    for y in range(1982, 2005):
        its = retry(lambda: list(cl.search(collections=["landsat-c2-l2"], bbox=bbox, datetime=f"{y}-01-01/{y}-12-31",
                                           query={"eo:cloud_cover": {"lt": 80}}).items()), tries=5, wait=30, lg=lg, what=str(y))
        for i in its:
            if "_L2SR_" in i.id:
                continue
            rows.append(dict(id=i.id, date=i.datetime.date().isoformat(), platform=i.properties.get("platform"),
                             cloud=i.properties.get("eo:cloud_cover"), wrs=f"{i.properties.get('landsat:wrs_path')}/{i.properties.get('landsat:wrs_row')}"))
    with open(WOUT / f"avail_{key}.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["id", "date", "platform", "cloud", "wrs"]); w.writeheader(); w.writerows(rows)
    lg.info(f"{key}: {len(rows)} items 1982-2004")
lg.info("WA AVAIL DONE")
