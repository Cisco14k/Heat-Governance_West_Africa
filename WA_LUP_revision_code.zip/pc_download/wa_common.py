"""West Africa land-use-policy revision (Ouagadougou, Abuja FCT, Accra AMA): shared helpers.

Runs inside heat6_pipeline/pc/wa_lup on the processing PC and reuses the download helpers of the Heat6 pipeline
(a42_common: Planetary Computer STAC client, signed COG reads, GeoTIFF writer, proxy set-up).
Area registry: wa_lup/areas_wa.json (window_utm snapped to 480 m so that the 30/60/120/240/480 m grids nest).
Outputs: heat6_pipeline/pc/out/wa/<product>/ ; logs: heat6_pipeline/pc/logs/wa_*.log
"""
import os, sys, json, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PC = HERE.parent
os.environ["H6_AREAS"] = "wa_lup/areas_wa.json"          # read by a42_common at import time
sys.path.insert(0, str(PC))
from a42_common import (OUT, AREAS, get_logger, status, retry, grid, subgrid, grid_bbox_lonlat,  # noqa: E402
                        stac_client, sign, warp_read, write_tif, pid_alive)

WOUT = OUT / "wa"
WOUT.mkdir(parents=True, exist_ok=True)
KEYS = ["WA_OUA", "WA_ABJ", "WA_ACC"]
DONE = WOUT / "_done"
DONE.mkdir(exist_ok=True)


def boundary(key):
    from shapely.geometry import shape
    gj = json.load(open(HERE / "areas" / f"{key}_utm.geojson", encoding="utf-8"))
    return shape(gj["features"][0]["geometry"])


def boundary_mask(key, g, all_touched=False):
    from rasterio.features import rasterize
    return rasterize([(boundary(key), 1)], out_shape=(g["height"], g["width"]), transform=g["transform"],
                     fill=0, all_touched=all_touched, dtype="uint8").astype(bool)


def mark(name, **kw):
    kw["time"] = time.strftime("%Y-%m-%d %H:%M:%S")
    (DONE / f"{name}.json").write_text(json.dumps(kw, indent=1, default=str))


def is_done(name):
    return (DONE / f"{name}.json").exists()
