"""Landsat Collection 2 Level-2 dry-season composites at 30 m for the three West African study areas.

Benchmark periods (dry season of year Y = 1 Nov (Y-1) to 31 Mar Y). Final design (identical windows in the three
cities, dictated by the Landsat archive over West Africa, where Landsat 5 holds no dry-season acquisitions of Abuja and
Accra between 1992 and 1997 and Landsat 7 ETM+ lost its scan-line corrector in May 2003):
  E88: 1986-1991 (Landsat 4/5 TM)          fallback 1985, 1992, 1984
  E01: 2000-2003 (Landsat 7 ETM+ SLC-on, Landsat 5 TM)   fallback 1999
  B15 = c. 2015 and B25 = c. 2025 as below. (B95/B05 were the first design and are not used.)
  B95: 1994-1996 (Landsat 5 TM)            fallback years 1993, 1997, 1992, 1998
  B05: 2004-2006 (Landsat 5 TM)            fallback years 2003, 2007, 2002, 2008; Landsat 7 ETM+ (SLC-off) if < 6 dates
  B15: 2014-2016 (Landsat 8 OLI/TIRS)      fallback 2013, 2017; Landsat 7 ETM+ if < 6 dates
  B25: 2024-2026 (Landsat 8/9 OLI/TIRS)    fallback 2023
Per date (all tiles of one platform on one day mosaicked): QA_PIXEL screening at native 30 m (fill, dilated cloud,
cirrus, cloud, cloud shadow, snow; medium/high cloud and cirrus confidence), surface temperature (ST_B6/ST_B10,
x0.00341802 + 149 K) with ST_QA uncertainty <= 5 K, six surface-reflectance bands (x0.0000275 - 0.2).
Composite = per-pixel median of the clear observations after a date screen (date median departing more than
max(15 K, 4 MAD) from the other dates) and a per-pixel cold-outlier screen (< median - max(3 MAD, 4 K)).
Outputs out/wa/landsat/<key>_<ep>.tif (int16): 1 LST degC x100 | 2 NOBS | 3 LST SD x100 | 4 ST_QA K x100 |
5-10 SR blue, green, red, nir, swir1, swir2 x10000 ; sidecar <key>_<ep>.json ; scene inventory <key>_<ep>_scenes.csv
Usage: python wa_landsat.py <key> [<key> ...]
"""
import os, sys, csv, json, time, datetime as dt
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from wa_common import (WOUT, AREAS, get_logger, status, retry, grid, grid_bbox_lonlat, stac_client, sign, warp_read,
                       write_tif, boundary_mask, mark, is_done)

lg = get_logger("wa_landsat")
ODIR = WOUT / "landsat"; ODIR.mkdir(parents=True, exist_ok=True)
TMP = ODIR / "_tmp"; TMP.mkdir(exist_ok=True)
EPOCHS = {
    "E88": dict(years=[1986, 1987, 1988, 1989, 1990, 1991], extra=[1985, 1992, 1984], plat=["landsat-4", "landsat-5"],
                fallback=None),
    "E01": dict(years=[2000, 2001, 2002, 2003], extra=[1999], plat=["landsat-7", "landsat-5"], fallback=None),
    "B95": dict(years=[1994, 1995, 1996], extra=[1993, 1997, 1992, 1998], plat=["landsat-5"], fallback=None),
    "B05": dict(years=[2004, 2005, 2006], extra=[2003, 2007, 2002, 2008], plat=["landsat-5"], fallback=["landsat-7"]),
    "B15": dict(years=[2014, 2015, 2016], extra=[2013, 2017], plat=["landsat-8"], fallback=["landsat-7"]),
    "B25": dict(years=[2024, 2025, 2026], extra=[2023], plat=["landsat-8", "landsat-9"], fallback=None),
}
SR = ["blue", "green", "red", "nir08", "swir16", "swir22"]
MAXN = {"WA_OUA": 14, "WA_ABJ": 14, "WA_ACC": 20}
TARGET_LOOKS = 6.0
STQA_MAX = 500          # ST_QA (K x 100): reject pixels with surface-temperature uncertainty above 5 K


def season_windows(year):
    return [(dt.date(year - 1, 11, 1), dt.date(year, 3, 31))]


def search(cl, bbox, years, plats, max_cloud=60):
    items = []
    for y in years:
        for a, b in season_windows(y):
            s = retry(lambda: list(cl.search(collections=["landsat-c2-l2"], bbox=bbox,
                                             datetime=f"{a.isoformat()}/{b.isoformat()}",
                                             query={"eo:cloud_cover": {"lt": max_cloud},
                                                    "platform": {"in": plats}}).items()),
                      tries=6, wait=30, lg=lg, what=f"search {y}")
            items += [i for i in s if "_L2SR_" not in i.id]
    return items


def season_of(d):
    return d.year + 1 if d.month >= 11 else d.year


def qa_clear(qa, conf=2):
    fill = (qa & 1) > 0
    bad = ((qa >> 1) & 1) | ((qa >> 2) & 1) | ((qa >> 3) & 1) | ((qa >> 4) & 1) | ((qa >> 5) & 1)
    return (~fill) & (bad == 0) & (((qa >> 8) & 3) < conf) & (((qa >> 14) & 3) < conf) & (qa > 0)


def mosaic(dst, a, qa_mode=False):
    if qa_mode:
        ok = (a > 0) & ((a & 1) == 0)
        m = ok & ((dst == 0) | ((dst & 1) > 0)); dst[m] = a[m]
        f = (dst == 0) & (a > 0); dst[f] = a[f]
    else:
        m = (dst == 0) & (a > 0); dst[m] = a[m]


def lwir_key(it):
    return "lwir11" if "lwir11" in it.assets else "lwir"


def plan_dates(order, g, maxn):
    from shapely.geometry import shape
    from shapely.ops import unary_union, transform as stransform
    from pyproj import Transformer
    from rasterio.features import rasterize
    from rasterio.transform import from_origin
    trf = Transformer.from_crs("EPSG:4326", g["crs"], always_xy=True).transform
    nC = 30
    sx = (g["bounds"][2] - g["bounds"][0]) / nC; sy = (g["bounds"][3] - g["bounds"][1]) / nC
    tC = from_origin(g["bounds"][0], g["bounds"][3], sx, sy)
    need = np.full((nC, nC), TARGET_LOOKS)
    plan, rest = [], []
    for d, its in order:
        try:
            fp = stransform(trf, unary_union([shape(i.geometry) for i in its]))
            m = rasterize([(fp, 1)], out_shape=(nC, nC), transform=tC, fill=0).astype(bool)
        except Exception:
            m = np.ones((nC, nC), bool)
        w = max(0.05, 1 - float(np.mean([i.properties.get("eo:cloud_cover", 50) for i in its])) / 100)
        gain = float((np.minimum(need, w) * m).sum())
        if len(plan) < maxn and m.sum() > 0 and gain >= 0.02 * m.sum():
            plan.append((d, its)); need = np.maximum(need - w * m, 0)
        else:
            rest.append((d, its))
    return plan, rest, float(need.mean())


def read_date(items, g):
    """QA at 30 m first; returns dict of uint16 arrays (0 = no data) or None if < 3 % clear."""
    qa = np.zeros((g["height"], g["width"]), np.uint16)
    for it in items:
        q = retry(lambda: warp_read(sign(it.assets["qa_pixel"].href), g, "nearest", dst_nodata=0), tries=5, wait=20,
                  lg=lg, what=f"qa_pixel {it.id}")
        mosaic(qa, q, True)
    clear = qa_clear(qa, 2)
    if clear.mean() < 0.03:
        return None, float(clear.mean())
    keys = ["lwir", "qa"] + SR
    out = {k: np.zeros((g["height"], g["width"]), np.uint16) for k in keys}

    def one(args):
        it, k = args
        kk = lwir_key(it) if k == "lwir" else k
        if kk not in it.assets:
            return k, None
        return k, retry(lambda: warp_read(sign(it.assets[kk].href), g, "nearest", dst_nodata=0), tries=5, wait=20,
                        lg=lg, what=f"{k} {it.id}")
    with ThreadPoolExecutor(max_workers=6) as ex:
        for k, arr in ex.map(one, [(it, k) for it in items for k in keys]):
            if arr is not None:
                mosaic(out[k], arr.astype(np.uint16))
    ok = clear & (out["lwir"] > 0)
    if (out["qa"] > 0).any():
        ok &= (out["qa"] <= STQA_MAX) | (out["qa"] >= 32768)          # 0 / negative int16 = no ST_QA value
    for k in keys:
        out[k] = np.where(ok, out[k], 0).astype(np.uint16)
    return out, float(ok.mean())


def composite(key, ep):
    name = f"landsat_{key}_{ep}"
    fn = ODIR / f"{key}_{ep}.tif"
    if is_done(name) and fn.exists():
        return
    E = EPOCHS[ep]
    g = grid(key, 30.0)
    inside = boundary_mask(key, g)
    bbox = grid_bbox_lonlat(g, 0.01)
    cl = retry(stac_client, tries=10, wait=60, lg=lg, what="stac client")
    items = [i for i in search(cl, bbox, E["years"], E["plat"])
             if not (i.properties.get("platform") == "landsat-7" and i.datetime.date() > dt.date(2003, 5, 30))]
    bydate = {}
    for it in items:
        bydate.setdefault(it.datetime.date().isoformat() + "_" + it.properties.get("platform", ""), []).append(it)
    note = []
    if len(bydate) < 8:
        for it in search(cl, bbox, E["extra"], E["plat"]):
            bydate.setdefault(it.datetime.date().isoformat() + "_" + it.properties.get("platform", ""), []).append(it)
        note.append(f"fallback years {E['extra']}")
    if len(bydate) < 6 and E["fallback"]:
        for it in search(cl, bbox, E["years"] + E["extra"], E["fallback"]):
            bydate.setdefault(it.datetime.date().isoformat() + "_" + it.properties.get("platform", ""), []).append(it)
        note.append(f"fallback platforms {E['fallback']} (Landsat 7 SLC-off allowed)")
    ranked = sorted(bydate.items(), key=lambda kv: np.mean([i.properties.get("eo:cloud_cover", 100) for i in kv[1]]))
    byseason = {}
    for d, its in ranked:
        byseason.setdefault(season_of(dt.date.fromisoformat(d[:10])), []).append((d, its))
    order = []
    while any(byseason.values()):
        for s in sorted(byseason):
            if byseason[s]:
                order.append(byseason[s].pop(0))
    plan, rest, deficit = plan_dates(order, g, MAXN[key])
    lg.info(f"{key} {ep}: {len(items)} items, {len(bydate)} dates, plan {len(plan)} (deficit {deficit:.2f}) "
            f"grid {g['width']}x{g['height']} {note}")
    inv, tmpfiles, dmed = [], [], []
    cover = np.zeros((g["height"], g["width"]), np.uint8)
    queue = list(plan); reserve_used = False
    while queue:
        d, its = queue.pop(0)
        if not queue and not reserve_used and (cover[inside] >= 3).mean() < 0.95:
            queue = rest[: max(0, MAXN[key] + 6 - len(tmpfiles))]; reserve_used = True
            lg.info(f"  {key} {ep}: coverage >=3 looks {(cover[inside] >= 3).mean():.3f}; adding {len(queue)} reserve dates")
        t0 = time.time()
        rec = dict(date=d[:10], platform=d[11:], n_tiles=len(its),
                   wrs=";".join(f"{i.properties.get('landsat:wrs_path')}/{i.properties.get('landsat:wrs_row')}" for i in its),
                   scene_cloud=round(float(np.mean([i.properties.get("eo:cloud_cover", np.nan) for i in its])), 1),
                   sun_elev=round(float(np.mean([i.properties.get("view:sun_elevation", np.nan) for i in its])), 2),
                   time_utc=its[0].datetime.strftime("%H:%M"), ids=";".join(i.id for i in its))
        try:
            arrs, frac = read_date(its, g)
        except Exception as e:
            lg.warning(f"  {d} failed: {type(e).__name__} {str(e)[:150]}")
            rec.update(used=0, error=str(e)[:100]); inv.append(rec); continue
        if arrs is None:
            rec.update(used=0, clear_window=round(frac, 3)); inv.append(rec); continue
        ok = arrs["lwir"] > 0
        lst = np.where(ok, arrs["lwir"] * 0.00341802 + 149.0 - 273.15, np.nan)
        fin = float(ok[inside].mean())
        rec.update(clear_window=round(frac, 3), clear_inside=round(fin, 3),
                   lst_median_inside=round(float(np.nanmedian(lst[inside])), 2) if fin > 0 else None,
                   stqa_median_K=round(float(np.median(arrs["qa"][ok & (arrs["qa"] < 32768)])) / 100, 2)
                   if (ok & (arrs["qa"] > 0) & (arrs["qa"] < 32768)).any() else None)
        if fin < 0.02 and frac < 0.05:
            rec["used"] = 0; inv.append(rec); continue
        tf = TMP / f"{key}_{ep}_{d}.tif"
        write_tif(tf, [arrs[k] for k in ["lwir", "qa"] + SR], g, "uint16", nodata=0)
        tmpfiles.append(tf); dmed.append(float(np.nanmedian(lst)) if ok.any() else np.nan)
        cover += ok.astype(np.uint8)
        rec["used"] = 1; inv.append(rec)
        lg.info(f"  {key} {ep} {d}: clear {frac:.2f} (inside {fin:.2f}), LST med {rec['lst_median_inside']} "
                f"({time.time() - t0:.0f}s)")
        status(f"wa_landsat_{key}", epoch=ep, dates_used=len(tmpfiles), last=d)
        del arrs, lst
    with open(ODIR / f"{key}_{ep}_scenes.csv", "w", newline="") as f:
        cols = ["date", "time_utc", "platform", "n_tiles", "wrs", "scene_cloud", "sun_elev", "clear_window",
                "clear_inside", "lst_median_inside", "stqa_median_K", "used", "date_screen", "ids", "error"]
        wr = csv.DictWriter(f, fieldnames=cols); wr.writeheader()
        for r in inv:
            wr.writerow({k: r.get(k) for k in cols})
    if not tmpfiles:
        mark(name, empty=True); lg.error(f"{key} {ep}: no usable dates"); return
    dmed = np.array(dmed)
    mm = np.nanmedian(dmed); md = np.nanmedian(np.abs(dmed - mm)) * 1.4826
    keep = np.isfinite(dmed) & (np.abs(dmed - mm) <= max(15.0, 4 * md))
    files = [f for f, k in zip(tmpfiles, keep) if k]
    import rasterio
    from rasterio.windows import Window
    H, W = g["height"], g["width"]
    out = {b: np.full((H, W), -32768, np.int16) for b in ["lst", "nobs", "sd", "stqa"] + SR}
    srcs = [rasterio.open(f) for f in files]
    nbad = 0
    step = 256
    for r0 in range(0, H, step):
        h = min(step, H - r0); win = Window(0, r0, W, h)
        st = np.stack([s.read(1, window=win) for s in srcs]).astype(np.float32)
        st[st == 0] = np.nan
        L = st * 0.00341802 + 149.0 - 273.15
        L[(L < -20) | (L > 80)] = np.nan
        med = np.nanmedian(L, axis=0)
        mad = np.nanmedian(np.abs(L - med), axis=0) * 1.4826
        bad = L < med - np.maximum(3 * mad, 4.0)
        nbad += int(bad.sum()); L[bad] = np.nan
        good = np.isfinite(L)
        nobs = good.sum(axis=0)
        lst = np.nanmedian(L, axis=0); sd = np.nanstd(L, axis=0)
        out["lst"][r0:r0 + h] = np.where(np.isfinite(lst), np.round(lst * 100), -32768)
        out["sd"][r0:r0 + h] = np.where(np.isfinite(sd), np.round(sd * 100), -32768)
        out["nobs"][r0:r0 + h] = nobs
        q = np.stack([s.read(2, window=win) for s in srcs]).astype(np.float32)
        q[(q == 0) | (q >= 32768) | ~good] = np.nan
        qm = np.nanmedian(q, axis=0)
        out["stqa"][r0:r0 + h] = np.where(np.isfinite(qm), np.round(qm), -32768)
        for bi, b in enumerate(SR):
            S = np.stack([s.read(3 + bi, window=win) for s in srcs]).astype(np.float32)
            S[(S == 0) | ~good] = np.nan
            S = S * 0.0000275 - 0.2
            m = np.nanmedian(S, axis=0)
            out[b][r0:r0 + h] = np.where(np.isfinite(m), np.round(np.clip(m, -0.1, 1.5) * 10000), -32768)
    for s in srcs:
        s.close()
    write_tif(fn, [out[b] for b in ["lst", "nobs", "sd", "stqa"] + SR], g, "int16", nodata=-32768,
              names=["LST_C_x100", "NOBS", "LST_SD_x100", "STQA_K_x100", "blue", "green", "red", "nir", "swir1", "swir2"],
              tags=dict(note="Landsat C2 L2 dry-season (Nov-Mar) per-pixel median composite; LST degC*100; SR*10000",
                        epoch=ep))
    used = [r for r in inv if r.get("used") == 1]
    kept = [r for r, k in zip(used, keep) if k]
    n_in = out["nobs"][inside]
    side = dict(area=key, epoch=ep, years=E["years"], notes=note, n_dates=len(files), removed_dates=int((~keep).sum()),
                removed_outliers=nbad, dates=[r["date"] for r in kept], platforms=sorted({r["platform"] for r in kept}),
                valid_inside=round(float((n_in > 0).mean()), 4), ge3_inside=round(float((n_in >= 3).mean()), 4),
                nobs_inside_median=float(np.median(n_in)), nobs_inside_p10=float(np.percentile(n_in, 10)),
                lst_inside_mean=round(float(np.mean(out["lst"][inside][out["lst"][inside] > -32768]) / 100), 3))
    json.dump(side, open(ODIR / f"{key}_{ep}.json", "w"), indent=1)
    # mark date-screen results in the inventory
    with open(ODIR / f"{key}_{ep}_scenes.csv", "w", newline="") as f:
        cols = ["date", "time_utc", "platform", "n_tiles", "wrs", "scene_cloud", "sun_elev", "clear_window",
                "clear_inside", "lst_median_inside", "stqa_median_K", "used", "date_screen", "ids", "error"]
        wr = csv.DictWriter(f, fieldnames=cols); wr.writeheader()
        ki = iter(keep)
        for r in inv:
            if r.get("used") == 1:
                r["date_screen"] = "kept" if next(ki) else "removed"
            wr.writerow({k: r.get(k) for k in cols})
    for f in tmpfiles:
        try:
            os.remove(f)
        except Exception:
            pass
    mark(name, **side)
    lg.info(f"WROTE {fn.name}: {len(files)} dates, valid inside {side['valid_inside']}, >=3 looks {side['ge3_inside']}")


if __name__ == "__main__":
    keys = [a for a in sys.argv[1:] if a in AREAS] or list(AREAS)
    eps = [a for a in sys.argv[1:] if a in EPOCHS] or ["B25", "B95", "B05", "B15"]
    for p_ in range(3):
        failed = []
        for k in keys:
            for ep in eps:
                try:
                    composite(k, ep)
                except Exception:
                    import traceback
                    lg.error(f"{k} {ep} FAILED\n{traceback.format_exc()[-1500:]}")
                    failed.append((k, ep))
        if not failed:
            break
        lg.info(f"pass {p_ + 1}: {len(failed)} composites failed; retry in 10 min")
        time.sleep(600)
    mark("landsat_" + "_".join(keys), failed=[f"{k}_{e}" for k, e in failed] if failed else [])
    lg.info("WA LANDSAT DONE " + " ".join(keys))
