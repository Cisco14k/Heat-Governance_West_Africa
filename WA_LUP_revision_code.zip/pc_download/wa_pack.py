"""Package the West Africa outputs for transfer: zips of the scene archive (per area), ERA5 files and logs, and a
manifest of every output file. Waits (up to 5 days) until the other WA jobs have written their done markers.
Output: out/wa/_pack/*.zip, out/wa/_pack/manifest.json, marker out/wa/_done/PACK_DONE.json"""
import json, time, zipfile
from pathlib import Path
from wa_common import WOUT, KEYS, DONE, get_logger, mark, PC

lg = get_logger("wa_pack")
P = WOUT / "_pack"; P.mkdir(exist_ok=True)


def ready():
    need = [f"landsat_{k}_{e}" for k in KEYS for e in ["B95", "B05", "B15", "B25"]] + \
           [f"scenes_{k}" for k in KEYS] + ["era5"] + [f"ref_{k}" for k in KEYS]
    miss = [n for n in need if not (DONE / f"{n}.json").exists()]
    return miss


def zipdir(src, dst, pattern="*"):
    tmp = dst.with_suffix(".part")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(Path(src).rglob(pattern)):
            if f.is_file() and not f.name.endswith(".part"):
                z.write(f, f.relative_to(WOUT))
    tmp.replace(dst)


if __name__ == "__main__":
    t_end = time.time() + 5 * 24 * 3600
    while time.time() < t_end:
        miss = ready()
        if not miss:
            break
        lg.info(f"waiting for {len(miss)}: {miss[:6]}")
        time.sleep(600)
    for k in KEYS:
        if (WOUT / "scenes" / k).exists():
            zipdir(WOUT / "scenes" / k, P / f"scenes_{k}.zip")
    zipdir(WOUT / "era5", P / "era5.zip")
    tmp = P / "logs.zip"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted((PC / "logs").glob("wa_*")):
            z.write(f, f.name)
        for f in sorted(DONE.glob("*.json")):
            z.write(f, "done/" + f.name)
    man = {str(f.relative_to(WOUT)).replace("\\", "/"): f.stat().st_size for f in WOUT.rglob("*")
           if f.is_file() and "_tmp" not in f.parts and not f.name.endswith(".part")
           and not (f.parent.name in KEYS and f.parent.parent.name == "scenes")}
    json.dump(man, open(P / "manifest.json", "w"), indent=1)
    mark("PACK_DONE", missing=ready(), n_files=len(man))
    lg.info("WA PACK DONE")
