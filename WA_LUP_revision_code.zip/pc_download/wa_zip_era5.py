"""Zip the ERA5 CSV folder: out/wa/_pack/era5<tag>.zip (optionally after a done marker exists).
Usage: python wa_zip_era5.py [--marker=era5_early] [--tag=_b]"""
import sys, time, zipfile
from wa_common import WOUT, DONE, get_logger
lg = get_logger("wa_zip")
marker = next((a.split("=")[1] for a in sys.argv if a.startswith("--marker=")), None)
tag = next((a.split("=")[1] for a in sys.argv if a.startswith("--tag=")), "")
t_end = time.time() + 5 * 86400
while marker and not (DONE / f"{marker}.json").exists() and time.time() < t_end:
    time.sleep(120)
P = WOUT / "_pack"; P.mkdir(exist_ok=True)
dst = P / f"era5{tag}.zip"; tmp = dst.with_suffix(".part")
with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted((WOUT / "era5").glob("*.csv")):
        z.write(f, f"era5/{f.name}")
tmp.replace(dst)
lg.info(f"zipped {dst.name} ({dst.stat().st_size/1e6:.1f} MB)")
