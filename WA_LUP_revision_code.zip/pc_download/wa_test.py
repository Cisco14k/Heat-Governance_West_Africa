"""Connectivity and product check for the West Africa revision (quick; writes out/wa/_test.json)."""
import json, time, traceback
from wa_common import WOUT, AREAS, get_logger, retry, stac_client, sign, warp_read, grid, grid_bbox_lonlat, subgrid

lg = get_logger("wa_test")
res = {}


def t(name, fn):
    t0 = time.time()
    try:
        out = fn()
        res[name] = dict(ok=True, sec=round(time.time() - t0, 1), info=out)
        lg.info(f"OK {name}: {str(out)[:300]}")
    except Exception as e:
        res[name] = dict(ok=False, sec=round(time.time() - t0, 1), error=f"{type(e).__name__}: {str(e)[:400]}",
                         tb=traceback.format_exc()[-800:])
        lg.error(f"FAIL {name}: {e}")
    json.dump(res, open(WOUT / "_test.json", "w"), indent=1)


key = "WA_OUA"
g = grid(key, 240.0)
bbox = grid_bbox_lonlat(g)
cl = {}


def stac():
    cl["c"] = stac_client()
    return "client ok"


def search_ls():
    its = list(cl["c"].search(collections=["landsat-c2-l2"], bbox=bbox, datetime="2025-01-01/2025-02-28",
                              query={"eo:cloud_cover": {"lt": 30}}).items())
    cl["its"] = its
    return [(i.id, i.properties.get("eo:cloud_cover"), sorted(i.assets)[:30]) for i in its[:3]]


def read_ls():
    it = cl["its"][0]
    k = "lwir11" if "lwir11" in it.assets else "lwir"
    a = warp_read(sign(it.assets[k].href), g, "nearest", dst_nodata=0)
    return dict(shape=a.shape, nonzero=float((a > 0).mean()), med=float(a[a > 0].mean()) if (a > 0).any() else None)


def read_ls30():
    it = cl["its"][0]
    g30 = grid(key, 30.0)
    t0 = time.time()
    a = warp_read(sign(it.assets["red"].href), g30, "nearest", dst_nodata=0)
    return dict(shape=a.shape, sec=round(time.time() - t0, 1), mb=a.nbytes / 1e6)


def coll(c, dt=None):
    def f():
        kw = dict(collections=[c], bbox=bbox)
        if dt:
            kw["datetime"] = dt
        its = list(cl["c"].search(**kw).items())
        return [(i.id, sorted(i.assets)[:12]) for i in its[:2]] + [len(its)]
    return f


def openmeteo():
    import requests
    out = {}
    for model, vars_ in [("era5_land", "temperature_2m,dew_point_2m,soil_moisture_0_to_7cm,soil_moisture_7_to_28cm,precipitation,shortwave_radiation,wind_speed_10m,et0_fao_evapotranspiration"),
                         ("era5", "temperature_2m,shortwave_radiation,wind_speed_10m,surface_pressure,cloud_cover,et0_fao_evapotranspiration,soil_moisture_0_to_7cm")]:
        r = requests.get("https://archive-api.open-meteo.com/v1/archive",
                         params=dict(latitude=12.3714, longitude=-1.5197, start_date="2025-01-10", end_date="2025-01-11",
                                     hourly=vars_, models=model, timezone="GMT", wind_speed_unit="ms"), timeout=120)
        j = r.json()
        h = j.get("hourly", {})
        out[model] = dict(status=r.status_code, n_null={k: sum(v is None for v in vv) for k, vv in h.items() if k != "time"},
                          sample={k: vv[10] for k, vv in h.items()}, elev=j.get("elevation"), reason=j.get("reason"))
    return out


def ghsl():
    import requests
    u = "https://jeodpp.jrc.ec.europa.eu/ftp/jrc-opendata/GHSL/GHS_BUILT_S_GLOBE_R2023A/GHS_BUILT_S_E1995_GLOBE_R2023A_4326_3ss/V1-0/tiles/"
    r = requests.get(u, timeout=90)
    return dict(status=r.status_code, n=r.text.count(".zip"))


if __name__ == "__main__":
    t("stac_client", stac)
    if res["stac_client"]["ok"]:
        t("search_landsat", search_ls)
        if res.get("search_landsat", {}).get("ok") and cl.get("its"):
            t("read_landsat_240m", read_ls)
            t("read_landsat_30m", read_ls30)
        t("worldcover", coll("esa-worldcover", "2021-01-01/2021-12-31"))
        t("cci", coll("esa-cci-lc", "1995-01-01/1995-12-31"))
        t("gsw", coll("jrc-gsw"))
        t("dem", coll("cop-dem-glo-30"))
    t("openmeteo", openmeteo)
    t("ghsl_listing", ghsl)
    lg.info("WA TEST DONE")
