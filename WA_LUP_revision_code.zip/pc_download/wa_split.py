"""Split finished West Africa outputs into 8 MB parts for transfer (the bridge refuses large single uploads).
Watches out/wa/landsat/*.tif, out/wa/ref/*.tif and out/wa/_pack/*.zip; for every finished file (not modified for
2 minutes) writes out/wa/_parts/<subdir>/<name>.partNNN and <name>.sha256 (with the number of parts).
Runs until out/wa/_done/PACK_DONE.json exists and every file is split (max 6 days)."""
import time, hashlib
from wa_common import WOUT, DONE, get_logger

lg = get_logger("wa_split")
P = WOUT / "_parts"; P.mkdir(exist_ok=True)
CH = 8 * 1024 * 1024


def split(f):
    sub = P / f.parent.name; sub.mkdir(exist_ok=True)
    marker = sub / (f.name + ".sha256")
    if marker.exists() and marker.stat().st_mtime >= f.stat().st_mtime:
        return False
    h = hashlib.sha256(); n = 0
    with open(f, "rb") as fh:
        while True:
            b = fh.read(CH)
            if not b:
                break
            h.update(b)
            (sub / f"{f.name}.part{n:03d}").write_bytes(b); n += 1
    marker.write_text(f"{h.hexdigest()} {n} {f.stat().st_size}")
    lg.info(f"split {f.parent.name}/{f.name}: {n} parts")
    return True


if __name__ == "__main__":
    t_end = time.time() + 6 * 24 * 3600
    while time.time() < t_end:
        files = list((WOUT / "landsat").glob("*.tif")) + list((WOUT / "ref").glob("*.tif")) + list((WOUT / "_pack").glob("*.zip"))
        for f in files:
            try:
                if time.time() - f.stat().st_mtime > 120:
                    split(f)
            except Exception as e:
                lg.warning(f"{f.name}: {e}")
        if (DONE / "PACK_DONE.json").exists():
            pend = [f for f in files if not (P / f.parent.name / (f.name + ".sha256")).exists()]
            if not pend:
                break
        time.sleep(60)
    lg.info("WA SPLIT DONE")
