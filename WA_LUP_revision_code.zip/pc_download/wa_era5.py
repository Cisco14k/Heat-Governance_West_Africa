"""ERA5-Land / ERA5 background climate at the three city centres (Open-Meteo historical archive API, ECMWF data).

1. Hourly, dry seasons (15 Oct - 15 Apr) 1990-2026, model era5_land (0.1 deg): temperature_2m, dew_point_2m,
   relative_humidity_2m, soil_moisture_0_to_7cm, soil_moisture_7_to_28cm, soil_temperature_0_to_7cm
   and model era5 (0.25 deg; Open-Meteo serves no precipitation/radiation/wind for era5_land): precipitation,
   shortwave_radiation, wind_speed_10m, surface_pressure, cloud_cover, et0_fao_evapotranspiration,
   vapour_pressure_deficit, soil_moisture_0_to_7cm          -> out/wa/era5/<key>_hourly_<model>_<season>.csv
2. Daily, full years 1990-2025: era5_land temperature_2m_max/min/mean; era5 precipitation_sum,
   et0_fao_evapotranspiration, shortwave_radiation_sum           -> out/wa/era5/<key>_daily_<model>_<y0>_<y1>.csv
Quota-aware (Open-Meteo: 600/min, 5,000/h, 10,000/day weighted calls). Resumable.
"""
import sys, time, datetime as dt
import requests
import pandas as pd
from wa_common import WOUT, AREAS, get_logger, status, mark, is_done

lg = get_logger("wa_era5")
ODIR = WOUT / "era5"; ODIR.mkdir(parents=True, exist_ok=True)
URL = "https://archive-api.open-meteo.com/v1/archive"
HV = {"era5_land": "temperature_2m,dew_point_2m,relative_humidity_2m,soil_moisture_0_to_7cm,"
                   "soil_moisture_7_to_28cm,soil_temperature_0_to_7cm",
      "era5": "precipitation,shortwave_radiation,wind_speed_10m,surface_pressure,cloud_cover,et0_fao_evapotranspiration,"
              "vapour_pressure_deficit,soil_moisture_0_to_7cm"}
DV = {"era5_land": "temperature_2m_max,temperature_2m_min,temperature_2m_mean",
      "era5": "precipitation_sum,et0_fao_evapotranspiration,shortwave_radiation_sum"}
T_END = time.time() + 6 * 24 * 3600


def get(params, fn, kind):
    if fn.exists() and fn.stat().st_size > 500:
        return
    fails = 0
    while time.time() < T_END:
        try:
            r = requests.get(URL, params=params, timeout=300)
        except Exception as e:
            fails += 1; lg.warning(f"{fn.name}: {type(e).__name__} {str(e)[:120]}")
            if fails > 40:
                raise
            time.sleep(60); continue
        if r.status_code == 200:
            j = r.json()
            d = pd.DataFrame(j[kind])
            d["grid_elevation"] = j.get("elevation"); d["grid_lat"] = j.get("latitude"); d["grid_lon"] = j.get("longitude")
            tmp = fn.with_suffix(".part"); d.to_csv(tmp, index=False); tmp.replace(fn)
            lg.info(f"{fn.name}: {len(d)} rows"); return
        txt = r.text[:200]
        wait = 1800 if "Daily" in txt else (3700 if "Hourly" in txt else (90 if "Minutely" in txt else 120))
        lg.warning(f"{fn.name}: HTTP {r.status_code} {txt} -> sleep {wait}s")
        status("wa_era5", file=fn.name, waiting=txt[:80])
        time.sleep(wait)
    raise RuntimeError("time budget exhausted")


def run(key):
    a = AREAS[key]
    y0 = next((int(a.split('=')[1]) for a in sys.argv if a.startswith('--y0=')), 1990)
    for s in range(y0, 2027):
        st, en = dt.date(s - 1, 10, 15), min(dt.date(s, 4, 15), dt.date(2026, 10, 31))
        for model, vars_ in HV.items():
            get(dict(latitude=a["lat"], longitude=a["lon"], start_date=st.isoformat(), end_date=en.isoformat(),
                     hourly=vars_, models=model, timezone="GMT", wind_speed_unit="ms"),
                ODIR / f"{key}_hourly_{model}_{s}.csv", "hourly")
            time.sleep(1.0)
    for y0 in ([1984] if y0 < 1990 else []) + list(range(1990, 2026, 6)):
        y1 = 1989 if y0 == 1984 else min(y0 + 5, 2025)
        for model, dv in DV.items():
            get(dict(latitude=a["lat"], longitude=a["lon"], start_date=f"{y0}-01-01", end_date=f"{y1}-12-31",
                     daily=dv, models=model, timezone="GMT"), ODIR / f"{key}_daily_{model}_{y0}_{y1}.csv", "daily")
            time.sleep(1.0)
    status("wa_era5", area=key, complete=True)


if __name__ == "__main__":
    keys = [k for k in sys.argv[1:] if k in AREAS] or list(AREAS)
    for p_ in range(3):
        failed = []
        for k in keys:
            try:
                run(k)
            except Exception:
                import traceback
                lg.error(f"{k} FAILED\n{traceback.format_exc()[-800:]}"); failed.append(k)
        if not failed:
            break
        time.sleep(900)
    mark("era5" + ("_early" if any(a.startswith("--y0=") for a in sys.argv) else ""), failed=failed)
    lg.info("WA ERA5 DONE")
